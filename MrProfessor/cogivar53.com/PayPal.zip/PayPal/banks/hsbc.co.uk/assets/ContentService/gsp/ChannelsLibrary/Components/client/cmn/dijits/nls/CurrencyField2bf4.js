define({
	root :({
		"currency" : "Currency",
		"messages" : {
			"valuePositive" : "The amount must be greater than zero.",
			"valueNotZero" : "The amount must be greater than zero.",
			"valueNumeric" : "The value entered is invalid.",
			"maxNumericCharsExceeded" : "The amount entered exceeds the allowable value.",
			"currencyFieldErrorMsg" : "You must enter a valid amount.",
			"amountTooLarge" : "The amount exceeds the maximum allowed.",
			"amountTooSmall" : "The amount may not be less than the threshold.",
			"decimalPlaces" : "Allowed only two decimals. Please use commas to separate them.",
			"fromErrorMsg" :"The \'From\' amount is not valid",
      		"toErrorMsg" : "The \'To\' amount is not valid",
			"compareErrorMsg" : "The \'To\' amount must be higher than the \'From\' amount",
			"bothAmountsTheSameErrorMsg" : "From and To amounts can not be the same.",
			"currencyFieldMissingMsg":"Currency field value is required."
		},
		"currencyOverrides" : {
			"JPY" : {
				"decimalPlaces" : "You must enter a valid amount."
			}
		}
	}),
	"zh-hk": true,
	"zh-cn": true,
	"en-hk": true,
	"ar-sa":true,
	"es-ar":true,
	"en-je":true,
	"en-gb" : true,
	"en-eg" : true
});
