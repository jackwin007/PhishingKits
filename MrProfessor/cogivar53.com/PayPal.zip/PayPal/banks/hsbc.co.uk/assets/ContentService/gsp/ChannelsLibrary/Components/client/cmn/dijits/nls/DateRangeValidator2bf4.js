define({
	root: {
        to: "To",
        from: "From",
		fromErrorMsg:"The From date is not valid",
		toErrorMsg: "The To date is not valid",
		compareErrorMsg: "The To date must be after the From date",
		futureDateError: "Date should not be in future",
		dateRangeInvalidMsg: "A valid date must be inputted.",
		dateRangeMissingMsg:"Phone number is required.",
		dateRangeErrorRangeMsg:"Date range missing"
    },
    "hi" : true
});
