define({

	"filterTitle" : "Print transaction summary",
	"lastPymtAmt" : "Last Payment Amount",
	"overdraft" : "Overdraft Limit",
	"creditLimit" : "Credit limit",
	"origLoanAmt" : "Original Loan",
	"indicativeBalance" : "Balance summary",
	"bic" : "Branch Identifier Code ",
	"errorsnoTransactionAvailable" : "No transactions matching your search are available.", 
	"startDt" : "Start date",
	"lastStmtMinPymtAmt" : "Minimum payment due at Last Statement date",
	"rdrwlimit" : "Redraw Available Limit ",
	"premierRewards" : "Premier reward points",
	"mtgBalance" : "Amount outstanding",
	"penBalance" : "Balance/Valuation",
	"insBalance" : "Cover value",
	"disclaimerHeading" : "Disclaimer",
	"disclaimerBDate" : "The earliest date you can view your transactions on this account is ${duration} ${unit}. To view older transactions, please view your previous statements.",
	"termUnit" : {
		"month":"months",
		"day":"days",
		"year":"years"
	}
});
