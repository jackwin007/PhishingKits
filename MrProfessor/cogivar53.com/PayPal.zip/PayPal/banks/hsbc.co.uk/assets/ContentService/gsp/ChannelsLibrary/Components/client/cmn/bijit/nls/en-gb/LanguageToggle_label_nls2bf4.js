/**
 *
 */
define({
		"en-in" : "English",
		"en"    : "English",
		"hi"    : "Hindi",
		"hi-in" : "हिंदी",
		"en-je" : "English",
		"en-ae" : "English",
		"en-bh" : "English",
		"en-eg" : "English",
		"en-gb" : "English",
		"es-ar" : "español",
		"en-ar" : "English",
		"en-ph" : "English",
		"en-sa" : "English",
		"ar-sa" : "عربي",
		"ar-ae" : "عربي",
		"en-hk" : "English",
		"zh-hk" : "Traditional Chinese",
		"langMsg" : "Language retrieval failed.",
		'dialogTitle' : "Are you sure you want to change language?",
		'dialogMessage' : 'Any existing data inputs on the page will be lost',
		'langText' : 'Language',
		'yes' : "Change language",
		'no' : "Cancel",
		'dialogAccessibleText':"Opens in a dialog"
});
