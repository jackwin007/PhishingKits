define({
        accessibility: {
            dateFormat: "format : D D / M M / Y Y Y Y"
        },
        dateTextBoxErrorMsg: "The value entered is not valid.",
dateTextBoxMissingMsg: "Please select a date that is within the next 12 months",
        dateTextBoxRangegMsg:"date is out of range"
});
