/**
 *
 */
define({
		'backToPrev' : "Back to previous version of Online Banking",
		'backToPreVersion' : "Before you return to the previous online banking version.",
		'dialogmsgText' : "Even if you return to our previous online banking experience, you can change your mind at any time and try our new, enhanced version.",
		'dismiss' : "Dismiss",
		'parallelAdoptionParticipation' : false,
		'parallelAdoption':"HSBC Online Banking",
		'title' : "Are you sure you want to leave?",
		'messageMastHead' : "Before you leave",
		'message' : "Leaving this page will cancel any payments or requests that have not been completed.",
		'leave' : "Leave",
		'stayHere' : "Stay here",
		'secureLabel' : "Requires security code",
		'legacyEntityPIBURL' : "/1/3/personal/online-banking/account-list",
		'hothotSupport' : true,
		'stayMessage' : "You will stay to the current page",
		'leaveMessage' : "You will leave this page",
		 'subDomain' : {
			    "www.hkgv2ls0397-uk.p2g.netd2.hsbc.com.hk_subdomain":".p2g.netd2.hsbc.com.hk",
				"www.hkgv2ls0294-uk.p2g.netd2.hsbc.com.hk_subdomain":".p2g.netd2.hsbc.com.hk",
				"www.hkl100845-uk-oneclick.hk.hsbc_subdomain":".hk.hsbc",
				"www.hkl100259-uk-oneclick.p2g.netd2.hk.hsbc_subdomain":".hk.hsbc",
				"localhost_subdomain":".hsbc.co.uk",
				"defaultkey_subdomain":".hsbc.co.uk",
				"www.hsbc.co.uk_subdomain":".hsbc.co.uk"
	 	},
		'accountDropDown' : "Wai Mai Wing Wann Chan",
		'PAtitle' : "Thank you for trying our enhanced Online Banking service",
		'PAmessageMastHead' : "Thank you for trying our enhanced Online Banking service",
		'PAmessage1' : "You can go to back to your previous version of Online Banking at any time - simply select the link in the top left hand corner of your screen.",
		'PAmessage2' : "We want to make HSBC Online Banking even better, and to do that we need your help. Please tell us what you think by filling in a three question survey when you log off.",
		'close' : "Close",
		'closeMessage' : "You will leave this page",
		'logcount':'3',
		'cddTitle':'Customer Due Diligence Dialog',
		'PAMigtitle' : "Welcome to your enhanced Online Banking service",
		'PAMigmessageMastHead' : "Welcome to our new Online Banking experience",
		'PAMigmessage1' : "For a limited period of time, to help you get used to the changes at your own pace, you can choose to return to your previous version of Online Banking. Simply select the 'Back to previous version of Online Banking' link situated in the top left hand corner of the screen.",
		'PAMigmessage2'	: "We're here to help - information and tutorial videos are available online or you can contact us."
});
