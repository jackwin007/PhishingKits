define({
	root : ({
		defaultDatePattern: "dd/MM/yyyy",
		entityDatePattern: "d MMM y"
	}),
	"zh-cn" : true,
	"zh-hk" : true
});
