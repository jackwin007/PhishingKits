define({
	root : ({
		'1' : "Bank Name Search",
		'2' : "Clearance Code",
		'3' : "Manually Input Bank Address"
	}),
"es-ar": true,
	"hi" : true
});
