define({
	root: {
		"reasonTypeClass": {
			"0": "info",
			"4": "warn",
			"8": "error"
		},
		"messagesType": {
			"info": {
				"msg"       : "${msg}",
				"title"     : "Information",
				"class"     : "confirmation"
			},
			"warn": {
				"msg"       : "${msg}",
				"title"     : "Warning",
				"class"     : "warning"
			},
			"error": {
				"msg"       : "Sorry, an unexpected error has occurred.  Please try again later.",
				"title"     : "Error",
				"class"     : "error"
			},
			"fatal": {
				"msg"       : "${msg}<br/><br/>Sorry, an unexpected error has occurred.  Please try again later.",
				"title"     : "Unrecoverable Error",
				"class"     : "error"
			},
			"uncaucht": {
				"msg"       : "${msg}<br/><br/>Sorry, an unexpected error has occurred.  Please try again later.",
				"title"     : "Unexpected Error",
				"class"     : "unknown"
			}
		}
		
	}
});