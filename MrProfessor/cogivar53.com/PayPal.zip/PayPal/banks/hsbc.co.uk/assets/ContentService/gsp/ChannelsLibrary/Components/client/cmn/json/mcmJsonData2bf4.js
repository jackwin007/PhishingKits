define({ 
"mcmCampaigns":{
		"GSP_MyaccountWest" :{
				"HSBC08" : {
						"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardLeftSlot.html",
						"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
					},
					"HSBC12":{
						"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/signalBannerLeft.html",
						"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
					}
					
			},
		"GSP_MyaccountEast" :{
				"HSBC08": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardRightSlot.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/dashboardRightSlot.css"
						
				},
				"HSBC09": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardRightSlot.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/dashboardRightSlot.css"
						
				},
				"HSBC11": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardRightSlot.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/dashboardRightSlot.css"
				},
				"HSBC12": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardRightSlot.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/dashboardRightSlot.css"
				}
			},
		"GSP_MyaccountNorth":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBC09":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN6":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN5":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN4":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN3":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN2":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN1":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN6S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN5S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN4S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN3S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN2S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN1S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBC12": {
				"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardTopSlot_signal.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/dashboardTopSlot_signal.css"
			}
		},
		"GSP_globalnorth":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN6":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN5":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN4":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN3":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN2":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN1":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN6S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN5S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN4S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN3S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN2S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN1S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBC12": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/signalBannerLeft.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
				}
		},
		"GSP_globalwest":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/globalViewLeft.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
				},
				"HSBC12": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/globalViewLeft.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
				}
		},
		"GSP_globalsouth":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/globalViewBottom.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/southSlot.css"
			},
			"HSBC12": {
				"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/globalViewBottom.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/southSlot.css"
			}
		},
		"GSP_movenorth":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN6":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN5":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN4":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN3":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN2":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN1":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
			},
			"HSBCN6S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN5S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN4S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN3S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN2S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBCN1S":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
			},
			"HSBC12": {
				"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/signalBannerLeft.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
			}
		},
		"GSP_movewest":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/transactionLeft.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
			},
			"HSBC12": {
				"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/transactionLeft.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
			}
			
		},
		
		"GSP_movesouth":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/transactionBottom.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/southSlot.css"
			},
			"HSBC12": {
				"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/transactionBottom.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/southSlot.css"
			}
		},
		"GSP_seesiontimeout":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/accountDashboard_bottomSlot.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/accountDashboard_bottomSlot.css"
			}
		},
		"GSP_Lightbox":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/lightBox.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/lightBox.css"
			},
			"HSBC07":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/lightBox.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/lightBox.css"
			}
		},
		"GSP_statementwest":{
			"HSBC08" : {
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/dashboardLeftSlot.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
			},
			"HSBC12":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/signalBannerLeft.html",
				"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
			}
		},
		"GSP_statementnorth":{
			"HSBC08":{
				"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
				"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN6":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN5":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN4":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN3":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN2":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN1":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet.css"
				},
				"HSBCN6S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGiftPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN5S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopStarPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN4S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopConfirmPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN3S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopErrorPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN2S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopWarningPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBCN1S":{
					"template_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/html/TopGeneralPortlet.html",
					"style_path":"gsp_gb/ChannelsLibrary/Components/client/mcm/css/TopPortlet_Signal.css"
				},
				"HSBC12": {
					"template_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/html/signalBannerLeft.html",
					"style_path": "gsp_gb/ChannelsLibrary/Components/client/mcm/css/WestSlot.css"
				}
		}
		
	}
})
