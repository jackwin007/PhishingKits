define({
    root: {
        to: "To",
        from: "From",
		divider: " - ",
        fromErrorMsg:"The \'From\' amount is not valid",
        toErrorMsg: "The \'To\' amount is not valid",
        compareErrorMsg: "The \'To\' amount must be higher than the \'From\' amount",
        bothAmountsTheSameErrorMsg: "Please enter different amount.",
		toPlaceholder: "To",
		fromPlaceholder: "From",
		currencyFieldMissingMsg: "This value is required.",
		currencyFieldErrorMsg: "A valid amount must be  entered."
    },
    "en-eg": true,
    "en-hk" : true,
    "zh-cn" : true,
    "zh-hk" : true
});
