define({
	root : ({
		'to' : 'To',
		'toAccntReqMsg' : 'This value is required',
		'myAccounts' : 'My accounts',
		'account' : 'Account',
		'myPayees' : 'My payees',
		'newPayee' : 'New payee',
		'lockIconNewpayee' : '<span class="locked"></span>',
		'newPayeeLocked' : 'New Payee is locked',
		'myPayeeLocked' : 'My Payee is locked',
		'myAccountsLabel':'Account',
    	'unSupportedRecurringMsg' : 'Recurring payments can\'t be made in a foreign currency.',
    	'toAccounts' : 'To Account'

	}),
	"zh-cn": true,
	"zh-hk": true,
	"es-ar": true,
	"hi-in" : true,
	"en-je" : true,
	"en-ph" : true,
	"en-eg" : true,
	"ar-ae" : true,
	"en-gb" : true,
	"en-hk" : true
});
