define(({
	"acctDetlKey" : {
		"WT.si_n" : "accountsummary",
		"WT.si_x" : "1"
	},
	"acctFiltrKey": {
		"WT.si_n" : "accountsummaryfilter",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00009",
		"WT.ti" : "GSP Account Summary and Transactions Filter"
	},
	"txnContinue": {
		"WT.si_n" : "continue",
		"WT.si_x" : "1"
	},
	"messageReply" : {
		"WT.si_n" : "messagecentre",
		"WT.si_x" : "1"
	},
	"messageCompose" : {
		"WT.si_n" : "messagecentre",
		"WT.si_x" : "1"
	},
	"messageDelete" : {
		"WT.si_n" : "messagecentre",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00031",
		"WT.ti" : "GSP Message Centre Delete Message"
	},
	"messageRead" : {
		"WT.si_n" : "messagecentre",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00030",
		"WT.ti" : "GSP Message Centre Read Message"
	},
	"transStageOne" : {
		"WT.si_x" : "1"
	},
	"transStageTwo" : {
		"WT.si_x" : "2"
	},
	"quickTransferStageTwo" : {
		"WT.si_x" : "2",
		"WT.ti" : "GSP Quick Move Money Confirm"
	},
	"transStageThree" : {
		"WT.si_x" : "3"
	},
	"futureFilterKey" : {
		"WT.si_n" : "futuredatemanagement",
		"WT.si_x" : "1"
	},
	"productSelect" : {
		"WT.si_n" : "termsandcondition",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00014"
	},
	"termsConditionsDetail" : {
		"WT.si_n" : "termsandcondition",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00015"
	},
	"messageSend" : {
		"WT.si_n" : "messagecentre",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00028",
		"WT.ti" : "GSP Message Centre Send Message"
	},

	"messageReceieve" : {
		"WT.si_n" : "messagecentre",
		"WT.si_x" : "1",
		"DCS.dcsuri" : "EV00029",
		"WT.ti" : "GSP Message Centre Received Message"
	},

	"lostStolenCard" : {
		"DCS.dcsuri" : "EV00021"
	},

	"lostCardLink" :  {
		"DCS.dcsuri" : "EV00021"
	}

}));