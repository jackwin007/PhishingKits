define({
	root : ({
		'calculator' : 'Currency converter',
		'TERMS_AND_CONDITIONS' : 'Terms and Conditions',
		'Close' : 'Close'
	}),
"es-ar": true,
	"hi-in" : true
});
