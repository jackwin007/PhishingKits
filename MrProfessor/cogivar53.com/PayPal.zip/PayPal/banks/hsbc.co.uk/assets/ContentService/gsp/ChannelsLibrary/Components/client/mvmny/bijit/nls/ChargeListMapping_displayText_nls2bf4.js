define({
	root : ({
		'select' : 'Select',
		'iPay': "Charge to debit account",
		'youPay': "Charge to credit account",
		'wePay': "Share charge between debit and credit"
	}),
	"es-ar" : true,
	"zh-cn" : true,
	"zh-hk" : true,
	"hi-in" : true
});
