/*  AccountCurrencyList used in Add Beneficiary (Person) */
/*  Likely incomplete */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"AccountCurrencyList" : [ {
		"id" : 'USD',
		"desckey" : 'USD',
		"defaultflag" : 'Y'
 }, {
		"id" : 'BHD',
		"desckey" : 'BHD',
		"defaultflag" : 'N'
	}, {
		"id" : 'BYR',
		"desckey" : 'BYR',
		"defaultflag" : 'N'
	}, {
		"id" : 'PHP',
		"desckey" : 'PHP',
		"defaultflag" : 'N'
	}, {
		"id" : 'INR',
		"desckey" : 'INR',
		"defaultflag" : 'N'
	}, {
		"id" : 'CAD',
		"desckey" : 'CAD',
		"defaultflag" : 'N'
	}, {
		"id" : 'AUD',
		"desckey" : 'AUD',
		"defaultflag" : 'N'
	}, {
		"id" : 'JPY',
		"desckey" : 'JPY',
		"defaultflag" : 'N'
	}, {
		"id" : 'AED',
		"desckey" : 'AED',
		"defaultflag" : 'N'
	} ]
}));
