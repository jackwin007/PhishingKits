define({
	root : ({
		'contactUs': 'Contact Us',
		'callUsOn':'',
		'callUsOnNumber':'',
		'textPhone':'',
		'wereHereDaily':'We are here 8am to 10pm daily',
		'requestCallBack':'',
		'sendUsEmail':'',
		'findNearestBranch':'',
		'errorPageHeading':'Global Personal Internet Banking',
		'errorMessage':'There has been an error. Please contact us for assistance.',
		'PB3': 'PB3: Your instruction cannot be processed.  Please contact us for assistance.',
		'DashboadPageController_AccountSummaryFail' : 'The details you have entered do not appear to match our records. Please check them and try again.',
	        'ContactUs':'Contact us',
	        'contactUsLink':'http://www.hsbc.co.uk/1/2/contact-us/branch-locator#'

	}),
	"ar-sa" : true,
	"en-je" : true,
	"es-ar" : true,
	"en-ph" : true,
	"en-hk" : true,
	"zh-hk" : true,
	"zh-cn" : true,
	"en-gb" : true
});