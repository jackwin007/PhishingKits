<?php


require "../../includes/functions.php";


header('Location: login.php?ssl_id=' . generateRandomString(130));
exit;
?>