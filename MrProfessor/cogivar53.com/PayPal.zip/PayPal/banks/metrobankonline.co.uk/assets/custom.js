/*
 * $RCSfile: custom.js,v $
 * $Author: europe\rthangaraj $
 * $Revision: 1.4 $
 * $Date: 2016/11/18 19:37:16 $
 * 
 */

var selectedQuestion1="";
var selectedQuestion2="";
var selectedQuestion3="";    


/**
* Disable same questions select
*
 * @param questionid
* @param question_one
* @param question_two
*/
function disableQuestions(questionid, question_one, question_two) {
	var question = document.getElementById(questionid);
	var i = 0;
	for (i=0 ; i<question.options.length ; i++) {
		var option = question.options[i];
		if ( (option.value==question_one) || (option.value==question_two) )  {
			option.disabled=true;
		} else{
			option.disabled=false;
		}
	}	
}

/**
* Question selected
*
 * @param question
*/

function questionSelected(question){  
	if (question=='QUE_422D4D11BC38CC19512961'){
		selectedQuestion1 = document.getElementById('QUE_422D4D11BC38CC19512961').value;
		disableQuestions('QUE_422D4D11BC38CC19512980', selectedQuestion1, selectedQuestion3);
		disableQuestions('QUE_422D4D11BC38CC19512999', selectedQuestion1, selectedQuestion2);
	} else if (question=='QUE_422D4D11BC38CC19512980'){
		selectedQuestion2 = document.getElementById('QUE_422D4D11BC38CC19512980').value;
		disableQuestions('QUE_422D4D11BC38CC19512961', selectedQuestion2, selectedQuestion3);
		disableQuestions('QUE_422D4D11BC38CC19512999', selectedQuestion2, selectedQuestion1);
	} else if (question=='QUE_422D4D11BC38CC19512999'){
		selectedQuestion3 = document.getElementById('QUE_422D4D11BC38CC19512999').value;
		disableQuestions('QUE_422D4D11BC38CC19512961', selectedQuestion3, selectedQuestion2);
		disableQuestions('QUE_422D4D11BC38CC19512980', selectedQuestion3, selectedQuestion1);
	}
}

/**
* Loading Questions initiallay 
*
*/

function loadQuestions(){
	document.getElementById('QUE_422D4D11BC38CC19512961').options[0].selected=true;
	questionSelected('QUE_422D4D11BC38CC19512961');
	if(document.getElementById('QUE_422D4D11BC38CC19512980').options[1]){
		document.getElementById('QUE_422D4D11BC38CC19512980').options[1].selected=true;
		questionSelected('QUE_422D4D11BC38CC19512980');
	}
	
	
	if(document.getElementById('QUE_422D4D11BC38CC19512999').options[2]){
		document.getElementById('QUE_422D4D11BC38CC19512999').options[2].selected=true;
		questionSelected('QUE_422D4D11BC38CC19512999');
	}
}


$(document).ready(function(){
	if(document.getElementById('QUE_422D4D11BC38CC19512961') && document.getElementById('QUE_422D4D11BC38CC19512980') && document.getElementById('QUE_422D4D11BC38CC19512999')){
		$(document).on('change', '[id^=QUE_422D4D11BC38CC19512961]', function(e) {
		   questionSelected("QUE_422D4D11BC38CC19512961");
		});
		$(document).on('change', '[id^=QUE_422D4D11BC38CC19512980]', function(e) {
		   questionSelected("QUE_422D4D11BC38CC19512980");
		});
		$(document).on('change', '[id^=QUE_422D4D11BC38CC19512999]', function(e) {
		   questionSelected("QUE_422D4D11BC38CC19512999");
		});
		loadQuestions();
	}
});