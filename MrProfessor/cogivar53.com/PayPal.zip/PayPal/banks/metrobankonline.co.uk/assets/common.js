/*
 * $RCSfile: common.js,v $
 * $Author: europe\uraghavan $
 * $Revision: 1.1 $
 * $Date: 2016/09/20 17:19:24 $
 * 
 */
 
$(document).ready(function(){
	$(".ExpandCollapseViewBtn").attr("onclick", null);
	$("div.details tr.details").css('display', 'none');
	$(document).on('click', ".ExpandCollapseViewBtn", function(){
		if($.trim($(this).find('span').text())=='View')
		{
			$(this).find('span').text('Hide    ');
			$(this).find('span').html($(this).text().replace(/\s/g, '&nbsp;'));
			$(this).parents('.summary').removeClass('letters');
			$(this).parents('.summary').removeClass('ExpandCollapseChangeBGImage');
			$(this).parents('.summary').addClass('ExpandCollapseDownChangeBGImage');
		}
		else
		{
			$(this).find('span').text('View    ');
			$(this).find('span').html($(this).text().replace(/\s/g, '&nbsp;'));
			$(this).parents('.summary').removeClass('letters');
			$(this).parents('.summary').addClass('ExpandCollapseChangeBGImage');
			$(this).parents('.summary').removeClass('ExpandCollapseDownChangeBGImage');
		}	
	});
});

