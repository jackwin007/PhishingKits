_satellite.pushAsyncScript(function(event, target, $variables){
  if (_satellite.readCookie('hideCookieWarning') == 'true') {
  return;
}
var style = document.createElement('style');
style.type = 'text/css';
style.innerHTML = '#cookieMessage { margin-top: 4px; margin-bottom: 12px; background: #e6e6e6; padding: 12px; overflow: hidden; } #cookieMessage img { float: left; } #cookieMessageContent { overflow: hidden; margin-left: 36px; } #cookieMessageContent p:first-child { margin-top: 0px; } #cookieMessageContent a { font-weight: bold; } #cookieMessageContent a:hover { color: #c90212; } #cookieMessageBtns { margin-top: 8px; margin-bottom: 0px; } #acceptCookieMessageBtn { background: #ec0000; border: none; padding-left: 12px; padding-right: 12px; } #acceptCookieMessageBtn:hover { background: #cc1221; color: white; }';
document.getElementsByTagName('head')[0].appendChild(style);

var cookieMessage = document.createElement('div');
cookieMessage.id = 'cookieMessage';
var icon = document.createElement('img');
icon.src = 'https://www.santander.co.uk/csdlvlr/BlobServer?blobtable=MungoBlobs&blobkey=id&blobcol=urldata&blobheader=image%2Fgif&blobheadervalue1=inline%3Bfilename%3Dico_infocookie.gif&blobwhere=1314010019586&blobheadervalue2=911289237421288&blobheadername1=Content-Disposition&blobheadername2=portal';
cookieMessage.appendChild(icon);
var cookieContent = document.createElement('div');
cookieContent.id = 'cookieMessageContent';
var title = document.createElement('p');
title.innerHTML = '<b>Please read</b>';
cookieContent.appendChild(title);
var paragraph1 = document.createElement('p');
paragraph1.innerHTML = 'Our website is set to allow cookies. We use cookies to improve your website experience, the products and services we offer and to make sure our digital marketing is personalised to you.';
cookieContent.appendChild(paragraph1);
var paragraph2 = document.createElement('p');
var cookiePolicyLink = document.createElement('a');
cookiePolicyLink.text = 'See the cookies we use on our website by visiting our cookie policy. You can manage them through your device or web browser.';
cookiePolicyLink.href = 'https://www.santander.co.uk/uk/cookie-policy?icid=olb-cookiebanner';
cookiePolicyLink.target = '_blank';
paragraph2.appendChild(cookiePolicyLink);
cookieContent.appendChild(paragraph2);
cookieMessage.appendChild(cookieContent);
var buttonDiv = document.createElement('div');
buttonDiv.id = 'cookieMessageBtns';
buttonDiv.className = 'buttonholder';
var acceptButtonSpan = document.createElement('span');
acceptButtonSpan.className = 'button';
var acceptButton = document.createElement('a');
acceptButton.id = 'acceptCookieMessageBtn';
acceptButton.className = 'primary';
acceptButton.text = "Don't show me this again";
acceptButton.onclick = function() {
  document.querySelector('div#cookieMessage').style.display = 'none';
  //var date = new Date();
  //date.setTime(date.getTime() + (10*60*1000));
  var date = new Date(new Date().setFullYear(new Date().getFullYear() + 1))
  var expires = "; expires="+ date.toGMTString();
  var currentDom = document.location.host;
  document.cookie = "hideCookieWarning=true" + expires + "; path=/; domain=.santander.co.uk;";
  //document.cookie = "hideCookieWarning=true" + expires + "; path=/; domain=" + currentDom + ";";
};
acceptButtonSpan.appendChild(acceptButton);
buttonDiv.appendChild(acceptButtonSpan);
cookieMessage.appendChild(buttonDiv);

var header = document.getElementById('header');
header.parentNode.insertBefore(cookieMessage, header);

});
