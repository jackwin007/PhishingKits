_satellite.pushAsyncScript(function(event, target, $variables){
  /*
var pageLinks = document.querySelectorAll('a');

for (i = 0; i < pageLinks.length; i++) {
  var linkHref = pageLinks[i].href;
  if (/http:.+/.test(linkHref)) {
  // If the link begins with HTTP, we change to HTTPS
    pageLinks[i].href = "https:" + pageLinks[i].href.substr(5);
    continue;
  } 
  // The alternative is that the link is HTTPS (ok) or that it doesn't have protocol
  // so it will automatically pick up HTTPS (ok)
}
*/

_satellite.track('Link_URL_Rewriting');
});
