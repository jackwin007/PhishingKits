/*
 * @namespace behaviour2
 * @description Common behaviours
 *
 * Behaviours supported & required  
 * - Global variable
 * - Link to post
 * - Register print button
 * - Iframe autoresize
 * - Register help button
 * - Register Radio Groups
 * - Fix for Safari 3 display table-cell on navigationBar
 * - Show elements hidden by hiddenWithoutJavaScript
 * - Close Button
 * - Descriptive dynamic behaviours
 * - Autotab
 * - Tooltip
 * - ContextHelp
 * - Register Submit On Change and Hide button
 * - hideBCSOC
 * - hideJS
 * - Support functions (scrollTop)
 * - No paste
 * - Terms Agreement
 * - Tabs
 * - Countdown
 * - Validator
 * - Popup Creation
 * - PopUp position
 * - Check all checkboxes
 * - Hide/Show block
 *
 * @copyright (c) 2010 Isban UK. All Rights Reserved.
 * @date   04/04/2016
 * @version V1R47F10
 * @since 2.0
 * @requires jQuery
 */

// Global variable

var touchDevice = false;
var MK1G="";
var MK2G="";
var MK3G="";
var MK4G="";

(function isTouchDevice() {
    "use strict";
    try {
        document.createEvent("TouchEvent");
        touchDevice = true;
    } catch (e) {
        touchDevice = false;
    }
})();

/**
 * @function
 * @name Link to post
 * @memberof behaviour2
 * @description Converts all links to post calls. If URL ends with .ssobto and ESCECTX cookie is present, a hidden
 * parameter is added to the form with cookie value.
 * Links with onclick events will be skipped.
 * @since 2.0
 */
(function ($) {
    "use strict";
    $(function () {
        $("a:not([onclick],.noLink2Post)").click(function (event) {
            function readCookie(name) {
                var nameEQ = name + "=",
                    ca = document.cookie.split(';');
                for(var i=0;i < ca.length;i++) {
                    var c = ca[i];
                    while (c.charAt(0)===' ') { 
                        c = c.substring(1,c.length); 
                    }
                    if (c.indexOf(nameEQ) === 0) { 
                        return unescape(c.substring(nameEQ.length,c.length)); 
                    }
                }
                return null;
            }
            
            var link = $(this),
                href = link.attr('href'),
                target = link.attr('target');
            
            if (href && href !== "" && href.indexOf("#") === -1 && href.indexOf(".ssobto") !== -1) {
                
                event.preventDefault();         
                var formElement = $(document.createElement('form')).attr({
                    'method': 'post',
                    'action': href
                });
                
                if (target && target !== ''){
                    formElement.attr('target', target);
                }
                    
                var esceCtx = readCookie("ESCECTX");
                if(esceCtx && esceCtx.length > 0){
                    var item = esceCtx.split(":");
                    formElement.append($(document.createElement('input')).attr({
                        'type': 'hidden',
                        'name': item[0],
                        'value': item[1]
                    }));
                }
                
                $('body').append(formElement);
                formElement.submit();
            }
    	});
	});
}(jQuery)); 

/**
 * @function
 * @name Register print button
 * @memberof behaviour2
 * @description Register on click event a function to print page on all tags with id 'printCommand'
 * @since 2.0
 * @example
 * &lt;a id="printCommand"&gt;Print&lt;/a&gt;
 */
$(function(){
	"use strict";
	//TODO Shoul be hidden without javascript
	$("#printCommand").click(function(e) {
		window.print();
		e.preventDefault();
	});
});

(function(n){function g(a){try{if(navigator.plugins&&navigator.plugins.length)for(var c=0;c<navigator.plugins.length;c++){var b=navigator.plugins[c];if(b.name.indexOf(a)>=0)return b.name+(b.description?"|"+b.description:"")}}catch(e){}return""}function A(a){try{if(!a)return B();var c;a:{var b;try{b=document.getElementById(a)}catch(e){}if(b===null||typeof b==="undefined")try{b=document.getElementsByName(a)[0]}catch(f){}if(b===null||typeof b==="undefined")for(var d=0;d<document.forms.length;d++)for(var h=
	document.forms[d],l=0;l<h.elements.length;l++){var k=h[l];if(k.name===a||k.id===a){c=k;break a}}c=b}if(c!==null)try{c.value=B()}catch(s){c.value=escape(s.message)}}catch(C){}}function B(a){var c=new Date,b=new Date,e=[u("TF1"),u("021"),function(){return ScriptEngineMajorVersion()},function(){return ScriptEngineMinorVersion()},function(){return ScriptEngineBuildVersion()},function(){return i("{7790769C-0471-11D2-AF11-00C04FA35D02}")},function(){return i("{89820200-ECBD-11CF-8B85-00AA005B4340}")},function(){return i("{283807B5-2C60-11D0-A31D-00AA00B92C03}")},
	function(){return i("{4F216970-C90C-11D1-B5C7-0000F8051515}")},function(){return i("{44BBA848-CC51-11CF-AAFA-00AA00B6015C}")},function(){return i("{9381D8F2-0288-11D0-9501-00AA00B911A5}")},function(){return i("{4F216970-C90C-11D1-B5C7-0000F8051515}")},function(){return i("{5A8D6EE0-3E18-11D0-821E-444553540000}")},function(){return i("{89820200-ECBD-11CF-8B85-00AA005B4383}")},function(){return i("{08B0E5C0-4FCB-11CF-AAA5-00401C608555}")},function(){return i("{45EA75A0-A269-11D1-B5BF-0000F8051515}")},
	function(){return i("{DE5AED00-A4BF-11D1-9948-00C04F98BBC9}")},function(){return i("{22D6F312-B0F6-11D0-94AB-0080C74C7E95}")},function(){return i("{44BBA842-CC51-11CF-AAFA-00AA00B6015B}")},function(){return i("{3AF36230-A269-11D1-B5BF-0000F8051515}")},function(){return i("{44BBA840-CC51-11CF-AAFA-00AA00B6015C}")},function(){return i("{CC2A9BA0-3BDD-11D0-821E-444553540000}")},function(){return i("{08B0E5C0-4FCB-11CF-AAA5-00401C608500}")},function(){return eval("navigator.appCodeName")},function(){return eval("navigator.appName")},
	function(){return eval("navigator.appVersion")},function(){return v(["navigator.productSub","navigator.appMinorVersion"])},function(){return eval("navigator.browserLanguage")},function(){return eval("navigator.cookieEnabled")},function(){return v(["navigator.oscpu","navigator.cpuClass"])},function(){return eval("navigator.onLine")},function(){return eval("navigator.platform")},function(){return eval("navigator.systemLanguage")},function(){return eval("navigator.userAgent")},function(){return v(["navigator.language",
	"navigator.userLanguage"])},function(){return eval("document.defaultCharset")},function(){return eval("document.domain")},function(){return eval("screen.deviceXDPI")},function(){return eval("screen.deviceYDPI")},function(){return eval("screen.fontSmoothingEnabled")},function(){return eval("screen.updateInterval")},function(){return Math.abs(p-q)!==0},function(){return D(c)},function(){return"@UTC@"},function(){var k=0;k=0;if(D(c))k=Math.abs(p-q);return k=-(c.getTimezoneOffset()+k)/60},function(){return(new Date(2005,
	5,7,21,33,44,888)).toLocaleString()},function(){return eval("screen.width")},function(){return eval("screen.height")},function(){return o.Acrobat},function(){return o.Flash},function(){return o.QuickTime},function(){return o["Java Plug-in"]},function(){return o.Director},function(){return o.Office},function(){return"@CT@"},function(){return p},function(){return q},function(){return c.toLocaleString()},function(){return eval("screen.colorDepth")},function(){return eval("window.screen.availWidth")},
	function(){return eval("window.screen.availHeight")},function(){return eval("window.screen.availLeft")},function(){return eval("window.screen.availTop")},function(){return g("Acrobat")},function(){return g("Adobe SVG")},function(){return g("Authorware")},function(){return g("Citrix ICA")},function(){return g("Director")},function(){return g("Flash")},function(){return g("MapGuide")},function(){return g("MetaStream")},function(){return g("PDFViewer")},function(){return g("QuickTime")},function(){return g("RealOne")},
	function(){return g("RealPlayer Enterprise")},function(){return g("RealPlayer Plugin")},function(){return g("Seagate Software Report")},function(){return g("Silverlight")},function(){return g("Windows Media")},function(){return g("iPIX")},function(){return g("nppdf.so")},function(){var k=document.createElement("span");k.innerHTML="&nbsp;";k.style.position="absolute";k.style.left="-9999px";document.body.appendChild(k);var s=k.offsetHeight;document.body.removeChild(k);return s},j,j,j,j,j,j,j,j,j,j,
	j,j,j,j,function(){return"5.7.0-0"},j,function(){return r},j,j,j];G();for(var f="",d=0;d<e.length;d++){if(a){f+=w(e[d].toString(),'"',"'",true);f+="="}var h;try{h=e[d](this)}catch(l){h=""}f+=a?h:escape(h);f+=";";if(a)f+="\\n"}f=w(f,escape("@UTC@"),(new Date).getTime());f=w(f,escape("@CT@"),(new Date).getTime()-b.getTime());return E&&x?x(f):f}function w(a,c,b,e){if(typeof e!=="boolean")e=false;for(var f=true,d;(d=a.indexOf(c))>=0&&(e||f);){a=a.substr(0,d)+b+a.substr(d+c.length);f=false}return a}function D(a){var c=
	Math.min(p,q);return Math.abs(p-q)!==0&&a.getTimezoneOffset()===c}function G(){for(var a=["Acrobat","Flash","QuickTime","Java Plug-in","Director","Office"],c=0;c<a.length;c++){var b=a[c],e=o,f=b,d=b;b="";try{if(navigator.plugins&&navigator.plugins.length){var h=RegExp(d+".* ([0-9._]+)");for(d=0;d<navigator.plugins.length;d++){var l=h.exec(navigator.plugins[d].name);if(l===null)l=h.exec(navigator.plugins[d].description);if(l)b=l[1]}}else if(window.ActiveXObject&&y[d])try{var k=new ActiveXObject(y[d][0]);
	b=y[d][1](k)}catch(s){b=""}}catch(C){b=C.message}e[f]=b}}function v(a){for(var c=0;c<a.length;c++)try{var b=eval(a[c]);if(b)return b}catch(e){}return""}function i(a){var c="";try{if(typeof m.a.getComponentVersion!=="undefined")c=m.a.getComponentVersion(a,"ComponentID")}catch(b){a=b.message.length;a=a>40?40:a;c=escape(b.message.substr(0,a))}return c}function u(a){return function(){return a}}function H(a){function c(h){e=e<<h[0]|h[1];for(f+=h[0];f>=6;){h=e>>f-6&63;b+=t.substring(h,h+1);f-=6;e^=h<<f}}
	var b="",e=0,f=0;c([6,(a.length&7)<<3|0]);c([6,a.length&56|1]);for(var d=0;d<a.length;d++){if(z[a.charCodeAt(d)]==undefined)return;c(z[a.charCodeAt(d)])}c(z[0]);f>0&&c([6-f,0]);return b}function x(a){for(var c=H,b=a,e=0;F[e];e++)b=b.split(F[e]).join(String.fromCharCode(e+1));c=c(b);if(c==undefined)return a;else{b=65535;for(e=0;e<a.length;e++){b=(b>>>8|b<<8)&65535;b^=a.charCodeAt(e)&255;b^=(b&255)>>4;b^=b<<12&65535;b^=(b&255)<<5&65535}b&=65535;a="";a+=t.charAt(b>>>12);a+=t.charAt(b>>>6&63);a+=t.charAt(b&
	63);c+=a;return c}}options=n||{};n=options.ctx||window;var E=options.hasOwnProperty("compress")?options.compress:true,m={},r="",p=(new Date(2005,0,15)).getTimezoneOffset(),q=(new Date(2005,6,15)).getTimezoneOffset(),o=[],j=u(""),y={Flash:["ShockwaveFlash.ShockwaveFlash",function(a){return a.getVariable("$version")}],Director:["SWCtl.SWCtl",function(a){return a.ShockwaveVersion("")}]};try{m.a=document.createElement("span");typeof m.a.addBehavior!=="undefined"&&m.a.addBehavior("#default#clientCaps")}catch(I){}o=
	{};var z={1:[4,15],110:[8,239],74:[8,238],57:[7,118],56:[7,117],71:[8,233],25:[8,232],101:[5,28],104:[7,111],4:[7,110],105:[6,54],5:[7,107],109:[7,106],103:[9,423],82:[9,422],26:[8,210],6:[7,104],46:[6,51],97:[6,50],111:[6,49],7:[7,97],45:[7,96],59:[5,23],15:[7,91],11:[8,181],72:[8,180],27:[8,179],28:[8,178],16:[7,88],88:[10,703],113:[11,1405],89:[12,2809],107:[13,5617],90:[14,11233],42:[15,22465],64:[16,44929],0:[16,44928],81:[9,350],29:[8,174],118:[8,173],30:[8,172],98:[8,171],12:[8,170],99:[7,
	84],117:[6,41],112:[6,40],102:[9,319],68:[9,318],31:[8,158],100:[7,78],84:[6,38],55:[6,37],17:[7,73],8:[7,72],9:[7,71],77:[7,70],18:[7,69],65:[7,68],48:[6,33],116:[6,32],10:[7,63],121:[8,125],78:[8,124],80:[7,61],69:[7,60],119:[7,59],13:[8,117],79:[8,116],19:[7,57],67:[7,56],114:[6,27],83:[6,26],115:[6,25],14:[6,24],122:[8,95],95:[8,94],76:[7,46],24:[7,45],37:[7,44],50:[5,10],51:[5,9],108:[6,17],22:[7,33],120:[8,65],66:[8,64],21:[7,31],106:[7,30],47:[6,14],53:[5,6],49:[5,5],86:[8,39],85:[8,38],23:[7,
	18],75:[7,17],20:[7,16],2:[5,3],73:[8,23],43:[9,45],87:[9,44],70:[7,10],3:[6,4],52:[5,1],54:[5,0]},F=["%20",";;;","%3B","%2C","und","fin","ed;","%28","%29","%3A","/53","ike","Web","0;",".0","e;","on","il","ck","01","in","Mo","fa","00","32","la",".1","ri","it","%u","le"],t=".0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz";m.santanderform=A;m.f1b5=x;m.setResource=function(a,c){if(c)try{xmlhttp=window.XMLHttpRequest?new XMLHttpRequest:new ActiveXObject("Microsoft.XMLHTTP");xmlhttp.open("GET",
	a,false);xmlhttp.send();if(xmlhttp.readyState==4&&xmlhttp.status==200)r=xmlhttp.getResponseHeader("Last-Modified");if(r===null)r=""}catch(b){}else r=""};n.santanderparm=m;if(E){n=navigator.userAgent.toLowerCase();navigator.product==="Gecko"&&parseInt(n.substring(n.indexOf("rv:")+3,n.indexOf(")",n.indexOf("rv:")+3)).split(".")[0])<=2&&A()}})();

(function ($) {
    'use strict';

	$(function () {
        var whoIDElement = $('#foData');
        if (whoIDElement.length) {
            $('#btnFO').click( function(){
                santanderparm.santanderform('foData');
				
				if(whoIDElement.val().length > 4000){
		                whoIDElement.val("jsc greater than 4000");
		        }
            })
        }
    });

}(jQuery));
 
/**
 * @function
 * @name Iframe autoresize
 * @memberof behaviour2
 * @description For each frame it checks every 100 msec if iframe height is correct, growing or shrinking it if necessary.
 * If an iframe has 'fixed' class, then it will be skipped from this check.
 * @since 2.0
 */
var timeInterval = 300;
$(function() {

	"use strict";
	var __iframes = $('iframe:not(.fixed)');

	function getDocHeight(iframe) {
		var body = $(iframe).contents().find("body");

		var maxHeight = 0;

		if (navigator.appVersion.indexOf("MSIE 7.") != -1){

			//Detect MIRA
			var miraObj = window.frames[0].main;
			if((typeof(miraObj) === "object") && (typeof(miraObj.dom) === "object")){
				maxHeight = 1800;
			}else{
				maxHeight = Math.max(
					body.prop('scrollHeight'),
					100
				);
			}

		}else{

			maxHeight = Math.max(
				body.prop('scrollHeight'),
				iframe.contentDocument.documentElement.scrollHeight,
				iframe.contentDocument.documentElement.offsetHeight,
				iframe.contentDocument.documentElement.clientHeight,
				100
			);

		}

		return maxHeight;
	}

	function checkIframes() {
		__iframes.each(function(index, iframe) {
			try {
				var scrollHeight = getDocHeight(iframe);
				if ($(iframe).data('pSH') !== scrollHeight) {
					$(iframe).height(scrollHeight + 20);
					$(iframe).data('pSH', getDocHeight(iframe));
				}
			} catch (e) {}
		});
	}
	
	var __interval;
	
	if (__iframes.length) {
		__interval = setInterval(checkIframes, timeInterval);
	}

});

/**
 * @function
 * @name Register help button
 * @memberof behaviour2
 * @description Register on click event a function to show help popup on all tags with 'helpCommand' id or class.
 * If 'interstitial' class is present, a diferent width and height for popup will be used.
 * @since 2.0
 * @example
 * &lt;a id="helpCommand"&gt;Show help&lt;/a&gt;
 * @example
 * &lt;a class="helpCommand"&gt;Show help&lt;/a&gt;
 */
$(function() {
	"use strict";
	$("#helpCommand, .helpCommand").click(function(event){
		event.preventDefault();
		var height = 500;
		var width = 500;
		if ($(this).hasClass('interstitial')) {
			width = 810;
		}
		window.open($(this).attr('href'), $(this).attr('target'),
			"status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,width="+width+",height="+height+",top=0,left=0,resizable=yes").focus();
	});
});


/**
 * @function
 * @name Assign focus
 * @memberof behaviour2
 * @description When page loads, set focus on the first tag with 'focus' class
 * @since 2.0
 * @example
 * &lt;input name="textField" type="text" class="firstfocus" /&gt;
 */
$(function() {
	"use strict";
	if(!touchDevice) {
		$('.firstfocus:first').focus();
	} 	
 });

/**
 * @function
 * @name Init Default Action
 * @memberof behaviour2
 * @description When user hits enter on a form field (text fields, radio, checkbox or select), the first input button with 'defaultAction' class will be used
 * @since 2.0
 * @example
 * &lt;input type="submit" class="defaultAction" value="Continue" /&gt;
 */
$(function() {
	"use strict";
	
	/*jshint validthis: true */
	function clickDefaultAction(event) {
		if (event.which === 13) { // Enter
			if ($(this).closest('form').find('input.defaultAction').click().length) {
				event.preventDefault();
			}
		}
	}

	$(':text, :password, :radio, :checkbox, select').keypress(clickDefaultAction);
});



/**
 * @function
 * @name Register Radio Groups
 * @memberof behaviour2
 * @description Behaviour that allows to clear fields when a its radio is unchecked (caused by other radio that has been checked). 
 * See example to know how to build this structure to get this behaviour
 * @since 2.0
 * @example
 * &lt;span class="data"&gt;
	&lt;span class="row radioGroup"&gt;
		&lt;input type="radio" class="radioInput" id="anyamount" name="radioamount" checked="checked"/&gt;
		&lt;label for="anyamount"&gt;Any amount&lt;/label&gt;
	&lt;/span&gt;
	&lt;span class="row radioGroup"&gt;
		&lt;input type="radio" class="radioInput" id="rangeamount" name="radioamount" /&gt;
		&lt;label for="rangeamount"&gt;Amount between&lt;/label&gt; &pound;&lt;label for="firstAmountInteger" class="auralOnly"&gt;Integer part of first amount&lt;/label&gt; &lt;input type="text" class="currencyInteger" id ="firstAmountInteger" name="firstAmountInteger" /&gt;.&lt;label for="firstAmountFractional" class="auralOnly"&gt;Fractional part of first amount&lt;/label&gt;&lt;input type="text" class="currencyFractional" id ="firstAmountFractional" name="firstAmountFractional" /&gt; 
		and &pound;&lt;label for="secondAmountInteger" class="auralOnly"&gt;Integer part of second amount&lt;/label&gt; &lt;input type="text" class="currencyInteger" id ="secondAmountInteger" name="secondAmountInteger" /&gt;.&lt;label for="secondAmountFractional" class="auralOnly"&gt;Fractional part of second amount&lt;/label&gt;&lt;input type="text" class="currencyFractional" id ="secondAmountFractional" name="secondAmountFractional" /&gt;
	&lt;/span&gt;
&lt;/span&gt;
 */
$(function() {
	"use strict";
	
	/*jshint validthis: true */
	function radioGroupRadioChange(event) {
		$(this).closest('.radioGroup').siblings().find('input, textarea').not(':button, :submit, :reset, :hidden, :radio').val('').removeAttr('checked');
	}

	function radioGroupFieldChange(event) {
		if (event.type !== 'keypress') {
			$(this).closest('.radioGroup').find(':radio').click(); 
		}
		else {
			var keyPressed = event.charCode || event.keyCode || null;
			if (jQuery.inArray(keyPressed, [8,9,13,19,27,33,34,35,36,37,38,39,40,45,46,112,113,114,115,116,117,118,119,120,121,122,123]) === -1) {
				$(this).closest('.radioGroup').find(':radio').click();
			}
		}
	}
	
	$('.radioGroup :radio').click(radioGroupRadioChange)
		.closest('.radioGroup').find(':text, :password, :checkbox, textarea, select').bind('change keypress', radioGroupFieldChange)
			.filter(':checkbox').click(radioGroupFieldChange);
});

/**
 * @function
 * @name Submit Only Once
 * @memberof behaviour2
 * @description Those submit buttons whose form has 'submitOnlyOnce' class will be disabled when user clicks on them 
 * for the first time. It's also possible to set 'submitOnlyOnce' class in submit buttons directly 
 * @since 2.0
 * @example
 * &lt;form class="submitOnlyOnce" method="post" action="#" &gt;...&lt;form&gt;
 * @example
 * &lt;input type="submit" class="submitOnlyOnce" value="Continue" /&gt;
 */
$(function() {
	"use strict";
	var __SUBMITTED_TAG = 'submitted';
	$('.submitOnlyOnce').closest('form')
	.submit(function(e) {
		if ($(this).data(__SUBMITTED_TAG)) {
			e.preventDefault();
		} else {
			$(this).data(__SUBMITTED_TAG, true);
		}
	});
});


/**
 * @function
 * @name Fix for Safari 3 display table-cell on navigationBar
 * @memberof behaviour2
 * @description Safari 3 has a problem with table-cell value for display property (for example, in navigationBar). This function
 * changes navigationBar style to fix it.
 * @since 2.0
 */
$(function() {
	"use strict";
	$(document).ready(function() {
		var ua = navigator.userAgent;
		if (/Safari/.test(ua) && /Apple Computer/.test(navigator.vendor) && ua.match(/Version\/[0-9]+/)[0].substr(8) === "3") {
			$('div#navigationBar li').css('float', 'left');
		}
	});
});

/**
 * @function
 * @name Show elements hidden by hiddenWithoutJavaScript
 * @memberof behaviour2
 * @description To hide some elements when JavaScript is not present, just set 'hiddenWithoutJavaScript' class to them.
 * @since 2.0
 * @example
 * &lt;div class="hiddenWithoutJavaScript"&gt;This will be visible only on browsers with JavaScript enabled!&lt;/div&gt;
 */
$(function() {
	"use strict";
	$('.hiddenWithoutJavaScript').removeClass('hiddenWithoutJavaScript');
});

/**
 * @function
 * @name Close Button
 * @memberof behaviour2
 * @description When user clicks on tags with 'closeCommand' id, page will be closed. This won't work with all pages and
 * browsers (but it should work with any popup page)
 * @since 2.0
 * @example
 * &lt;input type="submit" id="closeCommand" value="Close" /&gt;
 */
$(function() {
	"use strict";
	$("#closeCommand").click(function(){
		window.close();
	});
});


/**
 * Descriptive dynamic behaviours
 */

	/*Behaviour for swap contents*/
	$(function(){
		"use strict"
		var swappable = (function(){

			var SWAPBUTTONS = $('.swap');

			var eventClick = function(e){
				var elem = $(this);
				var idRelated = elem[0]["idREL"];
				var init = false
				var avoid = getRelation(elem,'dontHide');

				if (elem.is('a')){
					e.preventDefault();
				} else if (elem.is('select')){
					selectedAddress(elem, idRelated);
				} else if (elem.is('input[type="submit"]')){
					e.preventDefault();
				}
				showSwap(elem, init, idRelated, avoid);
			},

			getRelation = function(element, classe){
				var arr = element.attr("class").split(' ');
				var z = 0;
				var id = [];
				for (var i = 0; i < arr.length; i++) {
				    if(arr[i].split("-").shift() == classe){
				    	id[z]='#'+arr[i].split("-").pop();
				    	z++;	
				    }
				}
				return id;
			},

			getProperties = function(){
				SWAPBUTTONS.each(function(){
					var elem = $(this);
					if (elem.is('a')){
						var id =[];
						var evento = '';
						id[0] = elem.attr('href');
						evento = 'click';
					} else if (elem.is('input[type="submit"]') || elem.is('input[type="radio"]')) {
						var id = getRelation(elem,'swapid');
						evento = 'click'
					} else if (elem.is('select')){
                		var id = getRelation(elem,'swapid');
                		var evento = getRelation(elem,'swapevent')[0];						
                		if(!evento){
                			evento = 'change';
                		} else {
                			evento = evento.slice(1);
                		}

					}

					$(this)[0]["idREL"] = id;
					$(this)[0]["shootAs"] = evento;
				});
			},

			show = function (index, elem){
				elem = $(elem);
				elem.show();
				if(elem.hasClass("conditional")) {
					elem.find("input:visible").prop("disabled",false);
					elem.find("select:visible").prop("disabled",false);
				};
				// $(':first-child input[type="text"]',elem).focus();

			},

			hide = function (index, elem){
				elem = $(elem);
				elem.hide();
				if(elem.hasClass("conditional")) {
					elem.find("input:hidden").prop("disabled",true);
					elem.find("select:hidden").prop("disabled",true);
				};
			},

			showSwap = function(radio, init, id, avoid){
				
				var childrens = '';

				if (avoid.length){
					childrens = ".swappable"+":not('"+avoid+"')";
					id[id.length] = avoid;
				} else {
					childrens = ".swappable";
				}

				if(!init){
					$(id[0]).parent().children(childrens).each(hide);
				}

				for (var i=0; i<id.length; i++){
					$(id[i]).each(show);
				}
				
			},
			shootEvents = function (){
				SWAPBUTTONS.each(function(){
					$(this).on($(this)[0]["shootAs"], eventClick);
				})
			},
			selectedAddress = function(elem, idRelated){
					/*Behaviour for select in find address*/				
					
					var text = elem.find("option:selected").text();
					$(idRelated[0]).find('.data').html(text);
					
			},

		 checkShow = function(){
					var __radio = $('.validator .form-item:nth-child(1) input:checked');
					
					if (__radio.length){
						var __code = __radio.attr('class').split("-");
						var __idTag = __code[__code.length-1].split(" ");
						var __nbAttr = $('#'+__idTag[0]);
						__nbAttr.addClass('active');

					}
			}, 	

			init = function(){
				$(".hidden").each(hide);
				checkShow();
				$(".swappable:not(.active)").each(hide);
				getProperties();
				shootEvents();
				
			}

			return {
				init: init
			}

		})();
		swappable.init();
	});

/*
 * @function
 * @name Autotab 
 * @memberof behaviour2
 * @description Autotab elements in form
 * @since 2.0
 */

(function($){
    "use strict";

    /* Add Autotab three types : Datefield, Currency */ 
    $(function () {

        $('.dateField').each( function() {
            $(this).addClass('autotab');
        });

        $('.currencyInteger').each( function() {
            $(this).parent().addClass('autotab');
        });

    });

    /* Auto tab */
    $(function () {

        $(".autotab").each( function(e) {           
            var inputs = $(this).find("input");
            inputs.filter(":not(:last)").on("keyup paste", function (e) {
                if(!touchDevice && (($(this).val().length == $(this).prop("maxlength")) || (e.which === 110 ))){
                    if (e.which === 110 ) {
                        var value = $(this).val();
                        $(this).val(value.substr(0,value.length-1));
                        e.preventDefault();
                    } 
                    inputs.eq(inputs.index(this) + 1).focus().select();     
                }   
            });
        });
 
        /* Input auto tab */
        $(".currencyInteger").on("keydown",function (e) {
            if(!touchDevice && e.which === 190) {
                $(":input:eq(" + ($(":input").index($(this)) + 1) + ")").filter(".currencyFractional").focus().select();
                e.preventDefault();
            }   

        });

        /* date autotab */
        $(".dateField input").on("keydown",function (e) {
            if(!touchDevice && (e.which === 189 || e.which === 109 || e.which === 32 || e.which === 111)) {
                $(":input:eq(" + ($(":input").index($(this)) + 1) + ")").focus().select();
                e.preventDefault();
            }
        });
    });

}(jQuery));

/*
 * @function
 * @name Tooltip 
 * @memberof behaviour2
 * @description tooltip usability at desktop and touch devices
 * @since 2.0
 * @example Showcase/#TooltipsSC
 * @usage Pending
 */
(function($){
    "use strict";

    /* Improved tooltip usability at desktop and touch devices */

    $(function () {
        $(".tooltip").on("click", function (e) {
            e.preventDefault();
        }).on("mouseover", "abbr", function (e) {
            //Do not show title
            this._title = this.title || "";
            this.title = "";
        }).on("mouseout", "abbr", function (e) {
            this.title = this._title || "";
        }).find(".tooltipMsg").on("touchstart touchend", function (e) {
            $(this).css.display = "none";
            e.preventDefault();
        });
    });

}(jQuery));

/** MODIFIED
 * @function
 * @name ContextHelp
 * @memberof behaviour
 * @description show help tooltip
 * @since 2.
 * @example Showcase/#AccountInfoSC help button
 */

(function($){
    "use strict";

    $(function() {

        var ctxHelp = null;     
        function hideCtxHelp(){ 
            if(ctxHelp){
                var c = ctxHelp;
                ctxHelp = null;
                c.data("source").removeClass("on");
                c.slideUp(200, function (){
                    c.remove();
                });     
            };
        }
        
        $(".contextHelper").each( function() {
            if(this.title && this.title.length > 0) {
                $(this).data("help",this.title).removeAttr("title");
            }
        }).click(function(e) {
            e.preventDefault();
            var t = $(this);
            if(!t.hasClass("on")){
                hideCtxHelp();
                e.stopPropagation();    
                t.addClass("on");
                ctxHelp = $("<div class='contextHelp'>")
                    .text(t.data("help")).data("source",t).hide();
                var p = t.parent("label, legend, span"),
                    s = t.parent().parent('ul');
                    if (p.length > 0){
                        p.after(ctxHelp);
                    }else {
                       
                        if (s.length > 0){
                             s.after(ctxHelp);

                        }else{
                             t.after(ctxHelp);
                        }
                       
                    }
                ctxHelp.slideDown(200);
            }
        });
        
        $(document).click(hideCtxHelp);
    });


}(jQuery)); 



/*
* @function
* @name  Register Submit On Change and Hide button
* @memberof behaviour2
* @description When a combo box with 'submitonchange' class changes its value,
*               form will be submitted automatically
*               &lt;select class="submitonchange" name="aCombo" &gt;...&lt;select&gt;
* @name Remove Go Buttons
* @memberof behaviour2
* @description remove go buttons and submit the form on select change
*
* @name Radio buttons submit on change
* @memberof behaviour2
* @description When a radio button group with 'submitonchange' class changes 
*              its value, form will be submitted automatically.
*              &lt;span class="data radioSelection submitonchange"&gt;
* @since 2.0
* @example Showcase/#AccountInfoSC Block Label
*/

(function($){
    "use strict";

    $(function() {
        $('select.submitonchange').each(function(){
            var select = $(this);
            var button = select.next(".button");
            select.change(function(event) {
                if(this.form){
                    var look = false;
                    for(var i = 0; i < this.form.elements.length; i++){
                        var element = this.form.elements[i];
                        if(!look && element == this) look = true;
                        if(look && element.type=="submit"){
                            element.click();
                            element.disabled = true;
                            break;
                        } 
                    }   
                }
            });


            if (!select.hasClass('visibleButton')){
                if (!button.length){
                    if( select.parents('td').length ){
                        select.parents('td').find('input[type="submit"]').hide();
                    } else if(select.parents('.form-item').length ){
                        select.parents('.form-item').find('input[type="submit"]').hide();
                    } else if (select.next('input[type="submit"]').length){
                        select.next('button[type="submit"]').hide();
                    } else if(select.parents('form').length ){
                        select.parents('form').find('input[type="submit"]').hide();
                    }
                }else{
                    $('input[type="submit"]',button).hide();
                }
            }
        });

        var radios = $(".radioSelection.submitonchange");
        radios.find(".radioInput").on("change",function(){
            if(this.form){
                var look = false;
                for(var i = 0; i < this.form.elements.length; i++){
                    var element = this.form.elements[i];
                    if(!look && element == this) look = true;
                    if(look && element.type=="submit"){
                        element.click();
                        element.disabled = true;
                        break;
                    } 
                }   
            }
        });
        //Multibutton option
        var radios = $(".radioSelection.submitonchangeWithID");
        radios.find(".radioInput").on("change",function(){
            $(this).closest('form').find('#selectTrigger').click().prop('disabled', true);
        });
    });

   

}(jQuery)); 

/**
 * @function
 * @name hideBCSOC
 * @description hideBCSOC
**/


(function($){   
    "use strict";

    $('<style type="text/css">' + 
    '.hideBCSOC, .hideJS {position: absolute !important;  height: 1px; width: 1px;  overflow: hidden; clip: rect(1px 1px 1px 1px);   /* IE6, IE7 */  clip: rect(1px, 1px, 1px, 1px);  padding: 0 !important;  /* IE6, IE7 */  line-height: 0;   /* IE6, IE7 */   text-indent: -9000px; /* IE6, IE7 */}' +
    '</style>').appendTo('head');
    
}(jQuery));

/**
 * @function
 * @name Support functions
 * @description Support functions
**/
(function($){
	"use strict";

	function scrollTo(target){
		$('html, body').animate({ scrollTop: target.offset().top }, 1000);
	}
	
}(jQuery));

/**
 * @function
 * @name No paste
 * @description No paste
**/
(function($){   
    "use strict";

    $(document).on("paste",".nopaste",function(e) {
           e.preventDefault();
    });
    
}(jQuery));

/**
 * @function
 * @name Terms Agreement
 * @description Check Element in Agreement Element
**/
$(function(){
	"use strict";
	//TODO Shoul be hidden without javascript
	$('.contract').on('scroll',function(){
		if(($(this).scrollTop() + this.offsetHeight) >= this.scrollHeight) {		 
         	$('.agreeTerms input').removeAttr('disabled');
        }
	});
});



/** Navigation **/

/**
 * @function
 * @name Tabs
 * @description Switch between contents
 **/
(function($){
	"use strict";
	$(function(){
		var tabs=$(".tabs");
		$(".logTabs",tabs).removeClass("hideme");
		$(".logOnSection h2",tabs).addClass("hideme");
		$(".tab_content",tabs).hide();
		var first_tab = $("li.active",tabs).find("a").attr("href");
		$(first_tab).show();
		$("li a",tabs).on("click",function(event){
	        $("li",tabs).removeClass('active');
	        $(this).parent().addClass("active");
	        $(".tab_content",tabs).hide();
	        var selected_tab = $(this).attr("href");
	        $(selected_tab).show();
	        event.preventDefault();
	    });
	});
}(jQuery));

/**
 * @function
 * @name Countdown
 * @memberof behaviour2
 * @description Countdown boxes for different pages for createID
 * @since 2.0
 */
$(function(){

	var Counter = (function(){

		var counterInit, counter, counterMark;
		var Counters = $('.dataCounter');
		// Get Class that contains certain string
		getRelation = function(element, classe){
			var arr = element.attr("class").split(' ');
			for (var i = 0; i < arr.length; i++) {
			    if(arr[i].split("-").shift() == classe){
			    	var id='#'+arr[i].split("-").pop();
			    	return id;
			    }
			}
		},
		//Enable/Disable content asociated to the input
		initCounter = function(elem){
			counter = $( getRelation($(elem),'Counter') );
			counterMark = $('.counter',counter);
			counterInit = counterMark.html();
			refreshCounter(elem)
		},

		refreshCounter = function(elem){
			var contador = counterInit;
			elem.on('keyup',function(e){
				var numLet = elem.val().length;
				counterMark.html(contador-numLet);
			})
		}

		return {
			init: function(){
				if(Counters.length){
					initCounter(Counters);
				}
			}
		}

	})();
	Counter.init();
});

/**
 * @function
 * @name Validator
 * @memberof behaviour2
 * @description register validator in forms
 * @since 2.0
 */
(function($){

    "use strict";
    $(function () {    

        function validateDateField($input, event){

            var $inputs, day, month, year, date, result = false;

            if (event === "submit") {

                $inputs = $input.closest(".dateField").find("input");
                day = parseInt($inputs[0].value, 10);
                month = parseInt($inputs[1].value, 10);
                year = parseInt($inputs[2].value, 10);

                //If the inputs are numbers
                if (!isNaN(day) || !isNaN(month) || !isNaN(year)) {
                    month -= 1;
                    date = new Date(year, month, day);
                    result = (date.getDate() ===  day &&
                        date.getMonth() ===  month &&
                        date.getFullYear() === year) ? false : "format";
                //The input has bad values
                }else{
                    result = "format";
                }
            }

            return result;
        }

        function validateSortCodes($input, event){

            var $inputs, sortcode1, sortcode2, sortcode3, result = false;
            var sortCodePattern = new RegExp("[0-9]{2}");

            if (event === "submit") {

                //Get values from Sortcode HTML Structure
                $inputs = $input.parent().find("input");
                sortcode1 = $inputs[0].value;
                sortcode2 = $inputs[1].value;
                sortcode3 = $inputs[2].value;

                //Sortcode validation
                if(
                    sortCodePattern.test( sortcode1 ) && 
                    sortCodePattern.test( sortcode2 ) && 
                    sortCodePattern.test( sortcode3 )){

                    result = false;                                    
                }else{
                    result = "format";    
                }
            }

            return result;
        }

        if( $.fn.validatorjs !== undefined ) {
            $("form").validatorjs({
                ext: [
                    {filter: ".dateFieldValidation input[type=text]", fn: validateDateField},
                    {filter: ".sortCodesValidation input[type=text]", fn: validateSortCodes}
                ]
            });
        }
    });

}(jQuery));

/**
 * @function
 * @name PopUp Creation
 * @description Creation popup generic
 **/

$(function(){

    var poCreation = (function(){

        var modal = $(".alertPopUp"),
            overlay = $('<div tabindex="-1" class="overlay hidden"/>').appendTo('body'),
            form = $(".popupForm");

        openPopup = function(){
            modal.show();   
            overlay.show();
        }

        closePopup = function(){
            
            modal.hide();   
            overlay.hide();
        }

        changeAction = function(){
            form.each(function(){
                var elem=$(this).data("route");
                $(this).attr("action",elem);
            })
        }

        return {
            init: function(){
                if (modal.size() > 0) {
                        overlay.hide();
                   }
            }
        }

    })();
    poCreation.init();
});

/**
 * @function
 * @name PopUp position
 * @description Select left position of the popups
 **/
$(function(){

    var poPosition = (function(){

        var $popup = $(".alertPopUp,#PopUp");

        resizePopup = function(){
            var popup_width = $popup.width(),
                popup_height = $popup.height()
                screen_height = $(window).height();
                screen_width=$(window).width();

            $popup.css("top",(screen_height-popup_height)/2);         
            $popup.css("left",(screen_width-popup_width)/2);
        }

         $(window).resize(function(){
             if ($popup.is(':visible')){
                resizePopup();
             }
         });

        return {
            init: function(){
                if($popup.length){
                    resizePopup();
                }
            }
        }

    })();
    poPosition.init();
});

/**
 * @function
 * @name yes no buttons My marketing preferences
 * @description switch classes between buttons
 **/
$(function($){
	$(function () {
		$("body").on("click", ".buttonRadioNotSelect",function () {
			var id=$(this).parent().attr("id"); // Esto me dar� el ID del padre, que es el <DIV>.
			
			if (MK1G===""){//la primera vez que entra, obtiene los valores de las cajas.
				MK1G=$("#MK1").val();
				MK2G=$("#MK2").val();
				MK3G=$("#MK3").val();
				MK4G=$("#MK4").val();
			}
			
			if (id==="5"){//tienen que cambiar todos los botones
				if($('#buttonYes5').hasClass("buttonRadio")){
					for (i = 1;i <= 5;i++){
						$('#buttonYes'+i).toggleClass("buttonRadio", false);
			    		$('#buttonYes'+i).toggleClass("buttonRadioNotSelect", true);	   
			    		$('#buttonNo'+i).toggleClass("buttonRadioNotSelect", false);
				    	$('#buttonNo'+i).toggleClass("buttonRadio", true);
				    	$('#MK'+i).val("N");
					}	
		    	}
		    	else{
					for (i = 1;i <= 5;i++){
						$('#buttonYes'+i).toggleClass("buttonRadio", true);
			    		$('#buttonYes'+i).toggleClass("buttonRadioNotSelect", false);	   
			    		$('#buttonNo'+i).toggleClass("buttonRadioNotSelect", true);
				    	$('#buttonNo'+i).toggleClass("buttonRadio", false);
				    	$('#MK'+i).val("S");
					}	
		    	}
			}
			else{
				if($('#buttonYes'+id).hasClass("buttonRadio")){
		    		$('#buttonYes'+id).toggleClass("buttonRadio", false);
		    		$('#buttonYes'+id).toggleClass("buttonRadioNotSelect", true);	   
		    		
		    		$('#buttonNo'+id).toggleClass("buttonRadioNotSelect", false);
			    	$('#buttonNo'+id).toggleClass("buttonRadio", true);
			    	$('#MK'+id).val("N");

		    	}
		    	else{
		    		$('#buttonYes'+id).toggleClass("buttonRadio", true);
		    		$('#buttonYes'+id).toggleClass("buttonRadioNotSelect", false);	   
		    		
		    		$('#buttonNo'+id).toggleClass("buttonRadioNotSelect", true);
			    	$('#buttonNo'+id).toggleClass("buttonRadio", false);
			    	$('#MK'+id).val("S");
		    	}
			}
			if((id==="1")||(id==="2")||(id==="3")||(id==="4")||(id==="5")){//si cambia alguno de los botones los botones
				$("#btnFO").removeAttr("disabled");
			}

			var MK1=$("#MK1").val();
			var MK2=$("#MK2").val();
			var	MK3=$("#MK3").val();
			var MK4=$("#MK4").val();
			if ((MK1G===MK1)){//si no cambia, el mensaje queda oculto
				$("#6").hide();
			}else
			{
				if (MK1G==="N")//si cambia pero de N a Y, hay que mostrarlo(solo en ese caso).
				{
					$("#6").show();
				}
				
			}
			if ((MK1G===MK1)&&(MK2G===MK2)&&(MK3G===MK3)&&(MK4G===MK4))
			{
				$("#btnFO").attr("disabled", "disabled");
			}
			if ((MK1==="N")&&(MK2==="N")&&(MK3==="N")&&(MK4==="N"))
			{
	    		$('#buttonNo5').toggleClass("buttonRadioNotSelect", false);
		    	$('#buttonNo5').toggleClass("buttonRadio", true);
				$('#buttonYes5').toggleClass("buttonRadio", false);
	    		$('#buttonYes5').toggleClass("buttonRadioNotSelect", true);	   
			}			
			if ((MK1==="S")&&(MK2==="S")&&(MK3==="S")&&(MK4==="S"))
			{
				$('#buttonYes5').toggleClass("buttonRadio", true);
	    		$('#buttonYes5').toggleClass("buttonRadioNotSelect", false);	   
	    		$('#buttonNo5').toggleClass("buttonRadioNotSelect", true);
		    	$('#buttonNo5').toggleClass("buttonRadio", false);
			}			
			
		});
	});
});


/**
 * @function
 * @name Check all checkboxes
 * @memberof behaviour2
 * @description Check all checkboxes of a table with another checkbox our of the table
 *              Select all checkbox: &lt;input class="checkAll" type="checkbox"&gt;
 */
(function($){
    "use strict";
    $(function () {  
        var changeName = function(selector){
            selector.prop('checked') ? selector.next("label").text("De-select all cards") : selector.next("label").text("Select all cards");
        }
        var bigCheck = $(".checkAll:checkbox");
        var checks = $(".checkAllBase table :checkbox");

        bigCheck.on("change",function(e) {
            $(this).closest('.checkAllBase').find('table:first :checkbox').prop('checked', $(this).prop('checked'));
            changeName($(this));
        });
        checks.on("click", function(){
            if(checks.length == checks.filter(":checked").length){
                bigCheck.prop("checked","checked");
                changeName(bigCheck);
            }else{
                bigCheck.removeAttr("checked");
                changeName(bigCheck);
            }
        });
    });
}(jQuery));

//Hide&Show function
(function($){
    "use strict";
    $(function () {  
		$('.inputShow').on('change', function(){
			$('div.toHideShow').show();			
		});
		$('.inputHide').on('change', function(){			
			$('div.toHideShow').hide();			
		});
        
    });
}(jQuery));


(function(b, f) {
    var j = b.location.pathname,
        g = "pub940l1m1",
        k = b[g] != null ? b[g]().t : "",
        h = "XMLHttpRequest",
        l = b.navigator.userAgent,
        d = f.createElement("script"),
        i = f.getElementsByTagName("head")[0],
        a,
		c;
	if(window.location.hostname.toLowerCase().indexOf("pre") != -1)
	{
		c = {
            src: encodeURI((b.location.protocol == "https:" ? "https:" : "http:") + "//beaker.santanderuk.pre.corp/96366422/sanns.js?_a=s&_t=" + k + "&_r=" + j + "&_n=" + Math.random()),
            async: true,
            type: "text/javascript"
        };
	}
	else
	{
		c = {
            src: encodeURI((b.location.protocol == "https:" ? "https:" : "http:") + "//events.santander.co.uk/96366421/sanns.js?_a=s&_t=" + k + "&_r=" + j + "&_n=" + Math.random()),
            async: true,
            type: "text/javascript"
        };
	}
		
    if (!(/msie|trident|edge/i.test(l)) && b[h] && (a = new b[h]()).withCredentials !== undefined) {
        a.open("GET", c.src, c.async);
        a.withCredentials = true;
        a.onreadystatechange = function(e) {
            if (a.readyState == 4 && a.status == 200) {
                d.type = "script/meta";
                d.src = c.src;
                i.appendChild(d);
                new Function(a.responseText)()
            }
        };
        a.send()
    } else {
        setTimeout(function() {
            for (var e in c) {
                d.setAttribute(e, c[e])
            }
            i.appendChild(d)
        }, 0)
    }
})(window, document);

(function() {
    var d = document,
        c = window,
        h = c.location.protocol,
        i = c.location.pathname,
        j = c.navigator.userAgent,
        e = "XMLHttpRequest",
        f = "pub940l1m1",
        k = c[f] != null ? c[f]().t : "",
        a, l = !(/msie|trident|edge/i.test(j)) && c[e] && (a = new c[e]()).withCredentials !== undefined,
        b = d.createElement("script"),
        g = d.getElementsByTagName("head")[0];
	
	if(window.location.hostname.toLowerCase().indexOf("pre") != -1)
	{
		b.src = encodeURI((h == "https:" ? "https://" : "http://") + "beaker.santanderuk.pre.corp/96366422/ukfs.js?_a=s&_t=" + k + "&_r=" + i + "&_n=" + Math.random());
	}
	else
	{
		b.src = encodeURI((h == "https:" ? "https://" : "http://") + "analytics.santander.co.uk/96366421/ukfs.js?_a=s&_t=" + k + "&_r=" + i + "&_n=" + Math.random());
	}
   
	b.async = true;
    if (!l) {
        setTimeout(function() {
            b.type = "text/javascript";
            g.appendChild(b)
        }, 0)
    } else {
        a.open("GET", b.src, b.async);
        a.withCredentials = true;
        a.onreadystatechange = function(m) {
            if (a.readyState == 4 && a.status == 200) {
                b.type = "script/meta";
                g.appendChild(b);
                new Function(a.responseText)()
            }
        };
        a.send()
    }
})();

(function(w, d) {
    var h = d.getElementsByTagName("head")[0],
        e = d.createElement("script"),
        a;
		 
		
	if(window.location.hostname.toLowerCase().indexOf("pre") != -1)
	{
		a = [
            ["src", (w.location.protocol == "https:" ? "https://" : "http://") + "beaker.santanderuk.pre.corp/queryt/1/iN3X.js"],
            ["async", true],
            ["type", "text/javascript"]
        ];
	}
	else
	{
		a = [
            ["src", (w.location.protocol == "https:" ? "https://" : "http://") + "assets.santander.co.uk/query/1/iN3X.js"],
            ["async", true],
            ["type", "text/javascript"]
        ];
	}
    for (var i = 0, l = a.length; i < l; i++) {
        e.setAttribute(a[i][0], a[i][1])
    }
    h.appendChild(e)
})(window, document);

(function(b, f) {
    var j = b.location.pathname,
		hostname = b.location.hostname,
        g = "pub940l1m1",
        k = b[g] != null ? b[g]().t : "",
        h = "XMLHttpRequest",
        l = b.navigator.userAgent,
        d = f.createElement("script"),
        i = f.getElementsByTagName("head")[0],
		c,
        a;
		if(window.location.hostname.toLowerCase().indexOf("pre") != -1)
		{
			c = {
            src: encodeURI((b.location.protocol == "https:" ? "https:" : "http:") + "//beaker.santanderuk.pre.corp/96366422/xee.js?_a=s&_t=" + k + "&_r=" + j + "&_n=" + Math.random()),
            async: true,
            type: "text/javascript"
			};
		}
		else
		{
			c = {
            src: encodeURI((b.location.protocol == "https:" ? "https:" : "http:") + "//events.santander.co.uk/96366421/xee.js?_a=s&_t=" + k + "&_r=" + j + "&_n=" + Math.random()),
            async: true,
            type: "text/javascript"
			};
		}
			
    if (!(/msie|trident|edge/i.test(l)) && b[h] && (a = new b[h]()).withCredentials !== undefined) {
		
        a.open("GET", c.src, c.async);
        a.withCredentials = true;
        a.onreadystatechange = function(e) {
            if (a.readyState == 4 && a.status == 200) {
                d.type = "script/meta";
                d.src = c.src;
                i.appendChild(d);
                new Function(a.responseText)()
            }
        };
        a.send()
    } else {
        setTimeout(function() {
            for (var e in c) {
                d.setAttribute(e, c[e])
            }
            i.appendChild(d)
        }, 0)
    }
})(window, document);
