// Frame killer
try {
	if (top != self) top.location.replace(location);
} catch (e) {}
