<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package thim
 */
?>
<footer id="footer" class="site-footer" role="contentinfo">
	<?php global $theme_options_data; ?>

	<?php if ( is_active_sidebar( 'footer' ) ) :
		$footer_boxed  = '';
		$footer_border = '';
		if ( isset( $theme_options_data['thim_footer_box_layout'] ) && $theme_options_data['thim_footer_box_layout'] == "boxed" ) {
			$footer_boxed = " boxed-area";
		}
		if ( isset( $theme_options_data['thim_show_border_column'] ) && ( $theme_options_data['thim_show_border_column'] == true ) ) {
			$footer_border = " show-border";
		}
		?>
		<div class="footer<?php echo esc_attr( $footer_boxed );
		echo esc_attr( $footer_border ); ?>">
			<div class="container">
				<div class="row contact">
					<?php dynamic_sidebar( 'footer' ); ?>
				</div>
			</div>
		</div>
	<?php endif; ?>
	<!--==============================powered=====================================-->
	<?php if ( isset( $theme_options_data['thim_copyright_text'] ) || is_active_sidebar( 'copyright' ) ) { ?>
		<div id="powered">
			<div class="container">
				<div class="row contact">

					<?php if ( is_active_sidebar( 'copyright' ) ) : ?>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 payment">
							<?php dynamic_sidebar( 'copyright' ); ?>
						</div><!-- col-sm-6 -->
					<?php endif; ?>
					<?php
					if ( isset( $theme_options_data['thim_copyright_text'] ) ) {
						echo '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 copyright">';
						echo ent2ncr($theme_options_data['thim_copyright_text']);
						echo '</div>';
					}
					?>
				</div>
			</div>
		</div>
	<?php } ?>
	<a class="footer-call" href="tel:+5712324345" style=""><span class="pe-7s-phone"></span>Llámanos Ahora</a>
</footer><!-- #colophon -->
</div></div><!-- .wrapper-container -->
<!-- .box-area -->
<?php if ( isset( $theme_options_data['thim_show_to_top'] ) && $theme_options_data['thim_show_to_top'] == 1 ) { ?>
	<a id='topcontrol' class="scrollup show" title="<?php esc_attr_e( 'Go To Top', 'thim' ); ?>"><?php esc_attr_e( 'Go To Top', 'thim' ); ?></a>
<?php } ?>

<?php if ( isset( $theme_options_data['thim_box_layout'] ) && $theme_options_data['thim_box_layout'] == "boxed" ) {
	echo '</div>';
} ?>

<?php if ( isset( $theme_options_data['thim_show_offcanvas_sidebar'] ) && $theme_options_data['thim_show_offcanvas_sidebar'] == '1' && is_active_sidebar( 'offcanvas_sidebar' ) ) { ?>
	<div class="slider-sidebar">
		<?php dynamic_sidebar( 'offcanvas_sidebar' ); ?>
	</div>  <!--slider_sidebar-->
<?php } ?>
<?php wp_footer(); ?>
</body>
</html>

