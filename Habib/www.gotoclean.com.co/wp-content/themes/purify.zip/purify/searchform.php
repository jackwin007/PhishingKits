<form id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
    <input id="s" type="text" name="s" placeholder="Search"/>
    <button type="submit" id="submit"><i></i></button>
    <input type="hidden" name="post_type" value="post" />
</form>

