<div id="header-search-form-input" class="main-header-search-form-input">
	<div class="container">
		<form role="search" method="get" action="#">
			<input type="text" value="" name="s" id="s" placeholder="<?php echo __( 'Search the site or press ESC to cancel', 'montana' ); ?>" class="form-control ob-search-input" autocomplete="off" />
			<span class="header-search-close"><i class="fa fa-times"></i></span>
		</form>
		<ul class="ob-list-search">
		</ul>
	</div>
</div>