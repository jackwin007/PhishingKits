<?php
$url = TP_THEME_URI . 'images/admin/layout/';
$woocommerce = $titan->createThimCustomizerSection( array(
	'name'     => 'Woocommerce',
	'position' => 5,
 	'id'       => 'woocommerce',
) );