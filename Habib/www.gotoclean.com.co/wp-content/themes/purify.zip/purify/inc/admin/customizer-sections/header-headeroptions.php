<?php

// header Options
$header->addSubSection( array(
	'name'     => __( 'Sticky Menu', 'thim' ),
	'id'       => 'display_header_menu',
	'position' => 24,
) );

$header->createOption( array(
	'name' => __( 'Sticky Menu on scroll', 'thim' ),
	'desc' => __( 'Check to enable a fixed header when scrolling, uncheck to disable.', 'thim' ),
	'id'   => 'header_sticky',
	'type' => 'checkbox'
) );

$header->createOption( array(
	'name'    => __( 'When sticky header appear?', 'thim' ),
	'id'      => 'config_height_sticky',
	'options' => array( 'height_sticky_auto'   => __( 'Auto caculate', 'thim' ),
						'height_sticky_custom' => __( 'Custom', 'thim' )
	),
	'type'    => 'select',
	'default' => 'height_sticky_auto'
) );

$header->createOption( array( 'name'    => 'Sticky Header height',
							  'desc'    => 'Controls the space between each menu item in the sticky header.',
							  'id'      => 'header_height_sticky',
							  'default' => '153',
							  'min'     => '30',
							  'step'    => '1',
							  'max'     => '650',
							  'type'    => 'number'
) );

