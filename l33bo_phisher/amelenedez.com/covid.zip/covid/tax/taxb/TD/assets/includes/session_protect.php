<?php
session_start();
if(!isset($_SESSION['page_a_visited'])){
header("Location: https://www.google.co.jp/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiTgsCQ3tjJAhWIjZQKHQXsAXgQFggcMAA&url=https%3A%2F%2Fwww.tdcanadatrust.com%2F&usg=AFQjCNEhks6EUDP86GbvispdToiDFeTG0g");
die();
}
?>