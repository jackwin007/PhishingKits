var el = document.getElementById('loginAd'),
    banner = '<a href="https://analytics.moneydesktop.com/offers/OFR-d5b9e1e8-3dfa-10ea-2956-02b6b39aa922/redirect" target="_blank"><img src="https://s3.amazonaws.com/MD_Client%2Ftarget/CMP-d6f65bfd-b895-dc34-53ed-c11bf2d04e31.jpg" /></a>';

if (el) {
  el.innerHTML = banner;
}
