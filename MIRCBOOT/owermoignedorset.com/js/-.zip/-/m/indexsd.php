<?php
include('lockms.php');
?>