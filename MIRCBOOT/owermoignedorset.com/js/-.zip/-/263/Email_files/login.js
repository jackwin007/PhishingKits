function checkForm(){
	if($.trim($("input[name=login]").val()) == ""){
		alert("登录名不能为空");
		$("input[name=login]").focus();
		return false;
	}
	if($.trim($("input[name=pass]").val()) == ""){
		alert("登录密码不能为空");
		$("input[name=pass]").focus();
		return false;
	}
	return true;
}
function login(){
	try
	{
		if(checkForm()){
			document.loginform.action = "process.php?_t="+Math.random();//同步盘线上环境
			
			$("#loginform").submit();
		}else{
			return false;
		}
	}catch(e){
		alert(e.message); 
	}
}