<?php



function generateRandomString($length = 7) {

    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    $charactersLength = strlen($characters);

    $randomString = '';

    for ($i = 0; $i < $length; $i++) {

        $randomString .= $characters[rand(0, $charactersLength - 1)];

    }

    return $randomString;

}





$rands= generateRandomString();

 //dirname(__FILE__)

 //basename(__DIR__)

 //getcwd()

 

$cur_dir = explode('\\',basename(__DIR__));

$load= $cur_dir[count($cur_dir)-1];



if(isset($_POST['export']))

{

//if ($_SESSION['logged'] != 'yes') exit();

header("Content-Type: text/plain");

header("Content-Disposition: Attachment; filename=spirit.txt");

header("Pragma: no-cache");





 exit;

}







//password change

//password change code here

 







?>

﻿<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

      <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Code~Spirit Web Panel</title>

	<!-- BOOTSTRAP STYLES-->

    <link href="../admin/assets/css/bootstrap.css" rel="stylesheet" />

     <!-- FONTAWESOME STYLES-->

    <link href="../admin/assets/css/font-awesome.css" rel="stylesheet" />

     <!-- MORRIS CHART STYLES-->

    <link href="../admin/assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />

        <!-- CUSTOM STYLES-->

    <link href="../admin/assets/css/custom.css" rel="stylesheet" />

     <!-- GOOGLE FONTS-->

   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">

            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </button>

                <a class="navbar-brand" href="../admin/index.php">Code~Spirit</a> 

            <div style=" text-transform:uppercase; color: white;

padding: 10px 10px 5px 10px;

float: right;

font-size: 30px;"><?=$adminuser;?> </div>



</div>

          <div style="color: white; margin-right:50px;

padding: 15px 50px 5px 50px;

float: right;

font-size: 16px;"><a href="../admin/?log=logout" class="btn btn-danger square-btn-adjust">Logout</a> </div>









     </nav>   

           <!-- /. NAV TOP  -->

                <nav class="navbar-default navbar-side" role="navigation">

            <div class="sidebar-collapse">

                <ul class="nav" id="main-menu">

				<li class="text-center">

                    <img src="https://d13yacurqjgara.cloudfront.net/users/365895/screenshots/2260681/20150924-072413-800x600px-icd10spiritanimalcode-bittenbypig_1x.png" class="user-image img-responsive"/>

					</li>

				            <li>

                        <a  href="home.php"><i class="fa fa-dashboard fa-3x"></i><strong> HOME</strong></a>

                    </li>

					

                    <li>

                         <a href="../turbomail.php?suces=Your Page Has Been Cryted !&new=<?=$load;?>&old=<?=$load;?>"><i class="fa fa-dashboard fa-3x"></i> <strong>Biuld English Only</strong></a>

                    </li>

                     <li>

                        <a href="../turbomail-cn.php?suces=Your Page Has Been Cryted !&new=<?=$load;?>&old=<?=$load;?>"><i class="fa fa-desktop fa-3x"></i> <strong>Biuld China Only</strong></a>

                    </li>

                    <li>

                        <a  href="../KlVEMcK/home.php"><i class="fa fa-qrcode fa-3x"></i> <strong>Randomize Crypt</strong></a>

                    </li>

                    <li style="margin:40px 0px 0px 50px;">

                         <strong>   <form id="form1" name="form1" method="post" action="../cryptp.php">

 <input name="oldcrypt" type="hidden" value="<?=$load;?>" /> 

<input name="newcrypt" type="hidden" value="<?= $rands;?>" /> 

<label>

          <input class="fa-bolt" type="submit" name="crypt" id="crypt" value="Crypt & Biuld " />

      </label></form>

</strong> 

                    </li>

						                 

					                   

                    

                </ul>

               

            </div>

            

        </nav>  

        <!-- /. NAV SIDE  -->

        <div id="page-wrapper" >

            <div id="page-inner">

                <div class="row">

                    <div class="col-md-12">

                     <h2>Admin Dashboard</h2>   

                        <h5>Welcome, love to see you back. </h5>

                    </div>

                </div>              

                 <!-- /. ROW  -->

                  <hr />

                <div class="row"></div>

<div class="row">

                <div class="col-md-12">

                   

			<!-- Advanced Tables -->

                    <div class="panel panel-default">

                        <div class="panel-heading">

                           Notifications from Computers

                        </div>

                        <div align="center" class="panel-body">

                            <div class="table-responsive">

                                <div style="width:700px;"><h2>Page Control Panel</h2>



 <table width="100%" bordercolorlight="#666666" border="1" cellspacing="5" cellpadding="5">

    <tr>

      <th width="150px"  scope="col">Page Domain Name : </th>

      <th scope="col"><?=$_SERVER['HTTP_HOST'];

	  ?></th>

     </tr>

    <tr>

      <th scope="col">  Current Crypt Code:</th>

      <th scope="col"><?=$load;?></th>

     </tr>

    <tr>

      <th scope="col"> New Crypt Code: </th>

      <th scope="col">

      <?= $rands;?></th>

      

    </tr>  

      <tr>

      <th scope="col">Old Pass Code</th> 

      <th scope="col"><?=$load;?></th> 

      </tr>

      <tr>

      <th scope="col">New Pass Code</th> 

      <th scope="col"><?= $rands;?></th> 

      </tr>

      <tr>

 

      <th scope="col">

        

      </th> 

      <th scope="col">  </th>

      </tr>

  </table>    <div style="color:#F00; font-size:24px">NOTE! When ever you CLICK On CRYPT AND BIULD, Please make sure you copy your New Pass Code ( <?= $rands;?> )  To login In Feature <br/> This is for your Own Security.</div>

</div>

                            </div>

                        </div>

                    </div>

<!--End Advanced Tables -->

                   </div>

			</div>

                

			</div>



                      

    </div>

             <!-- /. PAGE INNER  -->

            </div>

         <!-- /. PAGE WRAPPER  -->

        </div>

     <!-- /. WRAPPER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->

    <!-- JQUERY SCRIPTS -->

    <script src="../admin/assets/js/jquery-1.10.2.js"></script>

      <!-- BOOTSTRAP SCRIPTS -->

    <script src="../admin/assets/js/bootstrap.min.js"></script>

<script>

            $(document).ready(function () {

                $('#Notifications').dataTable();

            });

    </script>

    <!-- METISMENU SCRIPTS -->

    <script src="../admin/assets/js/jquery.metisMenu.js"></script>

     <!-- MORRIS CHART SCRIPTS -->

     <script src="../admin/assets/js/morris/raphael-2.1.0.min.js"></script>

    <script src="../admin/assets/js/morris/morris.js"></script>

      <!-- CUSTOM SCRIPTS -->

    <script src="../admin/assets/js/custom.js"></script>

     

   

</body>

</html>