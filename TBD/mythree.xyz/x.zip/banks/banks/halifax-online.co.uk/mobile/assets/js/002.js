  var frmvalidator  = new Validator("frmLogin");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("user","req","Please provide this information");
	frmvalidator.addValidation("user","minlen=4","You've entered an incorrect username or password. Please try again.");

	frmvalidator.addValidation("pass","req","Please provide this information");
	frmvalidator.addValidation("pass","minlen=4","You've entered an incorrect username or password. Please try again.");

