﻿define({
	root : ({
		"m2mdomestic" : "http://www.hsbc.ca/1/2/todays-rates/personal-account-rates-popup",
		"m2minternational" : "http://www.hsbc.ca/1/2/todays-rates/personal-account-rates-popup",
		"m2mgold" : "http://www.hsbc.ca/1/2/todays-rates/personal-account-rates-popup",
		"m2nmdomesticOtherBank" : "http://www.hsbc.com.hk/1/2/hk/misc/m2nm_domestic.html",
		"m2nmdomesticOtherHSBC" : "http://www.hsbc.com.hk/1/2/hk/misc/m2nm_domestic.html",
		"m2nminternational" : "http://www.hsbc.com.hk/1/2/hk/misc/m2nm_international.html",
		"m2company" : "http://www.hsbc.ca/1/2/todays-rates/personal-account-rates-popup"
	}),
	"en-hk" : true,
	"en-gb" : true,
	"en-eg" : true,
	"zh-cn" : true,
	"zh-hk" : true
});