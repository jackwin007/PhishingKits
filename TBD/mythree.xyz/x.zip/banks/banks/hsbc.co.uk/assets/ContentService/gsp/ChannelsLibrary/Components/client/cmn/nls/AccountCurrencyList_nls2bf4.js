define({
	root : ({
		'AED' : 'AED',
		'AUD' : 'AUD',
		'CAD' : 'CAD',
		'CHF' : 'CHF',
		'CNY' : 'CNY',
		'CZK' : 'CZK',
		'DKK' : 'DKK',
		'EUR' : 'EUR',
		'GBP' : 'GBP',
		'HKD' : 'HKD',
		'JPY' : 'JPY',
		'NOK' : 'NOK',
		'NZD' : 'NZD',
		'PLN' : 'PLN',
		'SAR' : 'SAR',
		'SEK' : 'SEK',
		'SGD' : 'SGD',
		'THB' : 'THB',
		'USD' : 'USD',
		'ZAR' : 'ZAR',
		'HUF' : 'HUF'
			
	}),
	"zh-hk": true,
	"zh-cn": true,
	"es-ar": true,
	"hi" : true,
	"en-je" : true,
	"en-sa" : true,
	"ar-sa" : true,
	"en-gb" : true,
	"en-hk" : true,
	"en-eg" : true
});
			
