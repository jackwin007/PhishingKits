define(({
	"SanctionCountryList" : [ {
		"id" : 'kp', // North Korea
		"desckey" : 'kp',
		"default" : 'N',
	},{
		"id" : 'sy', // Syria
		"desckey" : 'sy',
		"default" : 'N',
	}, {
		"id" : 'ir', // Iran
		"desckey" : 'ir',
		"default" : 'N',
	} ]
}));