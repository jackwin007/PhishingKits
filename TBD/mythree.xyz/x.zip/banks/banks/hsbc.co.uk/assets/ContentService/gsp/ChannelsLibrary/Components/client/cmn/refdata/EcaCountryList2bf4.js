/* Global Reference Data representing payee charges List */
/* DD ID: 00072 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
    "EcaCountryList": [
        {
            "id": "AT",
            "desckey": "AT",
            "defaultKey": "N"
        },
        {
            "id": "AX",
            "desckey": "AX",
            "defaultKey": "N"
        },
        {
            "id": "BE",
            "desckey": "BE",
            "defaultKey": "N"
        },
        {
            "id": "BG",
            "desckey": "BG",
            "defaultKey": "N"
        },
        {
            "id": "HR",
            "desckey": "HR",
            "defaultKey": "N"
        },
        {
            "id": "CY",
            "desckey": "CY",
            "defaultKey": "N"
        },
        {
            "id": "CZ",
            "desckey": "CZ",
            "defaultKey": "N"
        },
        {
            "id": "DK",
            "desckey": "DK",
            "defaultKey": "N"
        },
        {
            "id": "EE",
            "desckey": "EE ",
            "defaultKey": "N"
        },
        {
            "id": "FI",
            "desckey": "FI",
            "defaultKey": "N"
        },
        {
            "id": "FR",
            "desckey": "FR",
            "defaultKey": "N"
        },
        {
            "id": "GF",
            "desckey": "GF",
            "defaultKey": "N"
        },
        {
            "id": "DE",
            "desckey": "DE",
            "defaultKey": "N"
        },
        {
            "id": "GI",
            "desckey": "GI",
            "defaultKey": "N"
        },
        {
            "id": "GR",
            "desckey": "GR",
            "defaultKey": "N"
        },
        {
            "id": "GP",
            "desckey": "GP",
            "defaultKey": "N"
        },
        {
            "id": "GG",
            "desckey": "GG",
            "defaultKey": "N"
        },
        {
            "id": "HU",
            "desckey": "HU",
            "defaultKey": "N"
        },
        
        {
            "id": "IS",
            "desckey": "IS",
            "defaultKey": "N"
        },
        {
            "id": "IE",
            "desckey": "IE",
            "defaultKey": "N"
        },
        {
            "id": "IM",
            "desckey": "IM",
            "defaultKey": "N"
        },
        {
            "id": "IT",
            "desckey": "IT",
            "defaultKey": "N"
        },
        {
            "id": "JE",
            "desckey": "JE",
            "defaultKey": "N"
        },
        {
            "id": "LV",
            "desckey": "LV",
            "defaultKey": "N"
        },
        {
            "id": "LI",
            "desckey": "LI",
            "defaultKey": "N"
        },
        {
            "id": "LT",
            "desckey": "LT",
            "defaultKey": "N"
        },
        {
            "id": "LU",
            "desckey": "LU",
            "defaultKey": "N"
        },
        {
            "id": "MT",
            "desckey": "MT",
            "defaultKey": "N"
        },
        {
            "id": "MQ",
            "desckey": "MQ",
            "defaultKey": "N"
        },
        {
            "id": "YT",
            "desckey": "YT",
            "defaultKey": "N"
        },
        {
            "id": "MC",
            "desckey": "MC",
            "defaultKey": "N"
        },
        {
            "id": "NL",
            "desckey": "NL",
            "defaultKey": "N"
        },
        {
            "id": "NO",
            "desckey": "NO",
            "defaultKey": "N"
        },
        {
            "id": "PL",
            "desckey": "PL",
            "defaultKey": "N"
        },
        {
            "id": "PT",
            "desckey": "PT ",
            "defaultKey": "N"
        },
        {
            "id": "RO",
            "desckey": "RO",
            "defaultKey": "N"
        },
        {
            "id": "RE",
            "desckey": "RE",
            "defaultKey": "N"
        },
        {
            "id": "BL",
            "desckey": "BL",
            "defaultKey": "N"
        },
        {
            "id": "PM",
            "desckey": "PM",
            "defaultKey": "N"
        },
        {
            "id": "SM",
            "desckey": "SM",
            "defaultKey": "N"
        },
        {
            "id": "SI",
            "desckey": "SI",
            "defaultKey": "N"
        },
        {
            "id": "SK",
            "desckey": "SK",
            "defaultKey": "N"
        },
        {
            "id": "ES",
            "desckey": "ES",
            "defaultKey": "N"
        },
        {
            "id": "MF",
            "desckey": "MF",
            "defaultKey": "N"
        },
        {
            "id": "SE",
            "desckey": "SE",
            "defaultKey": "N"
        },
        {
            "id": "CH",
            "desckey": "CH",
            "defaultKey": "N"
        },
        {
            "id": "GB",
            "desckey": "GB",
            "defaultKey": "N"
        }
        
    ]
}));