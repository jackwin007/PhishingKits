define({
		'isVisible' : true
});