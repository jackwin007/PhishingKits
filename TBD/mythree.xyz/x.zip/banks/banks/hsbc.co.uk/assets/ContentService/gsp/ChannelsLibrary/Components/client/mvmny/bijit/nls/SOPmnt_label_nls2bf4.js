define({
    root: {
        'amount' : 'Amount',
        'enterAmnt' : 'Enter amount',
        'amtExceedErr' : "Max number of digits inputted is 13 excluding decimal places and separators.",
        'amtNegErr' : "A valid amount must be inputted.",
        'amtZeroErr' : "A valid amount must be inputted.",
        'amtDecErr' : "A valid number of decimal places for the currency must be inputted.",
        'reference' : 'Payee reference',
        'optional' : 'Optional',
        
        
		'securityKey' : 'Security key',
		'enterReference' : 'Enter a reference for this payment',
		'invalidMessage' : 'Please enter a valid positive Amount and it does not allow special character',
		'dropdownEntry' : '<span class="title">${nickname}</span><span class="titleSubDetails"><span class="text">${accountNumber}</span><span class="text privacy">${balance}</span></span>',
		'fieldInvalidMessageCapTx' : 'The field must be between 0 and 24 characters long. It should contain only the following characters a-z, A-Z, 0-9, plus /_-?:().,+',
		'fieldInvalidMessageCapCBW' : 'The field must be between 0 and 66 characters long. It should contain only the following characters a-z, A-Z, 0-9, plus /_-?:().,+',
        'transferCurrency' : "Transfer Currency",
        'indicativeRate' : "Indicative rates are subject to change",
        'transactionReference' : "Transaction Reference"
    }
});
