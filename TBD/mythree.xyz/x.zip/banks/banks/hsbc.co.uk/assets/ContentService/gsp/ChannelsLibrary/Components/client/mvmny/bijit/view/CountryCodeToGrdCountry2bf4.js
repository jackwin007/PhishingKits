define({
	
	'gspCountryCodes' : {
		'PH' : 'P6',
		'JE' : 'JY'
	}

});