define({
	"nonGSPTxnMessageOne" : "",
	"nonGSPTxnMessageTwo" : "",
	"nonGSPTxnMessageThree" : "",
	"balance" : "Balance/Valuation",
	"tooTipMsgBal" : "The balance/valuation date shown is the date of the last valuation received and may not be the most up to date valuation or represent the current value. For non HSBC products, we rely upon the other provider to supply correct information and cannot guarantee its accuracy.",
	"penBalance" : "Balance/Valuation",
	"penTooTipMsgBal" : "This is the balance/valuation of your investment account",
	"insBalance" : "Cover value",
	"insTooTipMsgBal" : "This shows the current value of your insurance cover. ",
	"login" : "Log on to online banking for ",
	"crossEntityMessage" : "To view and manage these accounts you must log on to  this country's online banking ",
	"CC" : {
		"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=creditcardview",
		"isSensitiveData" : true,
		"iscustSeg" : true,
		"nonGSPTxnMessageOne":"Please review your statement for full details of any payments due, what to do next and how to contact us.",
	    "nonGSPTxnMessageTwo":"",
	    "nonGSPTxnMessageThree":""
	},

	"OTHER" : {
		"IVD" : {
			"linkAndLaunchUrl" : "{HSS_URL}/GSPPassThrough",
			"isSensitiveData" : false,
			"iscustSeg" : false,
			"isSSOToken" : true,
			"openType" : "_blank",
			"nonGSPTxnMessageOne":"",
    	    "nonGSPTxnMessageTwo":"",
    	    "nonGSPTxnMessageThree":""
		},
		"IVI" : {
			"linkAndLaunchUrl" : "{HSS_URL}/GSPPassThrough",
			"isSensitiveData" : false,
			"iscustSeg" : false,
			"isSSOToken" : true,
			"openType" : "_blank",
			"nonGSPTxnMessageOne":"",
    	    "nonGSPTxnMessageTwo":"",
    	    "nonGSPTxnMessageThree":""
		},
		"IVM" : {
			"linkAndLaunchUrl" : "{HSS_URL}/GSPPassThrough",
			"isSensitiveData" : "false",
			"iscustSeg" : "false",
			"isSSOToken" : true,
			"openType" : "_blank",
			"nonGSPTxnMessageOne":"",
    	    "nonGSPTxnMessageTwo":"",
    	    "nonGSPTxnMessageThree":""
		},
		"IVP" : {
			"linkAndLaunchUrl" : "{HSS_URL}/GSPPassThrough",
			"isSensitiveData" : false,
			"iscustSeg" : false,
			"isSSOToken" : true,
			"openType" : "_blank",
			"nonGSPTxnMessageOne":"",
    	    "nonGSPTxnMessageTwo":"",
    	    "nonGSPTxnMessageThree":""
		},
		"RA0" : {
			"linkAndLaunchUrl" : "{CWD_LAUNCH_URL}/wd3/group/hsbc/wd/appPage.html?channelID=OHI&channelCountryCode=GB&channelGroupMemberID=HBEU&channelBusinessLine=PFS&targetFunction=homepage",
			"isSensitiveData" : false,
			"iscustSeg" : false,
			"isSSOToken" : false,
			"nonGSPTxnMessageOne":"",
    	    "nonGSPTxnMessageTwo":"",
    	    "nonGSPTxnMessageThree":""
		}
	},
	"INV" : {
		"RB0" : {
			"linkAndLaunchUrl" : "{LEGACY_URL3}/1/2/home?flowId&=1&targetLandingPage&=rbp_home&ES_STATE_RESET&=reset&nextPage&=rbp_coreapp",
			"isSensitiveData" : false,
			"iscustSeg" : false,
			"isSSOToken" : false,
			"openType" : "_blank",
			"nonGSPTxnMessageOne" : "The balance/valuation date shown is the date of the last valuation received and may not be the most up to date valuation or represent the current value. For non HSBC products, we rely upon the other provider to supply correct information and cannot guarantee its accuracy.",
			"nonGSPTxnMessageTwo" : "",
			"nonGSPTxnMessageThree" : ""
		}

	},

	"INS" : {
		"linkAndLaunchUrl" : "#",
		"isSensitiveData" : "false",
		"iscustSeg" : "false",
		"nonGSPTxnMessageOne":"Please note that the cover value shown is subject to the terms and conditions of your policy. Please refer to your policy documentation for full details.",
	    "nonGSPTxnMessageTwo":"The cover value shown may not be the most up to date. For non HSBC products, we rely upon the other provider to supply correct information and cannot guarantee its accuracy.",
	    "nonGSPTxnMessageThree":"The cover value shows the current value of your insurance cover."
	}
});
