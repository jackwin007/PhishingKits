define(({
       "CountryValues" : [ 
               {
	              "id": 'AD',
	              "desckey": 'ANDORRA',
	              "default": 'N'
               },
		       {
		              "id": 'AE',
		              "desckey": 'UAE',
		              "default": 'N'
		       },
		       {
		              "id": 'AF',
		              "desckey": 'AFGHANISTAN',
		              "default": 'N'
		       },
		       {
		              "id": 'AG',
		              "desckey": 'ANTIGUAANDBARBUDA',
		              "default": 'N'
		       },
               {
                     "id": 'AI',
                     "desckey": 'ANGUILLA',
                     "default": 'N'
               },
               {
                     "id": 'AL',
                     "desckey": 'ALBANIA',
                     "default": 'N'
               },
               {
                     "id": 'AM',
                     "desckey": 'ARMENIA',
                     "default": 'N'
               },
               {
                  "id": 'AN',
                  "desckey": 'NETHERLANDSANTILLES',
                  "default": 'N'
               },
               {
                     "id": 'AO',
                     "desckey": 'ANGOLA',
                     "default": 'N'
               },
               {
                     "id": 'AQ',
                     "desckey": 'ANTARCTICA',
                     "default": 'N'
               },
               {
                     "id": 'AR',
                     "desckey": 'ARGENTINA',
                     "default": 'N'
               },
               {
                     "id": 'AS',
                     "desckey": 'AMERICANSAMOA',
                     "default": 'N'
               },
               {
                     "id": 'AT',
                     "desckey": 'AUSTRIA',
                     "default": 'N'
               },
               {
                     "id": 'AU',
                     "desckey": 'AUSTRALIA',
                     "default": 'N'
               },
               {
                     "id": 'AW',
                     "desckey": 'ARUBA',
                     "default": 'N'
               },
               {
                     "id": 'AX',
                     "desckey": 'ALANDISLAND',
                     "default": 'N'
			   },
               {
                     "id": 'AZ',
                     "desckey": 'AZERBAIJAN',
                     "default": 'N'
               },
               {
                     "id": 'BA',
                     "desckey": 'BOSNIAANDHERZEGOVINA',
                     "default": 'N'
               },
               {
                     "id": 'BB',
                     "desckey": 'BARBADOS',
                     "default": 'N'
               },
               {
                     "id": 'BD',
                     "desckey": 'BANGLADESH',
                     "default": 'N'
               },
               {
                     "id": 'BE',
                     "desckey": 'BELGIUM',
                     "default": 'N'
               },
               {
                     "id": 'BF',
                     "desckey": 'BURKINAFASO',
                     "default": 'N'
               },
               {
                     "id": 'BG',
                     "desckey": 'BULGARIA',
                     "default": 'N'
               },
               {
                     "id": 'BH',
                     "desckey": 'BAHRAIN',
                     "default": 'N'
               },
               {
                     "id": 'BI',
                     "desckey": 'BURUNDI',
                     "default": 'N'
               },
               {
                     "id": 'BJ',
                     "desckey": 'BENIN',
                     "default": 'N'
               },
               {
                     "id": 'BL',
                     "desckey": 'SAINTBARTHELEMY',
                     "defaultflag": 'N'
               },
               {
                     "id": 'BM',
                     "desckey": 'BERMUDA',
                     "default": 'N'
               },
               {
                     "id": 'BN',
                     "desckey": 'BRUNEIDARUSSALAM',
                     "default": 'N'
               },
               {
                     "id": 'BO',
                     "desckey": 'BOLIVIAPLURINATIONALSTATEOF',
                     "default": 'N'
               },
               {
                     "id": 'BQ',
                     "desckey": 'BONAIRESINTEUSTATIUSANDSABA',
                     "default": 'N'
               },
               {
                     "id": 'BR',
                     "desckey": 'BRAZIL',
                     "default": 'N'
               },
               {
                     "id": 'BS',
                     "desckey": 'BAHAMAS',
                     "defaultflag": 'N'
               },
               {
                     "id": 'BT',
                     "desckey": 'BHUTAN',
                     "default": 'N'
               },
               {
                     "id": 'BV',
                     "desckey": 'BOUVETISLAND',
                     "default": 'N'
               },
               {
                     "id": 'BW',
                     "desckey": 'BOTSWANA',
                     "default": 'N'
               },
               {
                     "id": 'BY',
                     "desckey": 'BELARUS',
                     "default": 'N'
               },
               {
                     "id": 'BZ',
                     "desckey": 'BELIZE',
                     "default": 'N'
               },
               {
                     "id": 'CA',
                     "desckey": 'CANADA',
                     "default": 'N'
               },
               {
                     "id": 'CC',
                     "desckey": 'COCOSISLANDS-KELLING',
                     "default": 'N'
               },
               {
                     "id": 'CD',
                     "desckey": 'CONGODEMOCRATICREPOFTHE',
                     "default": 'N'
               },
               {
                     "id": 'CF',
                     "desckey": 'CENTRALAFRICANREPUBLIC',
                     "default": 'N'
               },
               {
                     "id": 'CG',
                     "desckey": 'CONGO',
                     "default": 'N'
               },
               {
                     "id": 'CH',
                     "desckey": 'SWITZERLAND',
                     "default": 'N'
               },
               {
                     "id": 'CI',
                     "desckey": 'COTED\'IVOIRE',
                     "default": 'N'
               },
               {
                     "id": 'CK',
                     "desckey": 'COOKISLANDS',
                     "default": 'N'
               },
               {
                     "id": 'CL',
                     "desckey": 'CHILE',
                     "default": 'N'
               },
               {
                     "id": 'CM',
                     "desckey": 'CAMEROON',
                     "default": 'N'
               },
               {
                     "id": 'CN',
                     "desckey": 'CHINA',
                     "default": 'N'
               },
               {
                     "id": 'CO',
                     "desckey": 'COLOMBIA',
                     "default": 'N'
               },
               {
                     "id": 'CR',
                     "desckey": 'COSTARICA',
                     "default": 'N'
               },
               {
                  "id": 'CT',
                  "desckey": 'CANTONANDENDERBURYISLANDA',
                  "default": 'N'
               },
               {
                   "id": 'CU',
                   "desckey": 'CUBA',
                   "default": 'N'
               },
               {
                     "id": 'CV',
                     "desckey": 'CABOVERDE',
                     "default": 'N'
               },
               {
                     "id": 'CW',
                     "desckey": 'CURACAO',
                     "default": 'N'
               },
               {
                     "id": 'CX',
                     "desckey": 'CHRISTMASISLAND',
                     "default": 'N'
               },
               {
                     "id": 'CY',
                     "desckey": 'CYPRUS',
                     "default": 'N'
               },
               {
                     "id": 'CZ',
                     "desckey": 'CZECHREPUBLIC',
                     "default": 'N'
               },
               {
                     "id": 'DE',
                     "desckey": 'GERMANY',
                     "default": 'N'
               },
               {
                     "id": 'DJ',
                     "desckey": 'DJIBOUTI',
                     "default": 'N'
               },
               {
                     "id": 'DK',
                     "desckey": 'DENMARK',
                     "default": 'N'
              },
              {
                     "id": 'DM',
                     "desckey": 'DOMINICA',
                     "default": 'N'
              },
              {
                     "id": 'DO',
                     "desckey": 'DOMINICANREPUBLIC',
                     "default": 'N'
              },
              {
                     "id": 'DZ',
                     "desckey": 'ALGERIA',
                     "default": 'N'
              },
              {
                     "id": 'EC',
                     "desckey": 'ECUADOR',
                     "default": 'N'
              },
              {
                     "id": 'EE',
                     "desckey": 'ESTONIA',
                     "default": 'N'
              },
              {
                     "id": 'EG',
                     "desckey": 'EGYPT',
                     "default": 'N'
              },
              {
                     "id": 'EH',
                     "desckey": 'WESTERNSAHARA',
                     "default": 'N'
              },
              {
                     "id": 'ER',
                     "desckey": 'ERITREA',
                     "default": 'N'
              },
              {
                     "id": 'ES',
                     "desckey": 'SPAIN',
                     "default": 'N'
              },
              {
                     "id": 'ET',
                     "desckey": 'ETHIOPIA',
                     "default": 'N'
              },
              {
                     "id": 'FI',
                     "desckey": 'FINLAND',
                     "default": 'N'
              },
              {
                     "id": 'FJ',
                     "desckey": 'FIJI',
                     "default": 'N'
              },
              {
                     "id": 'FK',
                     "desckey": 'FALKLANDIS-MALVINAS',
                     "default": 'N'
              },
              {
                     "id": 'FM',
                     "desckey": 'MICRONESIA-FEDSTATESOF',
                     "default": 'N'
              },
              {
                     "id": 'FO',
                     "desckey": 'FAROEISLANDS',
                     "default": 'N'
              },
              {
                     "id": 'FR',
                     "desckey": 'FRANCE',
                     "default": 'N'
              },
              {
                     "id": 'GA',
                     "desckey": 'GABON',
                     "default": 'N'
              },
              {
                     "id": 'GB',
                     "desckey": 'UNITEDKINGDOM',
                     "default": 'N'
              },
              {
                     "id": 'GD',
                     "desckey": 'GRENADA',
                     "default": 'N'
              },
              {
                     "id": 'GE',
                     "desckey": 'GEORGIA',
                     "default": 'N'
              },
              {
                     "id": 'GF',
                     "desckey": 'FRENCHGUIANA',
                     "default": 'N'
              },
              {
                     "id": 'GG',
                     "desckey": 'GUERNSEY',
                     "default": 'N'
              },
                     {
                           "id": 'GH',
                           "desckey": 'GHANA',
                           "default": 'N'
                     },
                     {
                           "id": 'GI',
                           "desckey": 'GIBRALTAR',
                           "default": 'N'
                     },
                     {
                           "id": 'GL',
                           "desckey": 'GREENLAND',
                           "default": 'N'
                     },
                     {
                           "id": 'GM',
                           "desckey": 'GAMBIA',
                           "default": 'N'
                     },
                     {
                           "id": 'GN',
                           "desckey": 'GUINEA',
                           "default": 'N'
                     },
                     {
                           "id": 'GP',
                           "desckey": 'GUADELOUPE',
                           "default": 'N'
                     },
                     {
                           "id": 'GQ',
                           "desckey": 'EQUATORIALGUINEA',
                           "default": 'N'
                     },
                     {
                           "id": 'GR',
                           "desckey": 'GREECE',
                           "default": 'N'
                     },
                     {
                           "id": 'GS',
                           "desckey": 'SOUTHGEORGIAANDSANDWICHISLANDS',
                           "defaultflag": 'N'
                     },
                     {
                           "id": 'GT',
                           "desckey": 'GUATEMALA',
                           "default": 'N'
                     },
                     {
                           "id": 'GU',
                           "desckey": 'GUAM',
                           "default": 'N'
                     },
                     {
                           "id": 'GW',
                           "desckey": 'GUINEA-BISSAU',
                           "default": 'N'
                     },
                     {
                           "id": 'GY',
                           "desckey": 'GUYANA',
                           "default": 'N'
                     },
                     {
                           "id": 'HK',
                           "desckey": 'HONGKONG',
                           "default": 'N'
                     },
                     {
                           "id": 'HM',
                           "desckey": 'HEARD&MCDONALDIS',
                           "default": 'N'
                     },
                     {
                           "id": 'HN',
                           "desckey": 'HONDURAS',
                           "default": 'N'
                     },
                     {
                           "id": 'HR',
                           "desckey": 'CROATIA',
                           "default": 'N'
                     },
                     {
                           "id": 'HT',
                           "desckey": 'HAITI',
                           "default": 'N'
                     },
                     {
                           "id": 'HU',
                           "desckey": 'HUNGARY',
                           "default": 'N'
                     },
                     {
                           "id": 'ID',
                           "desckey": 'INDONESIA',
                           "default": 'N'
                     },
                     {
                           "id": 'IE',
                           "desckey": 'IRELAND',
                           "default": 'N'
                     },
                     {
                           "id": 'IL',
                           "desckey": 'ISRAEL',
                           "default": 'N'
                     },
                     {
                           "id": 'IM',
                           "desckey": 'ISLEOFMAN',
                           "default": 'N'
                     },
                     {
                           "id": 'IN',
                           "desckey": 'INDIA',
                           "default": 'N'
                     },
                     {
                           "id": 'IO',
                           "desckey": 'BRITISHINDIANOCEANTERRITORY',
                           "default": 'N'
                     },
                     {
                           "id": 'IQ',
                           "desckey": 'IRAQ',
                           "default": 'N'
                     },
                     {
                           "id": 'IR',
                           "desckey": 'IRAN',
                           "default": 'N'
                     },
                     {
                           "id": 'IS',
                           "desckey": 'ICELAND',
                           "default": 'N'
                     },
                     {
                           "id": 'IT',
                           "desckey": 'ITALY',
                           "default": 'N'
                     },
                     {
                           "id": 'JE',
                           "desckey": 'JERSEY',
                           "default": 'Y'
                     },
                           {
                                  "id": 'JM',
                                  "desckey": 'JAMAICA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'JO',
                                  "desckey": 'JORDAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'JP',
                                  "desckey": 'JAPAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KE',
                                  "desckey": 'KENYA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KG',
                                  "desckey": 'KYRGYZSTAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KH',
                                  "desckey": 'CAMBODIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KI',
                                  "desckey": 'KIRIBATI',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KM',
                                  "desckey": 'COMOROS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KN',
                                  "desckey": 'SAINTKITTSANDNEVIS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KP',
                                  "desckey": 'KOREA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KR',
                                  "desckey": 'SOUTHKOREA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KW',
                                  "desckey": 'KUWAIT',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KY',
                                  "desckey": 'CAYMANISLANDS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'KZ',
                                  "desckey": 'KAZAKHSTAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LA',
                                  "desckey": 'LAOPEOPLE\'SDREPUBLIC',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LB',
                                  "desckey": 'LEBANON',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LC',
                                  "desckey": 'STLUCIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LI',
                                  "desckey": 'LIECHTENSTEIN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LK',
                                  "desckey": 'SRILANKA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LR',
                                  "desckey": 'LIBERIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LS',
                                  "desckey": 'LESOTHO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LT',
                                  "desckey": 'LITHUANIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LU',
                                  "desckey": 'LUXEMBOURG',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LV',
                                  "desckey": 'LATVIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'LY',
                                  "desckey": 'LIBYANARABJAMAHIRIYA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MA',
                                  "desckey": 'MOROCCO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MC',
                                  "desckey": 'MONACO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MD',
                                  "desckey": 'MOLDOVA-REPUBLICOF',
                                  "default": 'N'
                           },
                           {
                                  "id": 'ME',
                                  "desckey": 'MONTENEGRO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MF',
                                  "desckey": 'STMARTIN',
                                  "defaultflag": 'N'
                           },
                           {
                                  "id": 'MG',
                                  "desckey": 'MADAGASCAR',
                                  "defaultflag": 'N'
                           },
                           {
                                  "id": 'MH',
                                  "desckey": 'MARSHALLISLANDS-REPOF',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MK',
                                  "desckey": 'MACEDONIA',
                                  "default": 'N'
                           },
                           {
	                               "id": 'ML',
	                               "desckey": 'MALI',
	                               "default": 'N'
                           },
                           {
                                  "id": 'MM',
                                  "desckey": 'MYANMAR',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MN',
                                  "desckey": 'MONGOLIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MO',
                                  "desckey": 'MACAO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MP',
                                  "desckey": 'NORTHERNMARIANAIS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MQ',
                                  "desckey": 'MARTINIQUE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MR',
                                  "desckey": 'MAURITANIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MS',
                                  "desckey": 'MONTSERRAT',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MT',
                                  "desckey": 'MALTA',
                                  "default": 'N'
                           },
                           {
								  "id": 'MU',
                                  "desckey": 'MAURITIUS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MV',
                                  "desckey": 'MALDIVES',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MW',
                                  "desckey": 'MALAWI',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MX',
                                  "desckey": 'MEXICO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MY',
                                  "desckey": 'MALAYSIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'MZ',
                                  "desckey": 'MOZAMBIQUE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NA',
                                  "desckey": 'NAMIBIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NC',
                                  "desckey": 'NEWCALEDONIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NE',
                                  "desckey": 'NIGER',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NF',
                                  "desckey": 'NORFOLKISLAND',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NG',
                                  "desckey": 'NIGERIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NI',
                                  "desckey": 'NICARAGUA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NL',
                                  "desckey": 'NETHERLANDS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NO',
                                  "desckey": 'NORWAY',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NP',
                                  "desckey": 'NEPAL',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NR',
                                  "desckey": 'NAURU',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NU',
                                  "desckey": 'NIUE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'NZ',
                                  "desckey": 'NEWZEALAND',
                                  "default": 'N'
                           },
                           {
                                  "id": 'OM',
                                  "desckey": 'OMAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PA',
                                  "desckey": 'PANAMA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PE',
                                  "desckey": 'PERU',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PF',
                                  "desckey": 'FRENCHPOLYNESIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PG',
                                  "desckey": 'PAPUANEWGUINEA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PH',
                                  "desckey": 'PHILIPPINES',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PK',
                                  "desckey": 'PAKISTAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PL',
                                  "desckey": 'POLAND',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PM',
                                  "desckey": 'STPIERRE&MIQUELON',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PN',
                                  "desckey": 'PITCAIRN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PR',
                                  "desckey": 'PUERTORICO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PS',
                                  "desckey": 'PALESTINIANTERRITORY',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PT',
                                  "desckey": 'PORTUGAL',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PW',
                                  "desckey": 'PALAU',
                                  "default": 'N'
                           },
                           {
                                  "id": 'PY',
                                  "desckey": 'PARAGUAY',
                                  "default": 'N'
                           },
                           {
                                  "id": 'QA',
                                  "desckey": 'QATAR',
                                  "default": 'N'
                           },
                           {
                                  "id": 'RE',
                                  "desckey": 'REUNION',
                                  "default": 'N'
                           },
                           {
                                  "id": 'RO',
                                  "desckey": 'ROMANIA',
                                  "default": 'N'
                           },
                           {
                               "id": 'RS',
                               "desckey": 'SERBIA',
                               "default": 'N'
                           },
                           {
                                  "id": 'RU',
                                  "desckey": 'RUSSIAFEDERATION',
                                  "default": 'N'
                           },
                           {
                                  "id": 'RW',
                                  "desckey": 'RWANDA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SA',
                                  "desckey": 'SAUDIARABIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SB',
                                  "desckey": 'SOLOMONISLANDS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SC',
                                  "desckey": 'SEYCHELLES',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SD',
                                  "desckey": 'SUDAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SE',
                                  "desckey": 'SWEDEN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SG',
                                  "desckey": 'SINGAPORE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SH',
                                  "desckey": 'STHELENA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SI',
                                  "desckey": 'SLOVENIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SJ',
                                  "desckey": 'SVALBARD&JANMAYENIS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SK',
                                  "desckey": 'SLOVAKIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SL',
                                  "desckey": 'SIERRALEONE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SM',
                                  "desckey": 'SANMARINO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SN',
                                  "desckey": 'SENEGAL',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SO',
                                  "desckey": 'SOMALIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SR',
                                  "desckey": 'SURINAME',
                                  "default": 'N'
                           },
                           {
                               "id": 'SS',
                               "desckey": 'SOUTHSUDAN',
                               "default": 'N'
                           },
                           {
                                  "id": 'ST',
                                  "desckey": 'SAOTOMEANDPRINCIPE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SV',
                                  "desckey": 'ELSALVADOR',
                                  "default": 'N'
                           },
                           {
                               "id": 'SX',
                               "desckey": 'SINTMAARTEN',
                               "default": 'N'
                           },
                           {
                                  "id": 'SY',
                                  "desckey": 'SYRIANARABREPUBLIC',
                                  "default": 'N'
                           },
                           {
                                  "id": 'SZ',
                                  "desckey": 'SWAZILAND',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TC',
                                  "desckey": 'TURKSANDCAICOSISLANDS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TD',
                                  "desckey": 'CHAD',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TF',
                                  "desckey": 'FRENCHSOUTHERNTERRITORIES',
                                  "default": 'N'
                           },
                           {
	                               "id": 'TG',
	                               "desckey": 'TOGO',
	                               "default": 'N'
                           },
                           {
                                  "id": 'TH',
                                  "desckey": 'THAILAND',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TJ',
                                  "desckey": 'TAJIKISTAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TK',
                                  "desckey": 'TOKELAU',
                                  "default": 'N'
                           },
                           {
	                               "id": 'TL',
	                               "desckey": 'TIMORLESTE',
	                               "defaultflag": 'N'
                           },
                           {
                                  "id": 'TM',
                                  "desckey": 'TURKMENISTAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TN',
                                  "desckey": 'TUNISIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TO',
                                  "desckey": 'TONGA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TP',
                                  "desckey": 'EASTTIMOR',
                                  "default": 'N'
                           },
                            {
                                  "id": 'TR',
                                  "desckey": 'TURKEY',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TT',
                                  "desckey": 'TRINIDAD&TOBAGO',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TV',
                                  "desckey": 'TUVALU',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TW',
                                  "desckey": 'TAIWAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'TZ',
                                  "desckey": 'TANZANIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'UA',
                                  "desckey": 'UKRAINE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'UG',
                                  "desckey": 'UGANDA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'UM',
                                  "desckey": 'UNITESSTATESMINOROUTLYINGISLANDS',
                                  "defaultflag": 'N'
                           },
                           {
                                  "id": 'US',
                                  "desckey": 'UNITEDSTATES',
                                  "default": 'N'
                           },
                           {
                                  "id": 'UY',
                                  "desckey": 'URUGUAY',
                                  "default": 'N'
                           },
                           {
                                  "id": 'UZ',
                                  "desckey": 'UZBEKISTAN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VA',
                                  "desckey": 'VATICANCITYSTATE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VC',
                                  "desckey": 'STVINCENT&GRENADINES',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VE',
                                  "desckey": 'VENEZUELA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VG',
                                  "desckey": 'VIRGINISLANDS-BRITISH',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VI',
                                  "desckey": 'VIRGINISLANDS-US',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VN',
                                  "desckey": 'VIETNAM',
                                  "default": 'N'
                           },
                           {
                                  "id": 'VU',
                                  "desckey": 'VANUATU',
                                  "default": 'N'
                           },
                           {
                                  "id": 'WF',
                                  "desckey": 'WALLISANDFUTUNAIS',
                                  "default": 'N'
                           },
                           {
                                  "id": 'WS',
                                  "desckey": 'SAMOA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'YE',
                                  "desckey": 'YEMEN',
                                  "default": 'N'
                           },
                           {
                                  "id": 'YT',
                                  "desckey": 'MAYOTTE',
                                  "default": 'N'
                           },
                           {
                                  "id": 'ZA',
                                  "desckey": 'SOUTHAFRICA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'ZM',
                                  "desckey": 'ZAMBIA',
                                  "default": 'N'
                           },
                           {
                                  "id": 'ZW',
                                  "desckey": 'ZIMBABWE',
                                  "default": 'N'
                           }
                     ]
}));
