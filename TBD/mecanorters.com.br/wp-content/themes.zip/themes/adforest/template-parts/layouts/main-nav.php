<?php global $adforest_theme; ?>
<!-- menu links -->
<ul class="menu-links">
<?php adforest_themeMenu( 'main_menu' ); ?>
</ul>