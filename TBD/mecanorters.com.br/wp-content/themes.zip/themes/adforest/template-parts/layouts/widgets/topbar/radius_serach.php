<div class="col-md-4 col-xs-12 col-sm-6">
<?php
	$radius = '';
	$area	= '';
	if( isset($_GET['org']) && $_GET['org'] != "" && isset($_GET['rd']) && $_GET['rd'] != "" )
	{
		$radius	=	$_GET['rd'];	
		$area	=	$_GET['org'];
	}
?>
<form id="sb-radius-form" class="for-radius">
    <div class="form-group">
        <label><?php echo esc_html( $instance['title'] ); ?></label>
        
        
        
        
        
        <div class="with-top-bar clearfix">
            <div class="col-md-9 no-padding">
                
                <input name="org" class="form-control" id="sb_user_address" placeholder="<?php echo __('Type Location...','adforest' ); ?>" type="text" data-parsley-required="true" data-parsley-error-message="" value="<?php echo esc_attr( $area ); ?>">
                
                
                <i id="you_current_location_text" class="fa fa-bullseye"></i>
            </div>
            <div class="col-md-3  no-padding">
           	 <input name="rd" value="<?php echo esc_attr( $radius ); ?>" placeholder="<?php echo __('Radius in km','adforest' ); ?>" type="number" data-parsley-required="true" data-parsley-error-message="" class="form-control" >
             <input type="submit" hidden />
            </div>
       </div>
        
        
       </div> 
        

	<?php echo adforest_search_params( 'org', 'rd'); ?>
</form>
<?php 
		adforest_widget_counter();
	?>
</div>
<?php adforest_advance_search_container(); ?>