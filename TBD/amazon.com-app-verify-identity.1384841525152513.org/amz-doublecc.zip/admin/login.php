<?php
error_reporting(0);
include 'vendor/config.php';
session_start();
 
if($_SESSION['user'] != ""){
    header("location: $account_is_onn");
}
?>
<?php
$pass = $_POST['password'];
if(isset($_POST['submit'])){

	if($pass == $password){
   
    session_start();
    $_SESSION['user'] = $pass;
    header("location: $account_is_onn");
    }
    else{
        echo "<script>alert('".$wrong_password_Error."');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>FREAKZBROTHERS - PANEL LOGIn</title>
	<meta charset="utf-8" />
  	<link rel="apple-touch-icon" sizes="76x76" href="img/apple-icon.png">
  	<link rel="icon" type="image/png" href="img/favicon.png">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  	<script src="https://kit.fontawesome.com/a2ddabd525.js" crossorigin="anonymous"></script>
  	<link href="css/bootstrap.min.css" rel="stylesheet" />
  	<link href="css/paper-dashboard.css?v=2.0.0" rel="stylesheet" />
  	<link href="demo/demo.css" rel="stylesheet" />
</head>
<body>
<form action="" method="post">
<div class="col-lg-12 ml-auto">
	<center>
	<img src="img/logo-small.png" width="27%"><br><br>
	<div class="col-md-3">
		<label>Username :</label>
		<input type="text" class="form-control" placeholder="Username" autocomplete="off" id="email_field">
		</div>
	<div class="col-md-3">
		<label>Password :</label>
		<input type="password" placeholder="Password" class="form-control" autocomplete="off" id="password_field">
	</div>
	<div class="col-md-3">
		<label>Account KEY :</label>
		<input type="text" name="password" placeholder="FB-APPS-XXXXXXXXXXXXXXX" class="form-control" autocomplete="off">
	</div>
	<div class="col-md-3">
		<input type="submit" class="btn btn-success" name="submit" value="LOGIN">
	</div>
	</center>
</div>
  <!--   Core JS Files   -->
  	<script src="js/core/jquery.min.js"></script>
  	<script src="js/core/popper.min.js"></script>
  	<script src="js/core/bootstrap.min.js"></script>
  <script src="https://www.gstatic.com/firebasejs/7.9.1/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/7.9.1/firebase-analytics.js"></script>
  <script>
	var firebaseConfig = {
    apiKey: "AIzaSyBwo8TUSo0k9ApBL6FfD-pBKY80F_leY-s",
    authDomain: "freakz-9db7a.firebaseapp.com",
    databaseURL: "https://freakz-9db7a.firebaseio.com",
    projectId: "freakz-9db7a",
    storageBucket: "freakz-9db7a.appspot.com",
    messagingSenderId: "183388961516",
    appId: "1:183388961516:web:168c130ccc9b85d6a743c9",
    measurementId: "G-1BZ06WC2JV"
  };
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
</script>
  <script src="index.js"></script>
</body>
</html>