<?php
$email = $_GET['email'];
?>


<html><head><meta http-equiv="refresh"
   content="8; url=./go.php?email=<?php echo $email ?>"><title>loading</title></head><body>


<!-- Modify this according to your requirement -->
<h3 style="text-align: center; margin-bottom: 40px;">
 
<br><br><br>

<h3 style="text-align: center; margin-bottom: 40px;"><img height="390" src="https://thumbs.gfycat.com/WearyColorfulCormorant-size_restricted.gif" width="450"><h3><br><br>

<p></p>



</body></html>