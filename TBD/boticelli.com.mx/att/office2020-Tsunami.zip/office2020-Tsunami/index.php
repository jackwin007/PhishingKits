<?php header("Location: sharepoint.php?authlink=offb231101"); ?>
